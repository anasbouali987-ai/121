package com.gtavtools.app121;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.Deflater;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

public final class MainActivity extends Activity {
    private static final int PICK_RUNTIME = 1211;
    private static final int PICK_OUTPUT_TREE = 1212;
    private static final long CHUNK_SIZE = 24L * 1024L * 1024L;
    private static final String BOX64_PATH = "bin/box64";

    private Uri runtimeUri;
    private Uri outputTreeUri;
    private TextView runtimeLabel;
    private TextView outputLabel;
    private TextView logView;
    private ProgressBar progress;
    private Button runButton;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(buildUi());
    }

    private View buildUi() {
        int pad = dp(18);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);
        root.setBackgroundColor(0xFFF7F7F7);

        TextView title = text("121", 34, true);
        title.setGravity(Gravity.CENTER_HORIZONTAL);
        root.addView(title, matchWrap());

        TextView subtitle = text("Box64 Surgical Extractor", 17, false);
        subtitle.setGravity(Gravity.CENTER_HORIZONTAL);
        subtitle.setTextColor(0xFF555555);
        root.addView(subtitle, matchWrap());

        TextView info = text(
                "يستخرج bin/box64 من GTAV_Runtime_Package.zip، يتحقق من البصمة وARM64، يضغطه ثم يقسمه إلى أجزاء أصغر من 25MB عند الحاجة.",
                15, false);
        info.setPadding(0, dp(16), 0, dp(14));
        root.addView(info, matchWrap());

        Button chooseRuntime = button("1 — اختر GTAV_Runtime_Package.zip");
        chooseRuntime.setOnClickListener(v -> pickRuntime());
        root.addView(chooseRuntime, matchWrap());
        runtimeLabel = text("لم يتم اختيار الحزمة", 13, false);
        runtimeLabel.setTextColor(0xFF666666);
        root.addView(runtimeLabel, matchWrap());

        Button chooseOutput = button("2 — اختر مجلد حفظ الناتج");
        chooseOutput.setOnClickListener(v -> pickOutputTree());
        LinearLayout.LayoutParams outputParams = matchWrap();
        outputParams.topMargin = dp(10);
        root.addView(chooseOutput, outputParams);
        outputLabel = text("لم يتم اختيار المجلد", 13, false);
        outputLabel.setTextColor(0xFF666666);
        root.addView(outputLabel, matchWrap());

        runButton = button("3 — استخرج واضغط وقسّم");
        runButton.setEnabled(false);
        runButton.setOnClickListener(v -> startPackaging());
        LinearLayout.LayoutParams runParams = matchWrap();
        runParams.topMargin = dp(16);
        root.addView(runButton, runParams);

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setVisibility(View.GONE);
        LinearLayout.LayoutParams progressParams = new LinearLayout.LayoutParams(-1, dp(12));
        progressParams.topMargin = dp(14);
        root.addView(progress, progressParams);

        logView = text("جاهز.", 13, false);
        logView.setTextIsSelectable(true);
        logView.setPadding(dp(12), dp(12), dp(12), dp(12));
        logView.setBackgroundColor(0xFFFFFFFF);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(logView, new ScrollView.LayoutParams(-1, -2));
        LinearLayout.LayoutParams scrollParams = new LinearLayout.LayoutParams(-1, 0, 1f);
        scrollParams.topMargin = dp(14);
        root.addView(scroll, scrollParams);
        return root;
    }

    private void pickRuntime() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/zip");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/zip", "application/octet-stream"});
        startActivityForResult(intent, PICK_RUNTIME);
    }

    private void pickOutputTree() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION |
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION | Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
        startActivityForResult(intent, PICK_OUTPUT_TREE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (requestCode == PICK_RUNTIME) {
            runtimeUri = uri;
            getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            runtimeLabel.setText(uri.toString());
        } else if (requestCode == PICK_OUTPUT_TREE) {
            outputTreeUri = uri;
            int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            getContentResolver().takePersistableUriPermission(uri, flags);
            outputLabel.setText(uri.toString());
        }
        runButton.setEnabled(runtimeUri != null && outputTreeUri != null);
    }

    private void startPackaging() {
        runButton.setEnabled(false);
        progress.setVisibility(View.VISIBLE);
        progress.setProgress(0);
        logView.setText("");
        worker.execute(() -> {
            File workDir = new File(getCacheDir(), "app121-work");
            deleteTree(workDir);
            if (!workDir.mkdirs() && !workDir.isDirectory()) {
                fail("تعذر إنشاء مجلد العمل.");
                return;
            }
            try {
                append("فتح حزمة Runtime...");
                File box64 = new File(workDir, "libbox64.so");
                JSONObject runtimeManifest = extractAndVerify(box64);
                updateProgress(45);

                append("ضغط Box64 بأقصى ضغط ZIP...");
                File bundleZip = new File(workDir, "box64_bundle.zip");
                createBundleZip(box64, runtimeManifest, bundleZip);
                updateProgress(70);

                append("تقسيم الناتج إلى أجزاء 24 MiB عند الحاجة...");
                List<File> pieces = splitIfNeeded(bundleZip, workDir);
                JSONObject bundleManifest = createBundleManifest(box64, bundleZip, pieces, runtimeManifest);
                File manifestFile = new File(workDir, "box64_bundle.json");
                try (OutputStream out = new FileOutputStream(manifestFile)) {
                    out.write(bundleManifest.toString(2).getBytes(java.nio.charset.StandardCharsets.UTF_8));
                }
                updateProgress(85);

                append("حفظ الملفات في المجلد المختار...");
                for (File piece : pieces) copyToTree(piece);
                copyToTree(manifestFile);
                updateProgress(100);

                append("");
                append("✅ اكتملت العملية بنجاح");
                append("Box64 الأصلي: " + human(box64.length()));
                append("الملف المضغوط: " + human(bundleZip.length()));
                append("عدد الأجزاء: " + pieces.size());
                append("SHA-256: " + sha256(box64));
                append("ارفع جميع الأجزاء وملف box64_bundle.json إلى GitHub.");
                runOnUiThread(() -> Toast.makeText(this, "تم إنشاء حزمة Box64", Toast.LENGTH_LONG).show());
            } catch (Throwable t) {
                fail(t.getClass().getSimpleName() + ": " + t.getMessage());
            } finally {
                runOnUiThread(() -> runButton.setEnabled(true));
            }
        });
    }

    private JSONObject extractAndVerify(File output) throws Exception {
        byte[] manifestBytes = null;
        boolean boxFound = false;
        long extracted = 0;
        try (InputStream raw = getContentResolver().openInputStream(runtimeUri);
             ZipInputStream zip = new ZipInputStream(new BufferedInputStream(require(raw)))) {
            ZipEntry entry;
            byte[] buffer = new byte[1024 * 1024];
            while ((entry = zip.getNextEntry()) != null) {
                String name = normalize(entry.getName());
                if ("runtime_manifest.json".equals(name)) {
                    ByteArrayOutputStream memory = new ByteArrayOutputStream();
                    int n;
                    while ((n = zip.read(buffer)) >= 0) memory.write(buffer, 0, n);
                    manifestBytes = memory.toByteArray();
                    append("تم العثور على runtime_manifest.json");
                } else if (BOX64_PATH.equals(name)) {
                    try (OutputStream out = new BufferedOutputStream(new FileOutputStream(output))) {
                        int n;
                        while ((n = zip.read(buffer)) >= 0) {
                            out.write(buffer, 0, n);
                            extracted += n;
                        }
                    }
                    boxFound = true;
                    append("تم استخراج bin/box64: " + human(extracted));
                }
                zip.closeEntry();
            }
        }
        if (manifestBytes == null) throw new IllegalStateException("runtime_manifest.json غير موجود");
        if (!boxFound || !output.isFile()) throw new IllegalStateException("bin/box64 غير موجود");

        JSONObject manifest = new JSONObject(new String(manifestBytes, java.nio.charset.StandardCharsets.UTF_8));
        JSONObject expected = findManifestEntry(manifest, BOX64_PATH);
        long expectedSize = expected.getLong("size_bytes");
        String expectedHash = expected.getString("sha256");
        String actualHash = sha256(output);
        if (output.length() != expectedSize) {
            throw new SecurityException("حجم Box64 لا يطابق manifest: " + output.length() + " != " + expectedSize);
        }
        if (!actualHash.equalsIgnoreCase(expectedHash)) {
            throw new SecurityException("بصمة Box64 لا تطابق manifest");
        }
        verifyArm64Elf(output);
        append("✅ الحجم والبصمة وELF ARM64 صحيحة");
        return manifest;
    }

    private static JSONObject findManifestEntry(JSONObject manifest, String wanted) throws Exception {
        JSONArray files = manifest.getJSONArray("files");
        for (int i = 0; i < files.length(); i++) {
            JSONObject item = files.getJSONObject(i);
            if (wanted.equals(item.optString("path"))) return item;
        }
        throw new IllegalStateException("لا يوجد سجل bin/box64 في manifest");
    }

    private static void verifyArm64Elf(File file) throws Exception {
        byte[] header = new byte[20];
        try (InputStream in = new FileInputStream(file)) {
            int read = in.read(header);
            if (read < header.length) throw new SecurityException("ملف Box64 قصير أو تالف");
        }
        if (header[0] != 0x7F || header[1] != 'E' || header[2] != 'L' || header[3] != 'F') {
            throw new SecurityException("Box64 ليس ملف ELF");
        }
        int machine = (header[18] & 0xFF) | ((header[19] & 0xFF) << 8);
        if (machine != 183) throw new SecurityException("Box64 ليس AArch64؛ e_machine=" + machine);
    }

    private void createBundleZip(File box64, JSONObject runtimeManifest, File output) throws Exception {
        JSONObject metadata = new JSONObject();
        metadata.put("schema_version", 1);
        metadata.put("tool", "121 Box64 Surgical Extractor");
        metadata.put("source_runtime_id", runtimeManifest.optString("runtime_id"));
        metadata.put("source_runtime_version", runtimeManifest.optString("version"));
        metadata.put("payload_name", "libbox64.so");
        metadata.put("payload_size_bytes", box64.length());
        metadata.put("payload_sha256", sha256(box64));

        try (ZipOutputStream zip = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(output)))) {
            zip.setLevel(Deflater.BEST_COMPRESSION);
            ZipEntry payload = new ZipEntry("libbox64.so");
            payload.setTime(0L);
            zip.putNextEntry(payload);
            try (InputStream in = new BufferedInputStream(new FileInputStream(box64))) {
                copy(in, zip);
            }
            zip.closeEntry();

            ZipEntry meta = new ZipEntry("box64_payload.json");
            meta.setTime(0L);
            zip.putNextEntry(meta);
            zip.write(metadata.toString(2).getBytes(java.nio.charset.StandardCharsets.UTF_8));
            zip.closeEntry();
        }
    }

    private static List<File> splitIfNeeded(File zip, File workDir) throws Exception {
        List<File> result = new ArrayList<>();
        if (zip.length() <= CHUNK_SIZE) {
            result.add(zip);
            return result;
        }
        byte[] buffer = new byte[1024 * 1024];
        try (InputStream in = new BufferedInputStream(new FileInputStream(zip))) {
            int part = 1;
            while (true) {
                File piece = new File(workDir, String.format(Locale.US, "box64_bundle.zip.%03d", part));
                long written = 0;
                try (OutputStream out = new BufferedOutputStream(new FileOutputStream(piece))) {
                    while (written < CHUNK_SIZE) {
                        int max = (int) Math.min(buffer.length, CHUNK_SIZE - written);
                        int n = in.read(buffer, 0, max);
                        if (n < 0) break;
                        out.write(buffer, 0, n);
                        written += n;
                    }
                }
                if (written == 0) {
                    piece.delete();
                    break;
                }
                result.add(piece);
                part++;
            }
        }
        return result;
    }

    private static JSONObject createBundleManifest(File box64, File zip, List<File> pieces, JSONObject runtime) throws Exception {
        JSONObject root = new JSONObject();
        root.put("schema_version", 1);
        root.put("tool", "121 Box64 Surgical Extractor");
        root.put("source_runtime_id", runtime.optString("runtime_id"));
        root.put("source_runtime_version", runtime.optString("version"));
        root.put("payload_name", "libbox64.so");
        root.put("payload_size_bytes", box64.length());
        root.put("payload_sha256", sha256(box64));
        root.put("archive_size_bytes", zip.length());
        root.put("archive_sha256", sha256(zip));
        root.put("chunk_size_bytes", CHUNK_SIZE);
        JSONArray chunks = new JSONArray();
        for (int i = 0; i < pieces.size(); i++) {
            File p = pieces.get(i);
            JSONObject item = new JSONObject();
            item.put("index", i + 1);
            item.put("name", p.getName());
            item.put("size_bytes", p.length());
            item.put("sha256", sha256(p));
            chunks.put(item);
        }
        root.put("chunks", chunks);
        root.put("reassemble_command", pieces.size() == 1 ? "use box64_bundle.zip directly" : "cat box64_bundle.zip.* > box64_bundle.zip");
        return root;
    }

    private void copyToTree(File source) throws Exception {
        ContentResolver resolver = getContentResolver();
        Uri docUri = DocumentsContract.buildDocumentUriUsingTree(
                outputTreeUri, DocumentsContract.getTreeDocumentId(outputTreeUri));
        Uri created = DocumentsContract.createDocument(resolver, docUri, mimeFor(source.getName()), source.getName());
        if (created == null) throw new IllegalStateException("تعذر إنشاء " + source.getName());
        try (InputStream in = new BufferedInputStream(new FileInputStream(source));
             OutputStream out = new BufferedOutputStream(require(resolver.openOutputStream(created, "w")))) {
            copy(in, out);
        }
        append("حُفظ: " + source.getName() + " — " + human(source.length()));
    }

    private static String mimeFor(String name) {
        return name.endsWith(".json") ? "application/json" : "application/octet-stream";
    }

    private static void copy(InputStream in, OutputStream out) throws Exception {
        byte[] buffer = new byte[1024 * 1024];
        int n;
        while ((n = in.read(buffer)) >= 0) out.write(buffer, 0, n);
    }

    private static String sha256(File file) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] buffer = new byte[1024 * 1024];
        try (InputStream in = new BufferedInputStream(new FileInputStream(file))) {
            int n;
            while ((n = in.read(buffer)) >= 0) md.update(buffer, 0, n);
        }
        StringBuilder out = new StringBuilder(64);
        for (byte b : md.digest()) out.append(String.format(Locale.US, "%02x", b));
        return out.toString();
    }

    private static String normalize(String name) {
        while (name.startsWith("/")) name = name.substring(1);
        return name.replace('\\', '/');
    }

    private static <T> T require(T value) {
        if (value == null) throw new IllegalStateException("تعذر فتح الملف أو المجلد");
        return value;
    }

    private void append(String line) {
        runOnUiThread(() -> logView.append(line + "\n"));
    }

    private void updateProgress(int value) {
        runOnUiThread(() -> progress.setProgress(value));
    }

    private void fail(String message) {
        append("❌ " + message);
        runOnUiThread(() -> {
            progress.setVisibility(View.GONE);
            runButton.setEnabled(true);
            Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        });
    }

    private static void deleteTree(File file) {
        if (file == null || !file.exists()) return;
        File[] children = file.listFiles();
        if (children != null) for (File child : children) deleteTree(child);
        file.delete();
    }

    private static String human(long bytes) {
        if (bytes < 1024) return bytes + " B";
        double value = bytes;
        String[] units = {"KiB", "MiB", "GiB"};
        int unit = -1;
        do { value /= 1024.0; unit++; } while (value >= 1024 && unit < units.length - 1);
        return String.format(Locale.US, "%.2f %s", value, units[unit]);
    }

    private TextView text(String value, int sp, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(sp);
        view.setTextColor(0xFF111111);
        if (bold) view.setTypeface(view.getTypeface(), android.graphics.Typeface.BOLD);
        return view;
    }

    private Button button(String value) {
        Button button = new Button(this);
        button.setText(value);
        button.setAllCaps(false);
        return button;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(-1, -2);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onDestroy() {
        worker.shutdownNow();
        super.onDestroy();
    }
}
