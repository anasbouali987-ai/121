plugins {
    id("com.android.application")
}

android {
    namespace = "com.gtavtools.app121"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.gtavtools.app121"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
}
