# V1F — Celestial Focus Lock

V1F هو الإصدار الوظيفي الأول لتطبيق حظر التطبيقات ذي الهوية السماوية.

## التدفق

1. فعّل الطبقات الثلاث:
   - Accessibility Service.
   - Device Administrator.
   - Foreground background protection.
2. اضغط بطاقة اختيار التطبيقات.
3. اختر تطبيقًا أو أكثر من قائمة تعرض تطبيقات المستخدم والنظام، بما فيها Settings.
4. اضغط **OKAY**.
5. اختر مدة من دقيقة إلى 24 ساعة.
6. اضغط **START** وراجع التطبيقات والمدة.
7. يتحول العداد إلى الأحمر وتبدأ الجلسة الصارمة.
8. عند فتح تطبيق محظور تظهر شاشة سوداء مع شهاب محترق والوقت المتبقي.

## الصرامة

- لا يوجد زر إلغاء جلسة داخل التطبيق.
- بطاقة الصلاحيات تصبح حمراء ومقفلة أثناء الجلسة.
- صفحات Settings والحماية المعروفة لدى عدد من الشركات تُحجب أثناء الجلسة.
- Foreground Service يعرض إشعارًا دائمًا ويحدّث الوقت.
- العداد يستخدم `elapsedRealtime` مع checkpoints.
- إطفاء الهاتف لا يحذف الوقت المتبقي؛ يعاد تثبيته بعد الإقلاع.

## حدود Android

V1F ليس Device Owner. لا يمكن لتطبيق عادي ضمان منع مطلق ضد Safe Mode أو ADB أو Root أو مسح البيانات أو Factory Reset. التطبيق يزيد الاحتكاك ويمنع مسارات العبث العادية، ولا يدّعي امتلاك سلطة أعلى من Android.

## البناء

يتطلب:

- JDK 17
- Android SDK 35
- Gradle 8.9
- Android Gradle Plugin 8.7.3

محليًا:

```bash
./gradlew :app:assembleDebug
```

عبر GitHub، استخدم ملف `build-any-zip.yml` المنفصل وضعه في:

```text
.github/workflows/build-any-zip.yml
```

## الملفات المرجعية

- `COMPARISON.md`
- `ARCHITECTURE.md`
- `DESIGN_SYSTEM.md`
- `PLAY_POLICY_NOTES.md`
- `STATE_MACHINE.md`
