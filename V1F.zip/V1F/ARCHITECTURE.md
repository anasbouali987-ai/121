# V1F Architecture

```text
com.v1f.app
├── V1FApplication / AppGraph
├── data
│   ├── SessionRepository
│   ├── PermissionRepository
│   └── InstalledAppsRepository
├── model
│   ├── ActiveSession
│   ├── InstalledApp
│   └── PermissionSnapshot
├── service
│   ├── AppBlockAccessibilityService
│   ├── PermissionGuard
│   └── BackgroundProtectionService
├── admin
│   └── V1FDeviceAdminReceiver
├── receiver
│   └── BootReceiver
├── MainActivity / LockActivity
└── ui
    ├── background
    ├── components
    ├── screens
    └── theme
```

## Enforcement path

1. Accessibility receives `TYPE_WINDOW_STATE_CHANGED` or `TYPE_WINDOWS_CHANGED`.
2. The session repository verifies that a strict session is active.
3. The observed package is compared with:
   - user-selected blocked packages;
   - dynamically discovered Settings package;
   - known vendor permission/security packages.
4. Accessibility performs HOME and launches the private `LockActivity`.
5. `MeteorLockScreen` displays the remaining monotonic duration.

## Session clock

During the same boot, `SystemClock.elapsedRealtime()` is authoritative. The foreground service checkpoints the remaining duration every 15 seconds. If the boot count changes, the saved remaining duration is rebased onto the new elapsed clock. This prevents rebooting from being used as a shortcut.

## Expansion

Future restrictions should be implemented as policies behind a common engine:

- website policies;
- schedules;
- settings categories;
- new-app policies;
- accountability partner;
- managed Device Owner mode.
