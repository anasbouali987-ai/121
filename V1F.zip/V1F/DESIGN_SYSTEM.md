# V1F Celestial Design System

## Core states

- Gold: setup required.
- Cyan: all protection layers ready.
- Red: strict session active and non-editable.
- Mint: successful completion, reserved for a future completion screen.

## High-value effects

- Seeded stars rendered once.
- Six twinkling stars only.
- Slow radial Aurora drift.
- Fake glass surfaces without live blur.
- Breathing and rotating Celestial Protection Core.
- Red pulse used only for locked session elements.
- Canvas-drawn burned meteor; no image assets or video background.

## Interaction rules

- One primary action per screen.
- Technical permissions remain on their own screen.
- Critical irreversible action receives a final confirmation.
- Once a session begins, no cancel or duration-edit control is rendered.
