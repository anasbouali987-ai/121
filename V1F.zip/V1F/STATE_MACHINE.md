# V1F State Machine

```text
SETUP_REQUIRED
  └─ منح 3 طبقات
       ↓
READY
  └─ اختيار التطبيقات
       ↓
APPS_SELECTED
  └─ OKAY
       ↓
DURATION_SELECTED
  └─ START + مراجعة نهائية
       ↓
SEALING (720 ms red transition)
       ↓
ACTIVE_STRICT_SESSION
  ├─ Permission card locked/red
  ├─ Settings guard active
  ├─ Selected apps blocked
  ├─ Foreground notification active
  └─ No in-app cancel action
       ↓ timer reaches zero
COMPLETED / READY
```

## Invariants

- A session cannot start with zero selected apps.
- A session cannot start unless the latest permission snapshot is 3/3.
- Duration must be between 60,000 ms and 86,400,000 ms.
- Only expiration code clears an active session.
- UI never renders a cancel-session control.
- Settings guard is evaluated dynamically by Accessibility.
