package com.v1f.app.service

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings

/**
 * Protects the ordinary Settings surfaces a user would normally use to remove
 * Accessibility, Device Admin, notification or battery permissions during a
 * sealed session.
 *
 * This is a deterrence layer, not a claim of system-level control. Safe mode,
 * ADB, root, factory reset and other owner-level actions remain outside the
 * authority of a normal Android application.
 */
object PermissionGuard {
    private val knownSettingsPackages = setOf(
        "com.android.settings",
        "com.miui.securitycenter",
        "com.coloros.safecenter",
        "com.oplus.safecenter",
        "com.samsung.android.lool",
        "com.huawei.systemmanager",
        "com.vivo.permissionmanager",
        "com.iqoo.secure",
        "com.realme.securitycheck"
    )

    fun guardedPackages(context: Context): Set<String> = buildSet {
        addAll(knownSettingsPackages)
        val settingsPackage = context.packageManager.resolveActivity(
            Intent(Settings.ACTION_SETTINGS),
            PackageManager.MATCH_DEFAULT_ONLY
        )?.activityInfo?.packageName
        if (!settingsPackage.isNullOrBlank()) add(settingsPackage)
    }

    fun shouldGuard(context: Context, packageName: String): Boolean =
        packageName in guardedPackages(context)
}
