package com.v1f.app.service

import android.accessibilityservice.AccessibilityService
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.view.accessibility.AccessibilityEvent
import com.v1f.app.AppGraph
import com.v1f.app.LockActivity

class AppBlockAccessibilityService : AccessibilityService() {
    private val mainHandler = Handler(Looper.getMainLooper())
    private var lastBlockedPackage: String? = null
    private var lastBlockedAt = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        AppGraph.permissionRepository.refresh()
        if (
            AppGraph.permissionRepository.isBackgroundRequested() ||
            AppGraph.sessionRepository.session.value != null
        ) {
            runCatching { BackgroundProtectionService.start(this) }
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (
            event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            event.eventType != AccessibilityEvent.TYPE_WINDOWS_CHANGED
        ) return

        val packageName = event.packageName?.toString()?.takeIf(String::isNotBlank) ?: return
        if (packageName == applicationContext.packageName || packageName == "com.android.systemui") return

        val repository = AppGraph.sessionRepository
        if (repository.session.value == null || repository.remainingMillis() <= 0L) {
            repository.clearIfExpired()
            return
        }

        val permissionGuard = PermissionGuard.shouldGuard(this, packageName)
        val selectedApp = repository.isPackageBlocked(packageName)
        if (!permissionGuard && !selectedApp) return

        val now = android.os.SystemClock.elapsedRealtime()
        if (lastBlockedPackage == packageName && now - lastBlockedAt < 650L) return
        lastBlockedPackage = packageName
        lastBlockedAt = now

        performGlobalAction(GLOBAL_ACTION_HOME)
        mainHandler.postDelayed({
            val intent = Intent(this, LockActivity::class.java).apply {
                addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK or
                        Intent.FLAG_ACTIVITY_CLEAR_TOP or
                        Intent.FLAG_ACTIVITY_SINGLE_TOP or
                        Intent.FLAG_ACTIVITY_NO_ANIMATION
                )
                putExtra(LockActivity.EXTRA_BLOCKED_PACKAGE, packageName)
                putExtra(LockActivity.EXTRA_PERMISSION_GUARD, permissionGuard)
            }
            runCatching { startActivity(intent) }
        }, 70L)
    }

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        AppGraph.permissionRepository.refresh()
        super.onDestroy()
    }

    companion object {
        fun isEnabled(context: Context): Boolean {
            val expected = ComponentName(context, AppBlockAccessibilityService::class.java)
            val enabledServices = Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false

            val splitter = TextUtils.SimpleStringSplitter(':')
            splitter.setString(enabledServices)
            while (splitter.hasNext()) {
                val enabledComponent = ComponentName.unflattenFromString(splitter.next())
                if (enabledComponent == expected) return true
            }
            return false
        }
    }
}
