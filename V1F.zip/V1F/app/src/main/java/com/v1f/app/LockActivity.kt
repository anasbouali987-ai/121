package com.v1f.app

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.v1f.app.ui.screens.MeteorLockScreen
import com.v1f.app.ui.theme.V1FTheme

class LockActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(androidx.core.view.WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }
        render(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        render(intent)
    }

    private fun render(intent: Intent) {
        val blockedPackage = intent.getStringExtra(EXTRA_BLOCKED_PACKAGE)
        val permissionGuard = intent.getBooleanExtra(EXTRA_PERMISSION_GUARD, false)
        val label = blockedPackage?.let { packageName ->
            runCatching {
                val info = packageManager.getApplicationInfo(packageName, 0)
                packageManager.getApplicationLabel(info).toString()
            }.getOrNull()
        }

        setContent {
            V1FTheme {
                MeteorLockScreen(
                    blockedAppLabel = label,
                    permissionGuard = permissionGuard,
                    onReturnHome = ::returnToLauncher
                )
            }
        }
    }

    private fun returnToLauncher() {
        startActivity(
            Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_HOME)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
        )
        finish()
    }

    companion object {
        const val EXTRA_BLOCKED_PACKAGE = "blocked_package"
        const val EXTRA_PERMISSION_GUARD = "permission_guard"
    }
}
