package com.v1f.app.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.v1f.app.AppGraph
import com.v1f.app.ui.theme.V1FColors
import com.v1f.app.util.formatDuration
import kotlinx.coroutines.delay

@Composable
fun MeteorLockScreen(
    blockedAppLabel: String?,
    permissionGuard: Boolean,
    onReturnHome: () -> Unit
) {
    var remaining by remember { mutableLongStateOf(AppGraph.sessionRepository.remainingMillis()) }

    BackHandler(onBack = onReturnHome)

    LaunchedEffect(Unit) {
        while (true) {
            remaining = AppGraph.sessionRepository.remainingMillis()
            if (remaining <= 0L) {
                AppGraph.sessionRepository.clearIfExpired()
                onReturnHome()
                break
            }
            delay(1_000L)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color.Black, Color(0xFF050208), Color.Black)
                )
            )
            .padding(horizontal = 28.dp),
        contentAlignment = Alignment.Center
    ) {
        BurnedMeteor(modifier = Modifier.fillMaxSize())

        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(70.dp))

            Box(
                modifier = Modifier
                    .size(48.dp)
                    .background(V1FColors.StrictRed.copy(alpha = 0.12f), RoundedCornerShape(16.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Rounded.Lock, null, tint = V1FColors.StrictRed)
            }

            Spacer(Modifier.height(18.dp))

            Text(
                text = if (permissionGuard) "صفحة الإعدادات مقفلة" else "${blockedAppLabel ?: "هذا التطبيق"} محظور",
                style = MaterialTheme.typography.headlineMedium,
                color = V1FColors.MoonWhite,
                textAlign = TextAlign.Center
            )

            Spacer(Modifier.height(8.dp))

            Text(
                text = if (permissionGuard) {
                    "لا يمكن الوصول إلى إعدادات إزالة الصلاحيات أثناء الجلسة الصارمة."
                } else {
                    "لقد اتخذت القرار مسبقًا. عد عندما ينتهي المؤقت."
                },
                style = MaterialTheme.typography.bodyLarge,
                color = V1FColors.TextSecondary,
                textAlign = TextAlign.Center
            )

            Spacer(Modifier.height(22.dp))

            Text(
                text = formatDuration(remaining),
                style = MaterialTheme.typography.displayMedium,
                color = V1FColors.MoonWhite
            )

            Spacer(Modifier.height(8.dp))
            Text("SESSION LOCKED", style = MaterialTheme.typography.labelLarge, color = V1FColors.StrictRed)

            Spacer(Modifier.height(34.dp))

            val interaction = remember { MutableInteractionSource() }
            Row(
                modifier = Modifier
                    .background(Color.White.copy(alpha = 0.055f), RoundedCornerShape(100.dp))
                    .clickable(interactionSource = interaction, indication = null, onClick = onReturnHome)
                    .padding(horizontal = 18.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(9.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Rounded.Home, null, tint = V1FColors.TextSecondary, modifier = Modifier.size(19.dp))
                Text("العودة إلى الشاشة الرئيسية", style = MaterialTheme.typography.labelLarge, color = V1FColors.TextSecondary)
            }
        }
    }
}

@Composable
private fun BurnedMeteor(modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "meteor")
    val pulse by transition.animateFloat(
        initialValue = 0.72f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1_900), RepeatMode.Reverse),
        label = "meteor-pulse"
    )
    val drift by transition.animateFloat(
        initialValue = -4f,
        targetValue = 4f,
        animationSpec = infiniteRepeatable(tween(4_800, easing = LinearEasing), RepeatMode.Reverse),
        label = "meteor-drift"
    )

    Canvas(modifier) {
        val center = Offset(size.width * 0.5f + drift, size.height * 0.31f)
        drawMeteor(center, pulse)
    }
}

private fun DrawScope.drawMeteor(center: Offset, pulse: Float) {
    rotate(-34f, pivot = center) {
        drawLine(
            brush = Brush.linearGradient(
                listOf(Color.Transparent, V1FColors.DeepRed.copy(alpha = 0.25f), V1FColors.StrictRed.copy(alpha = 0.72f)),
                start = Offset(center.x - 180f, center.y),
                end = center
            ),
            start = Offset(center.x - 190f, center.y),
            end = Offset(center.x - 20f, center.y),
            strokeWidth = 34f * pulse
        )
        drawLine(
            brush = Brush.linearGradient(
                listOf(Color.Transparent, V1FColors.Ember.copy(alpha = 0.82f)),
                start = Offset(center.x - 155f, center.y),
                end = center
            ),
            start = Offset(center.x - 150f, center.y),
            end = Offset(center.x - 13f, center.y),
            strokeWidth = 8f * pulse
        )

        drawCircle(V1FColors.StrictRed.copy(alpha = 0.14f * pulse), radius = 54f, center = center)
        drawCircle(V1FColors.Ember.copy(alpha = 0.20f * pulse), radius = 35f, center = center)

        val rock = Path().apply {
            moveTo(center.x - 22f, center.y - 9f)
            lineTo(center.x - 5f, center.y - 25f)
            lineTo(center.x + 21f, center.y - 15f)
            lineTo(center.x + 28f, center.y + 7f)
            lineTo(center.x + 10f, center.y + 25f)
            lineTo(center.x - 15f, center.y + 19f)
            close()
        }
        drawPath(
            rock,
            brush = Brush.radialGradient(
                listOf(V1FColors.Ember, Color(0xFF5A1B13), Color(0xFF110707)),
                center = Offset(center.x - 4f, center.y - 8f),
                radius = 55f
            )
        )
        drawCircle(Color.White.copy(alpha = 0.78f * pulse), radius = 4.5f, center = Offset(center.x - 4f, center.y - 8f))
    }
}
