# 121 — Box64 Surgical Extractor

تطبيق Android صغير لاستخراج `bin/box64` من `GTAV_Runtime_Package.zip` والتحقق منه ثم ضغطه وتقسيمه إلى أجزاء آمنة للرفع عبر واجهة GitHub.

## ماذا ينتج؟

- إذا أصبح ZIP أقل من أو يساوي 24 MiB: `box64_bundle.zip`
- إذا بقي أكبر: `box64_bundle.zip.001`, `.002`, ...
- دائمًا: `box64_bundle.json`

داخل الأرشيف يوجد:

- `libbox64.so`
- `box64_payload.json`

## ضمانات التحقق

- يقرأ الحجم وبصمة SHA-256 من `runtime_manifest.json`.
- يرفض الملف إذا اختلف الحجم أو البصمة.
- يتحقق من ترويسة ELF ومن أن `e_machine = AArch64 (183)`.
- كل جزء يحصل على SHA-256 مستقل في `box64_bundle.json`.

## إعادة التجميع في GitHub Actions

```bash
cat box64_bundle.zip.* > box64_bundle.zip  # فقط إذا كان مقسمًا
unzip -p box64_bundle.zip libbox64.so > app/src/main/jniLibs/arm64-v8a/libbox64.so
```

بعدها يجب مقارنة SHA-256 مع `payload_sha256` داخل `box64_bundle.json` قبل بناء APK.
