# 121 — GTAV Runtime Multipart Splitter v2

تطبيق Android يقسم `GTAV_Runtime_Package.zip` **بايتًا مقابل بايت** إلى أجزاء آمنة للرفع من متصفح GitHub.

## الناتج

- `GTAV_Runtime_Package.zip.001`
- `GTAV_Runtime_Package.zip.002`
- ...
- `GTAV_Runtime_Package.parts.json`
- `GTAV_Runtime_Package.zip.sha256`

الحد لكل جزء هو **24,000,000 بايت**، أي أقل بهامش واضح من حد GitHub البالغ 25 MiB عند الرفع عبر المتصفح.

## الضمانات

- يقرأ `runtime_manifest.json` ويتحقق من وجود RootFS المذكور فيه.
- لا يحمل Runtime كاملًا في الذاكرة؛ التقسيم Streaming.
- يحسب SHA-256 للحزمة الأصلية ولكل جزء أثناء القراءة نفسها.
- يحذف الأجزاء الجديدة تلقائيًا إذا فشلت العملية قبل اكتمالها.
- يستبدل ملفات الأجزاء القديمة التي تحمل الاسم نفسه في المجلد المختار.

## إعادة التجميع

لا تعتمد على ترتيب عشوائي. استخدم المصفوفة `parts` داخل `GTAV_Runtime_Package.parts.json` ثم تحقق من SHA-256 لكل جزء والحزمة الكاملة.

الـWorkflow المرفق `VX_Build_Multipart.yml` يقوم بذلك تلقائيًا.
