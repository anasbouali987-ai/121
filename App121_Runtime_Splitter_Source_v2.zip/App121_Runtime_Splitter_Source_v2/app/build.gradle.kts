plugins {
    id("com.android.application")
}

android {
    namespace = "com.gtavtools.app121"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.gtavtools.app121"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "2.0.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
}
