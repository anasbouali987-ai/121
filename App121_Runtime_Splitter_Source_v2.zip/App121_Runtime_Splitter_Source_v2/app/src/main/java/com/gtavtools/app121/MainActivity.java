package com.gtavtools.app121;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * 121 Runtime Multipart Splitter.
 *
 * Splits GTAV_Runtime_Package.zip byte-for-byte into browser-upload-safe parts.
 * The parts are raw segments, not independent ZIP archives. GitHub Actions
 * restores the exact original ZIP using the generated JSON manifest.
 */
public final class MainActivity extends Activity {
    private static final int PICK_RUNTIME = 1211;
    private static final int PICK_OUTPUT_TREE = 1212;

    // GitHub browser uploads are limited to 25 MiB per file. Keep a clear margin.
    private static final long PART_LIMIT_BYTES = 24_000_000L;
    private static final long GITHUB_BROWSER_LIMIT_BYTES = 25L * 1024L * 1024L;
    private static final int IO_BUFFER_BYTES = 1_000_000;
    private static final int MAX_MANIFEST_BYTES = 4 * 1024 * 1024;

    private static final String OUTPUT_BASE_NAME = "GTAV_Runtime_Package.zip";
    private static final String PARTS_MANIFEST_NAME = "GTAV_Runtime_Package.parts.json";
    private static final String CHECKSUM_NAME = "GTAV_Runtime_Package.zip.sha256";
    private static final String TOOL_REVISION = "app121-runtime-splitter-v2.0-r1";

    private Uri runtimeUri;
    private Uri outputTreeUri;
    private TextView runtimeLabel;
    private TextView outputLabel;
    private TextView logView;
    private ProgressBar progress;
    private Button runButton;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(buildUi());
    }

    private View buildUi() {
        int pad = dp(18);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);
        root.setBackgroundColor(0xFFF7F7F7);

        TextView title = text("121", 36, true);
        title.setGravity(Gravity.CENTER_HORIZONTAL);
        root.addView(title, matchWrap());

        TextView subtitle = text("GTAV Runtime Multipart Splitter", 18, false);
        subtitle.setGravity(Gravity.CENTER_HORIZONTAL);
        subtitle.setTextColor(0xFF555555);
        root.addView(subtitle, matchWrap());

        TextView info = text(
                "يقسم GTAV_Runtime_Package.zip إلى أجزاء خام متتابعة، كل جزء أقل من حد رفع GitHub عبر المتصفح. " +
                "وينشئ ملف تحقق JSON يحتوي ترتيب الأجزاء وحجمها وبصمة SHA-256 لكل جزء وللحزمة الكاملة.",
                15, false);
        info.setPadding(0, dp(16), 0, dp(14));
        root.addView(info, matchWrap());

        Button chooseRuntime = button("1 — اختر GTAV_Runtime_Package.zip");
        chooseRuntime.setOnClickListener(v -> pickRuntime());
        root.addView(chooseRuntime, matchWrap());

        runtimeLabel = text("لم يتم اختيار الحزمة", 13, false);
        runtimeLabel.setTextColor(0xFF666666);
        root.addView(runtimeLabel, matchWrap());

        Button chooseOutput = button("2 — اختر مجلد حفظ الأجزاء");
        chooseOutput.setOnClickListener(v -> pickOutputTree());
        LinearLayout.LayoutParams outputParams = matchWrap();
        outputParams.topMargin = dp(10);
        root.addView(chooseOutput, outputParams);

        outputLabel = text("لم يتم اختيار المجلد", 13, false);
        outputLabel.setTextColor(0xFF666666);
        root.addView(outputLabel, matchWrap());

        runButton = button("3 — تحقق وقسّم إلى أجزاء GitHub");
        runButton.setEnabled(false);
        runButton.setOnClickListener(v -> startSplitting());
        LinearLayout.LayoutParams runParams = matchWrap();
        runParams.topMargin = dp(16);
        root.addView(runButton, runParams);

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setVisibility(View.GONE);
        LinearLayout.LayoutParams progressParams = new LinearLayout.LayoutParams(-1, dp(12));
        progressParams.topMargin = dp(14);
        root.addView(progress, progressParams);

        logView = text("جاهز.\nالحد المستخدم لكل جزء: " + human(PART_LIMIT_BYTES), 13, false);
        logView.setTextIsSelectable(true);
        logView.setPadding(dp(12), dp(12), dp(12), dp(12));
        logView.setBackgroundColor(0xFFFFFFFF);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(logView, new ScrollView.LayoutParams(-1, -2));
        LinearLayout.LayoutParams scrollParams = new LinearLayout.LayoutParams(-1, 0, 1f);
        scrollParams.topMargin = dp(14);
        root.addView(scroll, scrollParams);
        return root;
    }

    private void pickRuntime() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/zip");
        intent.putExtra(Intent.EXTRA_MIME_TYPES,
                new String[]{"application/zip", "application/octet-stream", "application/x-zip-compressed"});
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, PICK_RUNTIME);
    }

    private void pickOutputTree() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION |
                Intent.FLAG_GRANT_WRITE_URI_PERMISSION |
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION |
                Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
        startActivityForResult(intent, PICK_OUTPUT_TREE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;

        Uri uri = data.getData();
        int flags = data.getFlags() &
                (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        try {
            getContentResolver().takePersistableUriPermission(uri, flags);
        } catch (SecurityException ignored) {
            // Some document providers grant access only for the current process.
        }

        if (requestCode == PICK_RUNTIME) {
            runtimeUri = uri;
            FileMetadata metadata = queryMetadata(uri);
            runtimeLabel.setText(metadata.displayName + " — " +
                    (metadata.sizeBytes >= 0 ? human(metadata.sizeBytes) : "حجم غير معروف"));
        } else if (requestCode == PICK_OUTPUT_TREE) {
            outputTreeUri = uri;
            outputLabel.setText(uri.toString());
        }
        runButton.setEnabled(runtimeUri != null && outputTreeUri != null);
    }

    private void startSplitting() {
        runButton.setEnabled(false);
        progress.setVisibility(View.VISIBLE);
        progress.setIndeterminate(true);
        progress.setProgress(0);
        logView.setText("");

        worker.execute(() -> {
            List<Uri> createdDocuments = new ArrayList<>();
            try {
                append("أداة: " + TOOL_REVISION);
                append("فحص بنية حزمة Runtime وقراءة manifest...");
                RuntimeInfo runtimeInfo = inspectRuntimePackage();
                append("✅ Runtime: " + runtimeInfo.runtimeId + " " + runtimeInfo.runtimeVersion);
                append("libc model: " + runtimeInfo.libcModel);
                if (!runtimeInfo.payloadPath.isEmpty()) {
                    append("RootFS payload: " + runtimeInfo.payloadPath);
                }

                FileMetadata sourceMetadata = queryMetadata(runtimeUri);
                long expectedSize = sourceMetadata.sizeBytes;
                runOnUiThread(() -> {
                    progress.setIndeterminate(expectedSize <= 0);
                    if (expectedSize > 0) progress.setProgress(5);
                });

                append("تقسيم الحزمة إلى أجزاء بحد " + human(PART_LIMIT_BYTES) + "...");
                SplitResult result = splitToOutput(runtimeInfo, expectedSize, createdDocuments);

                JSONObject partsManifest = buildPartsManifest(runtimeInfo, sourceMetadata, result);
                Uri manifestUri = writeTextDocument(
                        PARTS_MANIFEST_NAME,
                        "application/json",
                        partsManifest.toString(2) + "\n");
                createdDocuments.add(manifestUri);

                Uri checksumUri = writeTextDocument(
                        CHECKSUM_NAME,
                        "text/plain",
                        result.sourceSha256 + "  " + OUTPUT_BASE_NAME + "\n");
                createdDocuments.add(checksumUri);

                updateProgress(100);
                append("");
                append("✅ اكتملت العملية بنجاح");
                append("الحجم الكامل: " + human(result.totalBytes));
                append("عدد الأجزاء: " + result.parts.size());
                append("أكبر جزء: " + human(result.maxPartBytes));
                append("SHA-256 الكامل: " + result.sourceSha256);
                append("");
                append("ارفع إلى GitHub:");
                append("• جميع ملفات " + OUTPUT_BASE_NAME + ".001 وما بعدها");
                append("• " + PARTS_MANIFEST_NAME);
                append("• " + CHECKSUM_NAME + " (اختياري لكنه مفيد)");

                runOnUiThread(() -> Toast.makeText(
                        this,
                        "تم تقسيم Runtime إلى " + result.parts.size() + " أجزاء",
                        Toast.LENGTH_LONG).show());
            } catch (Throwable t) {
                cleanupDocuments(createdDocuments);
                fail(t.getClass().getSimpleName() + ": " + safeMessage(t));
            } finally {
                runOnUiThread(() -> runButton.setEnabled(runtimeUri != null && outputTreeUri != null));
            }
        });
    }

    private RuntimeInfo inspectRuntimePackage() throws Exception {
        byte[] manifestBytes = null;
        Set<String> entryNames = new HashSet<>();

        try (InputStream raw = require(getContentResolver().openInputStream(runtimeUri));
             ZipInputStream zip = new ZipInputStream(new BufferedInputStream(raw, IO_BUFFER_BYTES))) {
            ZipEntry entry;
            while ((entry = zip.getNextEntry()) != null) {
                String name = normalizeAndValidateZipPath(entry.getName());
                if (!name.isEmpty()) entryNames.add(name);

                if ("runtime_manifest.json".equals(name)) {
                    manifestBytes = readBounded(zip, MAX_MANIFEST_BYTES);
                }
                zip.closeEntry();
            }
        }

        if (manifestBytes == null) {
            throw new IllegalStateException("runtime_manifest.json غير موجود داخل الحزمة");
        }

        JSONObject manifest = new JSONObject(new String(manifestBytes, StandardCharsets.UTF_8));
        String runtimeId = manifest.optString("runtime_id", "").trim();
        String runtimeVersion = manifest.optString("version", "").trim();
        String libcModel = manifest.optString("libc_model", "unknown").trim();
        int schemaVersion = manifest.optInt("schema_version", 0);

        if (runtimeId.isEmpty()) throw new IllegalStateException("runtime_id غير موجود في manifest");
        if (runtimeVersion.isEmpty()) throw new IllegalStateException("version غير موجود في manifest");

        JSONObject payload = manifest.optJSONObject("rootfs_payload");
        String payloadPath = "";
        String payloadSha256 = "";
        long payloadSize = -1;
        if (payload != null) {
            payloadPath = normalizeAndValidateZipPath(payload.optString("path", ""));
            payloadSha256 = payload.optString("sha256", "").toLowerCase(Locale.US);
            payloadSize = payload.optLong("size_bytes", -1);
            if (payloadPath.isEmpty()) throw new IllegalStateException("rootfs_payload.path غير صالح");
            if (!entryNames.contains(payloadPath)) {
                throw new IllegalStateException("ملف RootFS المحدد في manifest غير موجود: " + payloadPath);
            }
            if (!payloadSha256.matches("[0-9a-f]{64}")) {
                throw new IllegalStateException("rootfs_payload.sha256 غير صالح");
            }
            if (payloadSize <= 0) throw new IllegalStateException("rootfs_payload.size_bytes غير صالح");
        }

        return new RuntimeInfo(
                runtimeId,
                runtimeVersion,
                libcModel,
                schemaVersion,
                payloadPath,
                payloadSha256,
                payloadSize,
                sha256(manifestBytes));
    }

    private SplitResult splitToOutput(
            RuntimeInfo runtimeInfo,
            long expectedSize,
            List<Uri> createdDocuments) throws Exception {
        MessageDigest fullDigest = MessageDigest.getInstance("SHA-256");
        List<PartInfo> parts = new ArrayList<>();
        byte[] buffer = new byte[IO_BUFFER_BYTES];
        long totalBytes = 0;
        long maxPartBytes = 0;
        int partIndex = 1;
        boolean endOfInput = false;

        try (InputStream input = new BufferedInputStream(
                require(getContentResolver().openInputStream(runtimeUri)), IO_BUFFER_BYTES)) {
            while (!endOfInput) {
                int firstRead = input.read(buffer);
                if (firstRead < 0) break;

                String partName = String.format(Locale.US, "%s.%03d", OUTPUT_BASE_NAME, partIndex);
                Uri partUri = createOrReplaceDocument(partName, "application/octet-stream");
                createdDocuments.add(partUri);

                MessageDigest partDigest = MessageDigest.getInstance("SHA-256");
                long partBytes = 0;

                try (OutputStream output = new BufferedOutputStream(
                        require(getContentResolver().openOutputStream(partUri, "w")), IO_BUFFER_BYTES)) {
                    int currentRead = firstRead;
                    while (currentRead >= 0) {
                        output.write(buffer, 0, currentRead);
                        partDigest.update(buffer, 0, currentRead);
                        fullDigest.update(buffer, 0, currentRead);
                        partBytes += currentRead;
                        totalBytes += currentRead;

                        if (expectedSize > 0) {
                            int value = 5 + (int) Math.min(85L, (totalBytes * 85L) / expectedSize);
                            updateProgress(value);
                        }
                        if (Thread.currentThread().isInterrupted()) {
                            throw new InterruptedException("تم إيقاف العملية");
                        }

                        long remaining = PART_LIMIT_BYTES - partBytes;
                        if (remaining <= 0) break;
                        int maxRead = (int) Math.min(buffer.length, remaining);
                        currentRead = input.read(buffer, 0, maxRead);
                        if (currentRead < 0) endOfInput = true;
                    }
                }

                if (partBytes <= 0 || partBytes > PART_LIMIT_BYTES) {
                    throw new IllegalStateException("حجم الجزء غير صالح: " + partName + " = " + partBytes);
                }

                String partSha = hex(partDigest.digest());
                parts.add(new PartInfo(partIndex, partName, partBytes, partSha));
                maxPartBytes = Math.max(maxPartBytes, partBytes);
                append("حُفظ: " + partName + " — " + human(partBytes) + " — " + shortHash(partSha));
                partIndex++;
            }
        }

        if (parts.isEmpty() || totalBytes <= 0) {
            throw new IllegalStateException("الحزمة فارغة أو تعذر قراءتها");
        }
        if (expectedSize > 0 && expectedSize != totalBytes) {
            throw new IllegalStateException("حجم القراءة لا يطابق حجم الملف: " + totalBytes + " != " + expectedSize);
        }

        long sum = 0;
        for (PartInfo part : parts) sum += part.sizeBytes;
        if (sum != totalBytes) throw new IllegalStateException("مجموع أحجام الأجزاء لا يطابق الحزمة");

        return new SplitResult(parts, totalBytes, maxPartBytes, hex(fullDigest.digest()));
    }

    private JSONObject buildPartsManifest(
            RuntimeInfo runtime,
            FileMetadata source,
            SplitResult result) throws Exception {
        JSONObject root = new JSONObject();
        root.put("schema_version", 2);
        root.put("format", "raw-byte-concatenation-v1");
        root.put("tool", "121 GTAV Runtime Multipart Splitter");
        root.put("tool_revision", TOOL_REVISION);
        root.put("source_display_name", source.displayName);
        root.put("reassembled_name", OUTPUT_BASE_NAME);
        root.put("source_size_bytes", result.totalBytes);
        root.put("source_sha256", result.sourceSha256);
        root.put("hash_algorithm", "SHA-256");
        root.put("part_size_limit_bytes", PART_LIMIT_BYTES);
        root.put("github_browser_limit_bytes", GITHUB_BROWSER_LIMIT_BYTES);
        root.put("part_count", result.parts.size());

        JSONObject runtimeObject = new JSONObject();
        runtimeObject.put("runtime_id", runtime.runtimeId);
        runtimeObject.put("runtime_version", runtime.runtimeVersion);
        runtimeObject.put("schema_version", runtime.schemaVersion);
        runtimeObject.put("libc_model", runtime.libcModel);
        runtimeObject.put("runtime_manifest_sha256", runtime.runtimeManifestSha256);
        if (!runtime.payloadPath.isEmpty()) {
            JSONObject payload = new JSONObject();
            payload.put("path", runtime.payloadPath);
            payload.put("size_bytes", runtime.payloadSize);
            payload.put("sha256", runtime.payloadSha256);
            runtimeObject.put("rootfs_payload", payload);
        }
        root.put("runtime", runtimeObject);

        JSONArray partsArray = new JSONArray();
        for (PartInfo part : result.parts) {
            JSONObject item = new JSONObject();
            item.put("index", part.index);
            item.put("name", part.name);
            item.put("size_bytes", part.sizeBytes);
            item.put("sha256", part.sha256);
            partsArray.put(item);
        }
        root.put("parts", partsArray);
        root.put("reassembly_command", "cat GTAV_Runtime_Package.zip.* > GTAV_Runtime_Package.zip");
        root.put("workflow_note", "GitHub Actions must concatenate parts in the JSON array order and verify every SHA-256.");
        return root;
    }

    private Uri writeTextDocument(String name, String mimeType, String text) throws Exception {
        Uri uri = createOrReplaceDocument(name, mimeType);
        try (OutputStream out = new BufferedOutputStream(
                require(getContentResolver().openOutputStream(uri, "w")))) {
            out.write(text.getBytes(StandardCharsets.UTF_8));
        }
        append("حُفظ: " + name);
        return uri;
    }

    private Uri createOrReplaceDocument(String name, String mimeType) throws Exception {
        ContentResolver resolver = getContentResolver();
        String treeId = DocumentsContract.getTreeDocumentId(outputTreeUri);
        Uri parentUri = DocumentsContract.buildDocumentUriUsingTree(outputTreeUri, treeId);
        Uri childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(outputTreeUri, treeId);

        try (Cursor cursor = resolver.query(
                childrenUri,
                new String[]{
                        DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                        DocumentsContract.Document.COLUMN_DISPLAY_NAME
                },
                null,
                null,
                null)) {
            if (cursor != null) {
                int idColumn = cursor.getColumnIndexOrThrow(
                        DocumentsContract.Document.COLUMN_DOCUMENT_ID);
                int nameColumn = cursor.getColumnIndexOrThrow(
                        DocumentsContract.Document.COLUMN_DISPLAY_NAME);
                while (cursor.moveToNext()) {
                    if (name.equals(cursor.getString(nameColumn))) {
                        Uri existing = DocumentsContract.buildDocumentUriUsingTree(
                                outputTreeUri, cursor.getString(idColumn));
                        if (!DocumentsContract.deleteDocument(resolver, existing)) {
                            throw new IllegalStateException("تعذر استبدال الملف الموجود: " + name);
                        }
                        break;
                    }
                }
            }
        }

        Uri created = DocumentsContract.createDocument(resolver, parentUri, mimeType, name);
        if (created == null) throw new IllegalStateException("تعذر إنشاء " + name);
        return created;
    }

    private void cleanupDocuments(List<Uri> documents) {
        ContentResolver resolver = getContentResolver();
        for (int i = documents.size() - 1; i >= 0; i--) {
            try {
                DocumentsContract.deleteDocument(resolver, documents.get(i));
            } catch (Throwable ignored) {
            }
        }
    }

    private FileMetadata queryMetadata(Uri uri) {
        String name = "GTAV_Runtime_Package.zip";
        long size = -1;
        try (Cursor cursor = getContentResolver().query(
                uri,
                new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE},
                null,
                null,
                null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int nameColumn = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                int sizeColumn = cursor.getColumnIndex(OpenableColumns.SIZE);
                if (nameColumn >= 0 && !cursor.isNull(nameColumn)) name = cursor.getString(nameColumn);
                if (sizeColumn >= 0 && !cursor.isNull(sizeColumn)) size = cursor.getLong(sizeColumn);
            }
        } catch (Throwable ignored) {
        }
        return new FileMetadata(name, size);
    }

    private static byte[] readBounded(InputStream input, int limit) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream(Math.min(limit, 64 * 1024));
        byte[] buffer = new byte[64 * 1024];
        int total = 0;
        int read;
        while ((read = input.read(buffer)) >= 0) {
            total += read;
            if (total > limit) throw new IllegalStateException("runtime_manifest.json أكبر من الحد الآمن");
            out.write(buffer, 0, read);
        }
        return out.toByteArray();
    }

    private static String normalizeAndValidateZipPath(String input) {
        if (input == null || input.isEmpty()) return "";
        String name = input.replace('\\', '/');
        if (name.startsWith("/")) {
            throw new SecurityException("مسار مطلق غير آمن داخل ZIP: " + input);
        }
        String[] segments = name.split("/", -1);
        for (String segment : segments) {
            if ("..".equals(segment)) {
                throw new SecurityException("مسار غير آمن داخل ZIP: " + input);
            }
        }
        return name;
    }

    private static String sha256(byte[] data) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        return hex(digest.digest(data));
    }

    private static String hex(byte[] bytes) {
        StringBuilder out = new StringBuilder(bytes.length * 2);
        for (byte value : bytes) out.append(String.format(Locale.US, "%02x", value & 0xFF));
        return out.toString();
    }

    private static String shortHash(String hash) {
        return hash.length() >= 12 ? hash.substring(0, 12) + "…" : hash;
    }

    private static <T> T require(T value) {
        if (value == null) throw new IllegalStateException("تعذر فتح الملف أو المجلد");
        return value;
    }

    private void append(String line) {
        runOnUiThread(() -> logView.append(line + "\n"));
    }

    private void updateProgress(int value) {
        runOnUiThread(() -> {
            progress.setIndeterminate(false);
            progress.setProgress(Math.max(0, Math.min(100, value)));
        });
    }

    private void fail(String message) {
        append("❌ " + message);
        runOnUiThread(() -> {
            progress.setVisibility(View.GONE);
            runButton.setEnabled(runtimeUri != null && outputTreeUri != null);
            Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        });
    }

    private static String safeMessage(Throwable throwable) {
        String message = throwable.getMessage();
        return message == null || message.trim().isEmpty() ? throwable.toString() : message;
    }

    private static String human(long bytes) {
        if (bytes < 0) return "غير معروف";
        if (bytes < 1000) return bytes + " B";
        double value = bytes;
        String[] units = {"KB", "MB", "GB", "TB"};
        int unit = -1;
        do {
            value /= 1000.0;
            unit++;
        } while (value >= 1000 && unit < units.length - 1);
        return String.format(Locale.US, "%.2f %s", value, units[unit]);
    }

    private TextView text(String value, int sp, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(sp);
        view.setTextColor(0xFF111111);
        if (bold) view.setTypeface(view.getTypeface(), android.graphics.Typeface.BOLD);
        return view;
    }

    private Button button(String value) {
        Button button = new Button(this);
        button.setText(value);
        button.setAllCaps(false);
        return button;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(-1, -2);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onDestroy() {
        worker.shutdownNow();
        super.onDestroy();
    }

    private static final class FileMetadata {
        final String displayName;
        final long sizeBytes;

        FileMetadata(String displayName, long sizeBytes) {
            this.displayName = displayName;
            this.sizeBytes = sizeBytes;
        }
    }

    private static final class RuntimeInfo {
        final String runtimeId;
        final String runtimeVersion;
        final String libcModel;
        final int schemaVersion;
        final String payloadPath;
        final String payloadSha256;
        final long payloadSize;
        final String runtimeManifestSha256;

        RuntimeInfo(
                String runtimeId,
                String runtimeVersion,
                String libcModel,
                int schemaVersion,
                String payloadPath,
                String payloadSha256,
                long payloadSize,
                String runtimeManifestSha256) {
            this.runtimeId = runtimeId;
            this.runtimeVersion = runtimeVersion;
            this.libcModel = libcModel;
            this.schemaVersion = schemaVersion;
            this.payloadPath = payloadPath;
            this.payloadSha256 = payloadSha256;
            this.payloadSize = payloadSize;
            this.runtimeManifestSha256 = runtimeManifestSha256;
        }
    }

    private static final class PartInfo {
        final int index;
        final String name;
        final long sizeBytes;
        final String sha256;

        PartInfo(int index, String name, long sizeBytes, String sha256) {
            this.index = index;
            this.name = name;
            this.sizeBytes = sizeBytes;
            this.sha256 = sha256;
        }
    }

    private static final class SplitResult {
        final List<PartInfo> parts;
        final long totalBytes;
        final long maxPartBytes;
        final String sourceSha256;

        SplitResult(List<PartInfo> parts, long totalBytes, long maxPartBytes, String sourceSha256) {
            this.parts = parts;
            this.totalBytes = totalBytes;
            this.maxPartBytes = maxPartBytes;
            this.sourceSha256 = sourceSha256;
        }
    }
}
