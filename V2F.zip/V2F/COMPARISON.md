# Fair comparison of the three V2 experiments

## Experiment 1 — V2-source.zip

**Best ideas**
- Clear generic Protection Engine terminology.
- Simple lifecycle and dispatch model.
- Strong documentation and baseline awareness.

**Problem corrected in V2F**
- Its Settings guard treated the entire Settings package and several window events as dangerous, recreating the broad Settings lock that V2 was meant to remove.

## Experiment 2 — V2(1).zip

**Best ideas**
- Strongest module-oriented engine contract.
- Separate app guard and Settings guard modules.
- Explicit engine state and clean AppGraph integration.

**Problem corrected in V2F**
- It added window/page analysis, language variants, class names, view IDs and broad sensitive controls, contrary to the final exact UI-click-only decision.

## Experiment 3 — V2.zip

**Best ideas**
- Best testability: it separated a pure classifier and included unit tests.
- Clean `ProtectionGuard` abstraction and preserved app blocking as a module.
- Good duplicate-event protection.

**Problem corrected in V2F**
- It still scanned full Settings surfaces and classified activities/pages. Its action also returned Home rather than performing the agreed hidden three-Back sequence.

## V2F synthesis

V2F keeps:
- Experiment 1's generic long-term engine vision.
- Experiment 2's modular lifecycle and AppGraph integration.
- Experiment 3's pure testable matching layer.

It then applies the final user-approved rules exactly:
- V1F is the baseline.
- No visible V2 controls.
- `com.android.settings` only.
- `TYPE_VIEW_CLICKED` only.
- Exact case-sensitive configured labels only.
- Meteor overlay plus Back ×3 separated by 250 ms.
- No window, page, Activity, OCR or full-tree detection.
