# V2F — Celestial Focus

V2F is the approved V1F baseline plus the first extensible **Protection Engine** module.
The visible V1F interface, app picker, timer, strict session, foreground service and meteor lock screen are preserved.

## What V2F adds

- A generic, background-only `ProtectionEngine`.
- `AppGuardModule`, preserving V1F application blocking.
- `SettingsClickGuardModule`, enabled only during an active strict session.
- Exact UI-click matching only inside `com.android.settings`.
- A full-screen accessibility meteor shield while Back is executed three times, 250 ms apart.
- No Protection Engine card, switch, page or visible configuration.
- Central editable rule file: `SettingsClickGuardConfig.kt`.
- Pure unit tests for package filtering and exact label matching.

## Important behavior

Ordinary Settings pages remain available. The guard does not use window detection, Activity detection, OCR, page-tree scanning or broad Settings blocking. It reacts only to exact clicked labels configured in the rule file.

## Build

- Android Studio / JDK 17 / Android SDK 35, or the separate `build-any-zip.yml` workflow.
- Application ID remains `com.v1f.app`, so V2F is an update path from V1F when signed with the same key.
- Version: `2.0.0-F` (`versionCode 4`).
