# V2F State Machine

```text
SETUP_REQUIRED
  └─ منح 3 طبقات
       ↓
READY
  └─ اختيار التطبيقات
       ↓
APPS_SELECTED
  └─ OKAY
       ↓
DURATION_SELECTED
  └─ START + مراجعة نهائية
       ↓
SEALING (720 ms red transition)
       ↓
ACTIVE_STRICT_SESSION
  ├─ Protection Engine active silently
  ├─ SettingsClickGuard listens only to exact clicks in com.android.settings
  ├─ Selected apps blocked by AppGuardModule
  ├─ Foreground notification active
  └─ No in-app cancel action
       ↓ timer reaches zero
COMPLETED / READY
```

## Invariants

- A session cannot start with zero selected apps.
- A session cannot start unless the latest permission snapshot is 3/3.
- Duration must be between 60,000 ms and 86,400,000 ms.
- Protection Engine modules are dormant outside an active session.
- Settings clicks from every package except `com.android.settings` are ignored.
- UI never renders a Protection Engine setting or a cancel-session control.
