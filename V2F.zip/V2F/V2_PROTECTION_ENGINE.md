# Protection Engine — V2F

## Registered modules

1. **SettingsClickGuardModule**
   - Hidden and automatic.
   - Active only while the strict timer is active.
   - Target package: `com.android.settings`.
   - Event: `TYPE_VIEW_CLICKED` only.
   - Exact labels are stored in `SettingsClickGuardConfig.kt`.

2. **AppGuardModule**
   - Preserves selected-application blocking from V1F.

## Settings escape sequence

1. Display the black meteor accessibility overlay.
2. Wait 32 ms for the overlay to attach.
3. Execute Back.
4. Wait 250 ms.
5. Execute Back.
6. Wait 250 ms.
7. Execute Back.
8. Keep the shield visible for another 250 ms, then remove it.
9. If Android rejects a Back global action, Home is used as a fallback.

The overlay is non-focusable, so Back targets Settings underneath rather than closing the shield.
