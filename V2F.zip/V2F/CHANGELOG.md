# Changelog

## 2.0.0-F — V2F

- Added generic Protection Engine architecture.
- Added hidden Settings Click Guard module.
- Replaced V1F's full Settings-package blocking with exact click interception.
- Added editable centralized click-rule configuration.
- Added meteor accessibility overlay and three-step Back escape sequence.
- Added AppGuardModule to preserve V1 behavior inside the engine.
- Added pure matching unit tests.
- Preserved application ID `com.v1f.app` and all main V1F UI flows.
