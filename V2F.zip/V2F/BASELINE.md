# Official baseline

`V1F.zip` supplied by the user is the official product baseline.

V2F was built by copying that baseline and changing only the code needed to introduce Protection Engine and Settings Click Guard. The main interface, visual system and established V1 behavior were not replaced by any experiment.
