# Distribution notes

Before publishing, prepare declarations for:

- Accessibility Service usage. The disclosure must clearly explain foreground-app detection and app blocking.
- Broad package visibility (`QUERY_ALL_PACKAGES`). Installed-app inventory is used only to let the user choose apps to block.
- Foreground service `specialUse` subtype.
- Battery optimization exemption request.

Do not transmit, sell or use the installed-app inventory for advertising or analytics.
