package com.v1f.app.protection.modules.settings

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class SettingsClickMatcherTest {
    @Test
    fun everyConfiguredLabel_isMatchedExactlyInsideSettings() {
        SettingsClickGuardConfig.blockedLabels.forEach { label ->
            assertEquals(
                label,
                SettingsClickMatcher.match(
                    packageName = SettingsClickGuardConfig.TARGET_PACKAGE,
                    isViewClick = true,
                    clickedLabels = listOf(label)
                )
            )
        }
    }

    @Test
    fun sameLabelInAnotherApp_isIgnored() {
        assertNull(
            SettingsClickMatcher.match(
                packageName = "com.example.other",
                isViewClick = true,
                clickedLabels = listOf("Device admin")
            )
        )
    }

    @Test
    fun nonClickEvent_isIgnored() {
        assertNull(
            SettingsClickMatcher.match(
                packageName = SettingsClickGuardConfig.TARGET_PACKAGE,
                isViewClick = false,
                clickedLabels = listOf("Device admin")
            )
        )
    }

    @Test
    fun matchingIsCaseSensitiveAndDoesNotUsePartialText() {
        assertNull(SettingsClickMatcher.match(
            SettingsClickGuardConfig.TARGET_PACKAGE,
            true,
            listOf("device admin")
        ))
        assertNull(SettingsClickMatcher.match(
            SettingsClickGuardConfig.TARGET_PACKAGE,
            true,
            listOf("Open Device admin settings")
        ))
    }
}
