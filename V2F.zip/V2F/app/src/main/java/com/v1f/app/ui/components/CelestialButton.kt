package com.v1f.app.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import com.v1f.app.ui.theme.V1FColors
import com.v1f.app.ui.theme.V1FDimensions

@Composable
fun CelestialButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    strict: Boolean = false,
    showLock: Boolean = false
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed && enabled) 0.985f else 1f,
        label = "celestial-button-press"
    )
    val shape = RoundedCornerShape(V1FDimensions.ButtonRadius)
    val colors = when {
        !enabled -> listOf(Color.White.copy(alpha = 0.10f), Color.White.copy(alpha = 0.06f))
        strict -> listOf(V1FColors.StrictRed, V1FColors.DeepRed)
        else -> listOf(V1FColors.Violet.copy(alpha = 0.95f), V1FColors.Cyan.copy(alpha = 0.88f))
    }
    val contentColor = if (enabled) V1FColors.SpaceBlack else V1FColors.TextMuted

    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(59.dp)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .clip(shape)
            .background(Brush.horizontalGradient(colors))
            .border(
                1.dp,
                if (strict) V1FColors.Coral.copy(alpha = 0.72f) else Color.White.copy(alpha = 0.22f),
                shape
            )
            .clickable(
                enabled = enabled,
                interactionSource = interaction,
                indication = null,
                onClick = onClick
            )
            .padding(horizontal = 21.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = text, style = MaterialTheme.typography.labelLarge, color = contentColor)
        Icon(
            imageVector = if (showLock) Icons.Rounded.Lock else Icons.AutoMirrored.Rounded.ArrowForward,
            contentDescription = null,
            tint = contentColor
        )
    }
}
