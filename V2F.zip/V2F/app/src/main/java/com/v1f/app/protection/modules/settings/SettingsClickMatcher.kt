package com.v1f.app.protection.modules.settings

/** Pure matcher kept independent from Android so its exact rules are testable. */
internal object SettingsClickMatcher {
    fun match(
        packageName: String,
        isViewClick: Boolean,
        clickedLabels: Collection<String>
    ): String? {
        if (!isViewClick) return null
        if (packageName != SettingsClickGuardConfig.TARGET_PACKAGE) return null

        return clickedLabels
            .asSequence()
            .map(String::trim)
            .firstOrNull(SettingsClickGuardConfig.blockedLabels::contains)
    }
}
