package com.v1f.app.ui.screens

import android.Manifest
import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.AccessibilityNew
import androidx.compose.material.icons.outlined.AdminPanelSettings
import androidx.compose.material.icons.outlined.BatterySaver
import androidx.compose.material.icons.outlined.ShieldMoon
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.v1f.app.AppGraph
import com.v1f.app.admin.V1FDeviceAdminReceiver
import com.v1f.app.model.PermissionSnapshot
import com.v1f.app.service.BackgroundProtectionService
import com.v1f.app.ui.components.CelestialButton
import com.v1f.app.ui.components.GlassSurface
import com.v1f.app.ui.components.PermissionTile
import com.v1f.app.ui.components.StatusPill
import com.v1f.app.ui.theme.V1FColors
import com.v1f.app.ui.theme.V1FDimensions

@Composable
fun PermissionsScreen(
    snapshot: PermissionSnapshot,
    sessionActive: Boolean,
    onBack: () -> Unit,
    onContinue: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)
    val context = LocalContext.current
    val backInteraction = remember { MutableInteractionSource() }

    val settingsLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { AppGraph.permissionRepository.refresh() }

    val notificationLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) {
        AppGraph.permissionRepository.markBackgroundRequested(true)
        BackgroundProtectionService.start(context)
        requestBatteryExemption(context) { settingsLauncher.launch(it) }
    }

    val strictAccent = if (sessionActive) V1FColors.StrictRed else V1FColors.Cyan

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = V1FDimensions.ScreenHorizontal)
            .padding(top = 18.dp, bottom = 30.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Outlined.ArrowBack,
                contentDescription = "رجوع",
                tint = V1FColors.MoonWhite,
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .clickable(
                        interactionSource = backInteraction,
                        indication = null,
                        onClick = onBack
                    )
                    .padding(8.dp)
            )
            StatusPill(
                text = if (sessionActive) "مقفلة أثناء الجلسة" else "${snapshot.completedCount} من 3",
                accent = if (sessionActive) V1FColors.StrictRed else if (snapshot.allReady) V1FColors.Mint else V1FColors.Gold
            )
        }

        Spacer(Modifier.height(25.dp))

        Icon(
            imageVector = if (sessionActive) Icons.Rounded.Lock else Icons.Outlined.ShieldMoon,
            contentDescription = null,
            tint = if (sessionActive) V1FColors.StrictRed else V1FColors.VioletSoft,
            modifier = Modifier.size(52.dp).align(Alignment.CenterHorizontally)
        )

        Spacer(Modifier.height(15.dp))

        Text(
            text = if (sessionActive) "طبقات الحماية مقفلة" else "جميع الصلاحيات",
            style = MaterialTheme.typography.displaySmall,
            color = V1FColors.MoonWhite,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(8.dp))

        Text(
            text = if (sessionActive) {
                "لا يمكن تعديل أو إزالة طبقات الحماية من داخل التطبيق حتى ينتهي العداد. كما تُحجب صفحات الإعدادات الحساسة أثناء الجلسة."
            } else {
                "فعّل الطبقات الثلاث لتشغيل اختيار التطبيقات والحظر الصارم."
            },
            style = MaterialTheme.typography.bodyLarge,
            color = V1FColors.TextSecondary,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(22.dp))

        GlassSurface(
            modifier = Modifier.fillMaxWidth(),
            padding = PaddingValues(17.dp),
            elevated = true,
            accent = if (sessionActive) V1FColors.StrictRed else null,
            pulseAccent = sessionActive
        ) {
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = if (sessionActive) "الجلسة الصارمة تحمي الصلاحيات" else "اكتملت ${snapshot.completedCount} من 3 طبقات",
                    style = MaterialTheme.typography.titleMedium,
                    color = V1FColors.MoonWhite,
                    modifier = Modifier.weight(1f)
                )
                Text(
                    text = if (sessionActive) "LOCKED" else "${snapshot.completedCount} / 3",
                    style = MaterialTheme.typography.labelLarge,
                    color = if (sessionActive) V1FColors.StrictRed else V1FColors.Gold
                )
            }
        }

        Spacer(Modifier.height(14.dp))

        PermissionTile(
            icon = Icons.Outlined.AccessibilityNew,
            title = "إمكانية الوصول",
            description = if (snapshot.accessibilityEnabled) "مراقبة التطبيقات وتنفيذ شاشة الحظر جاهزة." else "مطلوبة لاكتشاف التطبيق المفتوح وتنفيذ الحظر.",
            accent = V1FColors.Cyan,
            status = when {
                sessionActive -> "مقفلة"
                snapshot.accessibilityEnabled -> "مفعلة"
                else -> "تفعيل"
            },
            enabled = snapshot.accessibilityEnabled,
            locked = sessionActive,
            onClick = {
                settingsLauncher.launch(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(12.dp))

        PermissionTile(
            icon = Icons.Outlined.AdminPanelSettings,
            title = "إدارة الجهاز",
            description = if (snapshot.deviceAdminEnabled) "طبقة الإدارة وحماية الإزالة جاهزة." else "تضيف حاجزًا إضافيًا ضد إزالة التطبيق أثناء الجلسة.",
            accent = V1FColors.VioletSoft,
            status = when {
                sessionActive -> "مقفلة"
                snapshot.deviceAdminEnabled -> "مفعلة"
                else -> "تفعيل"
            },
            enabled = snapshot.deviceAdminEnabled,
            locked = sessionActive,
            onClick = {
                val admin = ComponentName(context, V1FDeviceAdminReceiver::class.java)
                settingsLauncher.launch(
                    Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                        putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin)
                        putExtra(
                            DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                            "تُستخدم هذه الطبقة لزيادة صرامة جلسة الحظر وحماية التطبيق من الإزالة السريعة."
                        )
                    }
                )
            },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(12.dp))

        PermissionTile(
            icon = Icons.Outlined.BatterySaver,
            title = "العمل في الخلفية",
            description = backgroundDescription(snapshot),
            accent = V1FColors.Mint,
            status = when {
                sessionActive -> "مقفلة"
                snapshot.backgroundReady -> "مفعلة"
                else -> "تفعيل"
            },
            enabled = snapshot.backgroundReady,
            locked = sessionActive,
            onClick = {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !snapshot.notificationsAllowed) {
                    notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                } else {
                    AppGraph.permissionRepository.markBackgroundRequested(true)
                    BackgroundProtectionService.start(context)
                    requestBatteryExemption(context) { settingsLauncher.launch(it) }
                }
            },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(22.dp))

        if (!sessionActive) {
            CelestialButton(
                text = if (snapshot.allReady) "اختيار التطبيقات" else "أكمل الصلاحيات أولًا",
                onClick = onContinue,
                enabled = snapshot.allReady
            )
        } else {
            GlassSurface(
                modifier = Modifier.fillMaxWidth(),
                padding = PaddingValues(16.dp),
                accent = V1FColors.StrictRed,
                pulseAccent = true
            ) {
                Text(
                    "لا يوجد زر تعطيل أثناء الحظر. تنتهي الحماية تلقائيًا عند وصول العداد إلى الصفر.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = V1FColors.TextSecondary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        Spacer(Modifier.height(18.dp))

        Text(
            text = "ملاحظة: بعض الشركات تضيف إعدادات بطارية خاصة بها؛ قد تحتاج إلى السماح بالتشغيل التلقائي من إعدادات الهاتف.",
            style = MaterialTheme.typography.bodySmall,
            color = V1FColors.TextMuted,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

private fun backgroundDescription(snapshot: PermissionSnapshot): String = when {
    snapshot.backgroundReady && snapshot.batteryOptimizationIgnored -> "الإشعار الدائم واستثناء البطارية جاهزان."
    !snapshot.notificationsAllowed -> "اسمح بالإشعارات حتى تظهر خدمة الحماية بوضوح."
    !snapshot.backgroundServiceRunning -> "شغّل خدمة الحماية المستمرة."
    snapshot.backgroundReady && !snapshot.batteryOptimizationIgnored -> "الخدمة تعمل. استثناء البطارية مستحسن لثبات أعلى."
    !snapshot.batteryOptimizationIgnored -> "شغّل الخدمة ثم استثن التطبيق من تحسين البطارية."
    else -> "أكمل إعداد العمل في الخلفية."
}

private fun requestBatteryExemption(
    context: Context,
    launch: (Intent) -> Unit
) {
    val packageUri = Uri.parse("package:${context.packageName}")
    val directIntent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, packageUri)
    val fallbackIntent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
    val intent = if (directIntent.resolveActivity(context.packageManager) != null) directIntent else fallbackIntent
    launch(intent)
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}
