package com.v1f.app.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.v1f.app.AppGraph
import com.v1f.app.service.BackgroundProtectionService
import com.v1f.app.ui.background.CelestialSky
import com.v1f.app.ui.screens.AppSelectionScreen
import com.v1f.app.ui.screens.HomeScreen
import com.v1f.app.ui.screens.PermissionsScreen
import com.v1f.app.ui.screens.TimerScreen
import com.v1f.app.ui.theme.V1FMotion

private enum class V1FScreen {
    Home,
    Permissions,
    Applications,
    Timer
}

@Composable
fun V1FApp() {
    val session by AppGraph.sessionRepository.session.collectAsStateWithLifecycle()
    val permissions by AppGraph.permissionRepository.snapshot.collectAsStateWithLifecycle()

    var screen by remember { mutableStateOf(V1FScreen.Home) }
    var selectedPackages by remember { mutableStateOf<Set<String>>(emptySet()) }

    LaunchedEffect(session?.id) {
        if (session != null) {
            screen = V1FScreen.Home
            selectedPackages = emptySet()
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        CelestialSky(activeSession = session != null) {
            AnimatedContent(
                targetState = screen,
                transitionSpec = {
                    val duration = V1FMotion.ScreenTransition
                    val forward = targetState.ordinal > initialState.ordinal
                    val direction = if (forward) 1 else -1
                    (
                        slideInHorizontally(tween(duration)) { direction * it / 7 } +
                            fadeIn(tween(duration))
                        ) togetherWith (
                        slideOutHorizontally(tween(duration)) { -direction * it / 10 } +
                            fadeOut(tween(duration))
                        )
                },
                label = "v1f-screen"
            ) { destination ->
                val safeModifier = Modifier
                    .fillMaxSize()
                    .windowInsetsPadding(WindowInsets.systemBars)

                when (destination) {
                    V1FScreen.Home -> HomeScreen(
                        permissionSnapshot = permissions,
                        activeSession = session,
                        onOpenPermissions = { screen = V1FScreen.Permissions },
                        onPrimaryAction = {
                            screen = if (permissions.allReady) {
                                V1FScreen.Applications
                            } else {
                                V1FScreen.Permissions
                            }
                        },
                        modifier = safeModifier
                    )

                    V1FScreen.Permissions -> PermissionsScreen(
                        snapshot = permissions,
                        sessionActive = session != null,
                        onBack = { screen = V1FScreen.Home },
                        onContinue = {
                            if (permissions.allReady && session == null) {
                                screen = V1FScreen.Applications
                            }
                        },
                        modifier = safeModifier
                    )

                    V1FScreen.Applications -> AppSelectionScreen(
                        initialSelection = selectedPackages,
                        onBack = { screen = V1FScreen.Home },
                        onNext = {
                            selectedPackages = it
                            screen = V1FScreen.Timer
                        },
                        modifier = safeModifier
                    )

                    V1FScreen.Timer -> TimerScreen(
                        selectedPackages = selectedPackages,
                        onBack = { screen = V1FScreen.Applications },
                        onStart = { durationMillis ->
                            AppGraph.permissionRepository.refresh()
                            val latestPermissions = AppGraph.permissionRepository.snapshot.value
                            when {
                                selectedPackages.isEmpty() -> screen = V1FScreen.Applications
                                !latestPermissions.allReady -> screen = V1FScreen.Permissions
                                else -> {
                                    AppGraph.sessionRepository.startSession(
                                        blockedPackages = selectedPackages,
                                        durationMillis = durationMillis
                                    )
                                    AppGraph.permissionRepository.markBackgroundRequested(true)
                                    BackgroundProtectionService.start(AppGraph.application)
                                }
                            }
                        },
                        modifier = safeModifier
                    )
                }
            }
        }
    }
}
