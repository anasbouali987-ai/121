package com.v1f.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val V1FColorScheme = darkColorScheme(
    primary = V1FColors.Violet,
    onPrimary = V1FColors.MoonWhite,
    secondary = V1FColors.Cyan,
    onSecondary = V1FColors.SpaceBlack,
    tertiary = V1FColors.Mint,
    background = V1FColors.SpaceBlack,
    onBackground = V1FColors.MoonWhite,
    surface = V1FColors.DeepNight,
    onSurface = V1FColors.MoonWhite,
    error = V1FColors.Coral
)

@Composable
fun V1FTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = V1FColorScheme,
        typography = V1FTypography,
        content = content
    )
}
