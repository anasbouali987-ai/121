package com.v1f.app

import android.app.Application
import com.v1f.app.data.InstalledAppsRepository
import com.v1f.app.data.PermissionRepository
import com.v1f.app.data.SessionRepository
import com.v1f.app.protection.ProtectionEngine

object AppGraph {
    lateinit var application: Application
        private set

    lateinit var sessionRepository: SessionRepository
        private set

    lateinit var permissionRepository: PermissionRepository
        private set

    lateinit var installedAppsRepository: InstalledAppsRepository
        private set

    lateinit var protectionEngine: ProtectionEngine
        private set

    fun initialize(app: Application) {
        if (::application.isInitialized) return
        application = app
        sessionRepository = SessionRepository(app)
        permissionRepository = PermissionRepository(app)
        installedAppsRepository = InstalledAppsRepository(app)
        protectionEngine = ProtectionEngine(sessionRepository)
        protectionEngine.synchronize()
    }
}
