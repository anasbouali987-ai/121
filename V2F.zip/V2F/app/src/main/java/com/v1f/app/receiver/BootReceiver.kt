package com.v1f.app.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.v1f.app.AppGraph
import com.v1f.app.service.BackgroundProtectionService

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        AppGraph.protectionEngine.synchronize()
        val shouldRun = AppGraph.permissionRepository.isBackgroundRequested() ||
            AppGraph.sessionRepository.session.value != null
        if (shouldRun) {
            runCatching { BackgroundProtectionService.start(context) }
        }
    }
}
