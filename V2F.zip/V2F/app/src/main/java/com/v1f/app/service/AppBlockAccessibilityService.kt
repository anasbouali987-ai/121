package com.v1f.app.service

import android.accessibilityservice.AccessibilityService
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.text.TextUtils
import android.view.accessibility.AccessibilityEvent
import com.v1f.app.AppGraph
import com.v1f.app.LockActivity
import com.v1f.app.protection.ProtectionDecision
import com.v1f.app.protection.actions.SettingsEscapeGuard

class AppBlockAccessibilityService : AccessibilityService() {
    private val mainHandler = Handler(Looper.getMainLooper())
    private var settingsEscapeGuard: SettingsEscapeGuard? = null
    private var lastBlockedPackage: String? = null
    private var lastBlockedAt = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        settingsEscapeGuard = SettingsEscapeGuard(this)
        AppGraph.permissionRepository.refresh()
        AppGraph.protectionEngine.synchronize()
        if (
            AppGraph.permissionRepository.isBackgroundRequested() ||
            AppGraph.sessionRepository.session.value != null
        ) {
            runCatching { BackgroundProtectionService.start(this) }
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        when (val decision = AppGraph.protectionEngine.evaluate(event)) {
            ProtectionDecision.Allow -> Unit

            is ProtectionDecision.InterceptSettingsClick -> {
                // Hidden V2 action: no card, switch or settings page is exposed.
                settingsEscapeGuard?.trigger()
            }

            is ProtectionDecision.BlockApplication -> {
                showApplicationLock(decision.packageName)
            }
        }
    }

    private fun showApplicationLock(packageName: String) {
        if (packageName == applicationContext.packageName || packageName == "com.android.systemui") return

        val now = SystemClock.elapsedRealtime()
        if (lastBlockedPackage == packageName && now - lastBlockedAt < BLOCK_DEBOUNCE_MS) return
        lastBlockedPackage = packageName
        lastBlockedAt = now

        performGlobalAction(GLOBAL_ACTION_HOME)
        mainHandler.postDelayed({
            val intent = Intent(this, LockActivity::class.java).apply {
                addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK or
                        Intent.FLAG_ACTIVITY_CLEAR_TOP or
                        Intent.FLAG_ACTIVITY_SINGLE_TOP or
                        Intent.FLAG_ACTIVITY_NO_ANIMATION
                )
                putExtra(LockActivity.EXTRA_BLOCKED_PACKAGE, packageName)
            }
            runCatching { startActivity(intent) }
        }, LOCK_SCREEN_DELAY_MS)
    }

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        settingsEscapeGuard?.close()
        settingsEscapeGuard = null
        AppGraph.protectionEngine.stop()
        AppGraph.permissionRepository.refresh()
        super.onDestroy()
    }

    companion object {
        private const val BLOCK_DEBOUNCE_MS = 650L
        private const val LOCK_SCREEN_DELAY_MS = 70L

        fun isEnabled(context: Context): Boolean {
            val expected = ComponentName(context, AppBlockAccessibilityService::class.java)
            val enabledServices = Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false

            val splitter = TextUtils.SimpleStringSplitter(':')
            splitter.setString(enabledServices)
            while (splitter.hasNext()) {
                val enabledComponent = ComponentName.unflattenFromString(splitter.next())
                if (enabledComponent == expected) return true
            }
            return false
        }
    }
}
