package com.v1f.app.data

import android.content.Context
import android.os.SystemClock
import android.provider.Settings
import com.v1f.app.model.ActiveSession
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

class SessionRepository(private val context: Context) {
    private val preferences = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private val _session = MutableStateFlow(loadSession())
    val session: StateFlow<ActiveSession?> = _session.asStateFlow()

    init {
        normalizeAfterBootIfNeeded()
        clearIfExpired()
    }

    fun startSession(blockedPackages: Set<String>, durationMillis: Long): ActiveSession {
        require(blockedPackages.isNotEmpty())
        require(durationMillis in MIN_DURATION..MAX_DURATION)

        val nowElapsed = SystemClock.elapsedRealtime()
        val activeSession = ActiveSession(
            id = UUID.randomUUID().toString(),
            blockedPackages = blockedPackages,
            durationMillis = durationMillis,
            remainingAtCheckpointMillis = durationMillis,
            checkpointElapsedRealtime = nowElapsed,
            checkpointBootCount = currentBootCount(),
            startedAtEpochMillis = System.currentTimeMillis()
        )
        persist(activeSession)
        _session.value = activeSession
        return activeSession
    }

    fun remainingMillis(): Long {
        val activeSession = _session.value ?: return 0L
        val currentBoot = currentBootCount()
        val remaining = if (currentBoot == activeSession.checkpointBootCount) {
            activeSession.remainingAtCheckpointMillis -
                (SystemClock.elapsedRealtime() - activeSession.checkpointElapsedRealtime)
        } else {
            activeSession.remainingAtCheckpointMillis
        }
        return remaining.coerceAtLeast(0L)
    }

    fun checkpoint(): Long {
        val activeSession = _session.value ?: return 0L
        val remaining = remainingMillis()
        if (remaining <= 0L) {
            clearSession()
            return 0L
        }
        val updated = activeSession.copy(
            remainingAtCheckpointMillis = remaining,
            checkpointElapsedRealtime = SystemClock.elapsedRealtime(),
            checkpointBootCount = currentBootCount()
        )
        persist(updated)
        _session.value = updated
        return remaining
    }

    fun isPackageBlocked(packageName: String): Boolean {
        val activeSession = _session.value ?: return false
        if (remainingMillis() <= 0L) {
            clearSession()
            return false
        }
        return packageName in activeSession.blockedPackages
    }

    fun clearIfExpired(): Boolean {
        if (_session.value != null && remainingMillis() <= 0L) {
            clearSession()
            return true
        }
        return false
    }

    fun clearSession() {
        preferences.edit().remove(KEY_SESSION).apply()
        _session.value = null
    }

    private fun normalizeAfterBootIfNeeded() {
        val activeSession = _session.value ?: return
        val currentBoot = currentBootCount()
        if (activeSession.checkpointBootCount != currentBoot) {
            val rebased = activeSession.copy(
                checkpointElapsedRealtime = SystemClock.elapsedRealtime(),
                checkpointBootCount = currentBoot
            )
            persist(rebased)
            _session.value = rebased
        }
    }

    private fun persist(session: ActiveSession) {
        val encodedPackages = session.blockedPackages.joinToString(PACKAGE_SEPARATOR)
        val encoded = listOf(
            session.id,
            encodedPackages,
            session.durationMillis,
            session.remainingAtCheckpointMillis,
            session.checkpointElapsedRealtime,
            session.checkpointBootCount,
            session.startedAtEpochMillis
        ).joinToString(FIELD_SEPARATOR)
        preferences.edit().putString(KEY_SESSION, encoded).apply()
    }

    private fun loadSession(): ActiveSession? {
        val raw = preferences.getString(KEY_SESSION, null) ?: return null
        return runCatching {
            val fields = raw.split(FIELD_SEPARATOR)
            ActiveSession(
                id = fields[0],
                blockedPackages = fields[1]
                    .split(PACKAGE_SEPARATOR)
                    .filter(String::isNotBlank)
                    .toSet(),
                durationMillis = fields[2].toLong(),
                remainingAtCheckpointMillis = fields[3].toLong(),
                checkpointElapsedRealtime = fields[4].toLong(),
                checkpointBootCount = fields[5].toInt(),
                startedAtEpochMillis = fields[6].toLong()
            )
        }.getOrNull()
    }

    private fun currentBootCount(): Int = runCatching {
        Settings.Global.getInt(context.contentResolver, Settings.Global.BOOT_COUNT, 0)
    }.getOrDefault(0)

    companion object {
        const val MIN_DURATION = 60_000L
        const val MAX_DURATION = 24L * 60L * 60L * 1000L
        private const val PREFS = "v1f_session"
        private const val KEY_SESSION = "active_session"
        private const val FIELD_SEPARATOR = "\u241E"
        private const val PACKAGE_SEPARATOR = "\u241F"
    }
}
