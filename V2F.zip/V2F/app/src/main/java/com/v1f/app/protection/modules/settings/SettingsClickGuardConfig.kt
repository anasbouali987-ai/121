package com.v1f.app.protection.modules.settings

/**
 * Single source of truth for V2F's hidden Settings Click Guard.
 *
 * The labels are intentionally case-sensitive and are matched exactly after
 * trimming leading/trailing whitespace. Edit this file only when a future
 * system update changes one of the visible Settings labels.
 */
object SettingsClickGuardConfig {
    const val TARGET_PACKAGE = "com.android.settings"

    const val BACK_PRESS_COUNT = 3
    const val BACK_PRESS_DELAY_MS = 250L
    const val OVERLAY_SETTLE_DELAY_MS = 32L
    const val OVERLAY_HIDE_DELAY_MS = 250L
    const val TRIGGER_COOLDOWN_MS = 900L

    val blockedLabels: Set<String> = linkedSetOf(
        "Private DNS",
        "System Languages",
        "Developer options",
        "Device admin",
        "DEACTIVATE THIS DEVICE ADMIN APP",
        "Uninstall",
        "DEACTIVATE & UNINSTALL",
        "Rest app preferences",
        "Reset network settings",
        "Background running",
        "V1F App Guard",
        "V1F Device Protection"
    )
}
