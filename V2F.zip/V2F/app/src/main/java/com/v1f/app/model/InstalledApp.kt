package com.v1f.app.model

import android.graphics.drawable.Drawable

data class InstalledApp(
    val label: String,
    val packageName: String,
    val icon: Drawable,
    val isSystem: Boolean,
    val isCritical: Boolean,
    val isSettings: Boolean
)
