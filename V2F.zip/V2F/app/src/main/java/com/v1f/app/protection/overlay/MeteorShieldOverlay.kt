package com.v1f.app.protection.overlay

import android.accessibilityservice.AccessibilityService
import android.animation.ValueAnimator
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.os.Build
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import kotlin.math.sin

/** Full-screen, non-focusable accessibility overlay used during the escape sequence. */
class MeteorShieldOverlay(
    private val service: AccessibilityService
) {
    private val windowManager = service.getSystemService(WindowManager::class.java)
    private var shieldView: MeteorShieldView? = null

    fun show(): Boolean {
        if (shieldView != null) return true
        val view = MeteorShieldView(service).apply {
            isClickable = true
            isFocusable = false
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS
            systemUiVisibility = (
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                    View.SYSTEM_UI_FLAG_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                )
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            android.graphics.PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

        return runCatching {
            windowManager.addView(view, params)
            shieldView = view
            view.start()
            true
        }.getOrDefault(false)
    }

    fun hide() {
        val view = shieldView ?: return
        shieldView = null
        view.stop()
        runCatching { windowManager.removeViewImmediate(view) }
    }
}

private class MeteorShieldView(context: android.content.Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private var phase = 0f
    private var animator: ValueAnimator? = null

    fun start() {
        if (animator != null) return
        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1_900L
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener {
                phase = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    fun stop() {
        animator?.cancel()
        animator = null
    }

    override fun onDetachedFromWindow() {
        stop()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.rgb(1, 0, 3))

        val pulse = 0.78f + 0.22f * sin(phase * Math.PI * 2.0).toFloat()
        val centerX = width * 0.5f
        val centerY = height * 0.38f

        canvas.save()
        canvas.rotate(-34f, centerX, centerY)

        paint.style = Paint.Style.STROKE
        paint.strokeCap = Paint.Cap.ROUND
        paint.strokeWidth = 38f * pulse
        paint.shader = LinearGradient(
            centerX - 260f, centerY, centerX, centerY,
            intArrayOf(Color.TRANSPARENT, Color.argb(75, 120, 8, 16), Color.argb(210, 245, 40, 48)),
            null,
            Shader.TileMode.CLAMP
        )
        canvas.drawLine(centerX - 250f, centerY, centerX - 22f, centerY, paint)

        paint.strokeWidth = 9f * pulse
        paint.shader = LinearGradient(
            centerX - 210f, centerY, centerX, centerY,
            intArrayOf(Color.TRANSPARENT, Color.rgb(255, 119, 36), Color.rgb(255, 229, 170)),
            null,
            Shader.TileMode.CLAMP
        )
        canvas.drawLine(centerX - 205f, centerY, centerX - 14f, centerY, paint)

        paint.style = Paint.Style.FILL
        paint.shader = RadialGradient(
            centerX, centerY, 78f,
            intArrayOf(Color.argb(95, 255, 67, 46), Color.argb(35, 173, 8, 17), Color.TRANSPARENT),
            null,
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(centerX, centerY, 78f, paint)

        path.reset()
        path.moveTo(centerX - 29f, centerY - 12f)
        path.lineTo(centerX - 8f, centerY - 34f)
        path.lineTo(centerX + 28f, centerY - 22f)
        path.lineTo(centerX + 39f, centerY + 9f)
        path.lineTo(centerX + 14f, centerY + 36f)
        path.lineTo(centerX - 22f, centerY + 27f)
        path.close()

        paint.shader = RadialGradient(
            centerX - 7f, centerY - 10f, 70f,
            intArrayOf(Color.rgb(255, 157, 60), Color.rgb(101, 25, 18), Color.rgb(13, 5, 6)),
            null,
            Shader.TileMode.CLAMP
        )
        canvas.drawPath(path, paint)

        paint.shader = null
        paint.color = Color.argb((215 * pulse).toInt(), 255, 245, 215)
        canvas.drawCircle(centerX - 7f, centerY - 10f, 5.5f, paint)
        canvas.restore()

        paint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        paint.textAlign = Paint.Align.CENTER
        paint.textSize = resources.displayMetrics.scaledDensity * 16f
        paint.color = Color.argb(210, 255, 91, 91)
        canvas.drawText("PROTECTION ENGINE", centerX, height * 0.58f, paint)
    }
}
