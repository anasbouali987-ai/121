package com.v1f.app.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.HourglassTop
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.v1f.app.AppGraph
import com.v1f.app.data.SessionRepository
import com.v1f.app.ui.components.CelestialButton
import com.v1f.app.ui.components.GlassSurface
import com.v1f.app.ui.components.StatusPill
import com.v1f.app.ui.theme.V1FColors
import com.v1f.app.ui.theme.V1FDimensions
import com.v1f.app.util.formatDurationHuman
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.filter

@Composable
fun TimerScreen(
    selectedPackages: Set<String>,
    onBack: () -> Unit,
    onStart: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    var hours by remember { mutableIntStateOf(1) }
    var minutes by remember { mutableIntStateOf(0) }
    var showConfirmation by remember { mutableStateOf(false) }
    var sealing by remember { mutableStateOf(false) }

    BackHandler(enabled = !sealing, onBack = onBack)

    LaunchedEffect(hours, minutes) {
        when {
            hours == 24 && minutes != 0 -> minutes = 0
            hours == 0 && minutes == 0 -> minutes = 1
        }
    }

    val durationMillis = ((hours * 60L) + minutes) * 60_000L
    val safeDuration = durationMillis.coerceIn(SessionRepository.MIN_DURATION, SessionRepository.MAX_DURATION)

    LaunchedEffect(sealing) {
        if (sealing) {
            delay(720L)
            onStart(safeDuration)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = V1FDimensions.ScreenHorizontal)
            .padding(top = 16.dp, bottom = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            BackButton(onBack)
            StatusPill("${selectedPackages.size} تطبيق", V1FColors.Cyan)
        }

        Spacer(Modifier.height(15.dp))

        Box(
            modifier = Modifier.size(51.dp).background(V1FColors.Violet.copy(alpha = 0.13f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Outlined.HourglassTop, null, tint = V1FColors.VioletSoft, modifier = Modifier.size(27.dp))
        }

        Spacer(Modifier.height(10.dp))
        Text("حدد مدة الحظر", style = MaterialTheme.typography.displaySmall, color = V1FColors.MoonWhite)
        Text("من دقيقة واحدة إلى 24 ساعة", style = MaterialTheme.typography.bodyLarge, color = V1FColors.TextSecondary)

        Spacer(Modifier.height(16.dp))

        GlassSurface(
            modifier = Modifier.fillMaxWidth(),
            padding = PaddingValues(horizontal = 14.dp, vertical = 18.dp),
            elevated = true,
            accent = if (sealing) V1FColors.StrictRed else V1FColors.VioletSoft,
            pulseAccent = sealing
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("المدة المختارة", style = MaterialTheme.typography.labelLarge, color = V1FColors.TextMuted)
                Spacer(Modifier.height(4.dp))
                Text(formatDurationHuman(safeDuration), style = MaterialTheme.typography.headlineMedium, color = V1FColors.MoonWhite)

                Spacer(Modifier.height(10.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(232.dp)
                        .clip(RoundedCornerShape(26.dp))
                        .background(V1FColors.SpaceBlack.copy(alpha = 0.42f)),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(Modifier.fillMaxSize()) {
                        drawRoundRect(
                            brush = Brush.horizontalGradient(
                                listOf(
                                    (if (sealing) V1FColors.DeepRed else V1FColors.Violet).copy(alpha = 0.12f),
                                    (if (sealing) V1FColors.StrictRed else V1FColors.Cyan).copy(alpha = 0.18f),
                                    (if (sealing) V1FColors.DeepRed else V1FColors.Violet).copy(alpha = 0.12f)
                                )
                            ),
                            topLeft = androidx.compose.ui.geometry.Offset(8f, size.height / 2f - 31f),
                            size = androidx.compose.ui.geometry.Size(size.width - 16f, 62f),
                            cornerRadius = androidx.compose.ui.geometry.CornerRadius(22f, 22f)
                        )
                        drawRoundRect(
                            color = (if (sealing) V1FColors.StrictRed else V1FColors.Cyan).copy(alpha = if (sealing) 0.82f else 0.34f),
                            topLeft = androidx.compose.ui.geometry.Offset(8f, size.height / 2f - 31f),
                            size = androidx.compose.ui.geometry.Size(size.width - 16f, 62f),
                            cornerRadius = androidx.compose.ui.geometry.CornerRadius(22f, 22f),
                            style = Stroke(1.4f)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 22.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        WheelPicker(
                            values = (0..24).toList(),
                            selected = hours,
                            label = "ساعة",
                            onValueChange = {
                                hours = it
                                if (it == 24) minutes = 0
                                if (it == 0 && minutes == 0) minutes = 1
                            },
                            modifier = Modifier.weight(1f)
                        )

                        Text(":", fontSize = 38.sp, color = if (sealing) V1FColors.StrictRed else V1FColors.Cyan, fontWeight = FontWeight.Light)

                        WheelPicker(
                            values = if (hours == 24) listOf(0) else (0..59).toList(),
                            selected = minutes,
                            label = "دقيقة",
                            onValueChange = {
                                minutes = if (hours == 0 && it == 0) 1 else it
                            },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Box(
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .fillMaxWidth()
                            .height(69.dp)
                            .background(Brush.verticalGradient(listOf(V1FColors.SpaceBlack, Color.Transparent)))
                    )
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                            .height(69.dp)
                            .background(Brush.verticalGradient(listOf(Color.Transparent, V1FColors.SpaceBlack)))
                    )
                }

                Spacer(Modifier.height(14.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Preset("15 د") { hours = 0; minutes = 15 }
                    Preset("30 د") { hours = 0; minutes = 30 }
                    Preset("1 س") { hours = 1; minutes = 0 }
                    Preset("2 س") { hours = 2; minutes = 0 }
                }
            }
        }

        Spacer(Modifier.height(13.dp))

        GlassSurface(
            modifier = Modifier.fillMaxWidth(),
            padding = PaddingValues(15.dp),
            accent = V1FColors.StrictRed
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Lock, null, tint = V1FColors.StrictRed)
                Spacer(Modifier.width(10.dp))
                Text(
                    "بعد الضغط على START لا يمكن تقليل الوقت أو إلغاء الحظر حتى يصل العداد إلى الصفر.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = V1FColors.TextSecondary
                )
            }
        }

        Spacer(Modifier.weight(1f))
        Spacer(Modifier.height(13.dp))

        CelestialButton(
            text = if (sealing) "تم ختم القرار · جارٍ بدء الحظر" else "START · بدء الحظر الصارم",
            onClick = { if (!sealing) showConfirmation = true },
            enabled = !sealing,
            strict = true,
            showLock = true
        )
    }

    if (showConfirmation) {
        StartConfirmationDialog(
            duration = safeDuration,
            selectedPackages = selectedPackages,
            onDismiss = { showConfirmation = false },
            onConfirm = {
                showConfirmation = false
                sealing = true
            }
        )
    }
}

@Composable
private fun WheelPicker(
    values: List<Int>,
    selected: Int,
    label: String,
    onValueChange: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val selectedIndex = values.indexOf(selected).coerceAtLeast(0)
    val state = rememberLazyListState(initialFirstVisibleItemIndex = selectedIndex)
    val itemHeight = 56.dp
    val itemHeightPx = with(LocalDensity.current) { itemHeight.toPx() }

    LaunchedEffect(selected, values) {
        val index = values.indexOf(selected).coerceAtLeast(0)
        if (!state.isScrollInProgress && state.firstVisibleItemIndex != index) {
            state.animateScrollToItem(index)
        }
    }

    LaunchedEffect(state, values) {
        snapshotFlow { state.isScrollInProgress }
            .distinctUntilChanged()
            .filter { !it }
            .collect {
                val next = if (state.firstVisibleItemScrollOffset > itemHeightPx / 2f) {
                    state.firstVisibleItemIndex + 1
                } else {
                    state.firstVisibleItemIndex
                }.coerceIn(values.indices)
                state.animateScrollToItem(next)
                onValueChange(values[next])
            }
    }

    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        LazyColumn(
            state = state,
            modifier = Modifier.height(224.dp).fillMaxWidth(),
            contentPadding = PaddingValues(vertical = 84.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            items(values.size) { index ->
                val isSelected = values[index] == selected
                Box(modifier = Modifier.fillMaxWidth().height(itemHeight), contentAlignment = Alignment.Center) {
                    Text(
                        text = values[index].toString().padStart(2, '0'),
                        fontSize = if (isSelected) 39.sp else 25.sp,
                        fontWeight = if (isSelected) FontWeight.Light else FontWeight.Normal,
                        color = if (isSelected) V1FColors.MoonWhite else V1FColors.TextMuted.copy(alpha = 0.55f)
                    )
                }
            }
        }
        Text(label, style = MaterialTheme.typography.labelMedium, color = V1FColors.TextMuted)
    }
}

@Composable
private fun Preset(text: String, onClick: () -> Unit) {
    GlassSurface(
        padding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
        onClick = onClick
    ) {
        Text(text, style = MaterialTheme.typography.labelMedium, color = V1FColors.TextSecondary)
    }
}

@Composable
private fun StartConfirmationDialog(
    duration: Long,
    selectedPackages: Set<String>,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    val packageManager = AppGraph.application.packageManager
    val selectedLabels = remember(selectedPackages) {
        selectedPackages.map { packageName ->
            runCatching {
                val info = packageManager.getApplicationInfo(packageName, 0)
                packageManager.getApplicationLabel(info).toString()
            }.getOrDefault(packageName)
        }.sorted()
    }
    Dialog(onDismissRequest = onDismiss) {
        GlassSurface(
            modifier = Modifier.fillMaxWidth(),
            padding = PaddingValues(22.dp),
            elevated = true,
            accent = V1FColors.StrictRed,
            pulseAccent = true
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Rounded.Lock, null, tint = V1FColors.StrictRed, modifier = Modifier.size(44.dp))
                Spacer(Modifier.height(12.dp))
                Text("تأكيد القرار الصارم", style = MaterialTheme.typography.headlineSmall, color = V1FColors.MoonWhite)
                Spacer(Modifier.height(8.dp))
                Text(
                    "سيُحظر ${selectedPackages.size} تطبيقات لمدة ${formatDurationHuman(duration)}. لا يوجد إلغاء داخل التطبيق بعد البدء.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = V1FColors.TextSecondary,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(14.dp))
                GlassSurface(
                    modifier = Modifier.fillMaxWidth(),
                    padding = PaddingValues(13.dp),
                    accent = V1FColors.StrictRed
                ) {
                    Column {
                        selectedLabels.take(4).forEach { label ->
                            Text("✦  $label", style = MaterialTheme.typography.bodyMedium, color = V1FColors.TextSecondary)
                        }
                        if (selectedLabels.size > 4) {
                            Text("+${selectedLabels.size - 4} تطبيقات أخرى", style = MaterialTheme.typography.labelMedium, color = V1FColors.Cyan)
                        }
                        Spacer(Modifier.height(7.dp))
                        Text(
                            "صفحات الإعدادات الحساسة ستُحمى تلقائيًا طوال الجلسة.",
                            style = MaterialTheme.typography.bodySmall,
                            color = V1FColors.Gold
                        )
                    }
                }
                Spacer(Modifier.height(18.dp))
                CelestialButton("ابدأ الآن", onClick = onConfirm, strict = true, showLock = true)
                Spacer(Modifier.height(10.dp))
                GlassSurface(
                    modifier = Modifier.fillMaxWidth(),
                    padding = PaddingValues(13.dp),
                    onClick = onDismiss
                ) {
                    Text("عودة", style = MaterialTheme.typography.labelLarge, color = V1FColors.TextSecondary, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                }
            }
        }
    }
}

@Composable
private fun BackButton(onBack: () -> Unit) {
    val interaction = remember { MutableInteractionSource() }
    Icon(
        imageVector = Icons.AutoMirrored.Outlined.ArrowBack,
        contentDescription = "رجوع",
        tint = V1FColors.MoonWhite,
        modifier = Modifier
            .size(40.dp)
            .clip(CircleShape)
            .clickable(interactionSource = interaction, indication = null, onClick = onBack)
            .padding(8.dp)
    )
}
