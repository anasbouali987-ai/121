package com.v1f.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.v1f.app.service.BackgroundProtectionService
import com.v1f.app.ui.V1FApp
import com.v1f.app.ui.theme.V1FTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        configureSystemBars()
        setContent {
            V1FTheme {
                V1FApp()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        AppGraph.permissionRepository.refresh()
        if (
            AppGraph.permissionRepository.isBackgroundRequested() ||
            AppGraph.sessionRepository.session.value != null
        ) {
            runCatching { BackgroundProtectionService.start(this) }
        }
    }

    private fun configureSystemBars() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }
    }
}
