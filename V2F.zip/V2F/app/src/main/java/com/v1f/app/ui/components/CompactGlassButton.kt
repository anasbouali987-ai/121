package com.v1f.app.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.GridView
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.v1f.app.ui.theme.V1FColors

@Composable
fun CompactGlassButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    accent: Color? = null,
    locked: Boolean = false
) {
    GlassSurface(
        modifier = modifier,
        padding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
        accent = accent,
        pulseAccent = locked,
        onClick = onClick
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = if (locked) Icons.Rounded.Lock else Icons.Outlined.GridView,
                contentDescription = null,
                tint = accent ?: V1FColors.TextSecondary,
                modifier = Modifier.size(18.dp)
            )
            Text(
                text = text,
                style = MaterialTheme.typography.labelMedium,
                color = if (accent != null) V1FColors.MoonWhite else V1FColors.TextSecondary,
                maxLines = 1
            )
        }
    }
}
