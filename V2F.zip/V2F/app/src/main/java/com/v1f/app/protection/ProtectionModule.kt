package com.v1f.app.protection

import com.v1f.app.model.ActiveSession

/**
 * A silent unit owned by [ProtectionEngine].
 *
 * Modules have no cards, switches, screens or independent user settings. Their
 * lifecycle follows the sealed session automatically.
 */
interface ProtectionModule {
    val id: String

    fun onSessionStarted(session: ActiveSession) = Unit

    fun onSessionEnded() = Unit

    fun evaluate(context: ProtectionContext): ProtectionDecision
}
