package com.v1f.app.protection.modules

import android.view.accessibility.AccessibilityEvent
import com.v1f.app.protection.ProtectionContext
import com.v1f.app.protection.ProtectionDecision
import com.v1f.app.protection.ProtectionModule

/** Preserves the tested V1F selected-application blocking behavior. */
class AppGuardModule : ProtectionModule {
    override val id: String = ID

    override fun evaluate(context: ProtectionContext): ProtectionDecision {
        if (context.event.eventType !in APP_WINDOW_EVENTS) {
            return ProtectionDecision.Allow
        }
        if (context.packageName !in context.session.blockedPackages) {
            return ProtectionDecision.Allow
        }
        return ProtectionDecision.BlockApplication(
            packageName = context.packageName,
            moduleId = id
        )
    }

    companion object {
        const val ID = "app_guard"

        private val APP_WINDOW_EVENTS = setOf(
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED,
            AccessibilityEvent.TYPE_WINDOWS_CHANGED
        )
    }
}
