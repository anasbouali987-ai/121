package com.v1f.app.model

data class ActiveSession(
    val id: String,
    val blockedPackages: Set<String>,
    val durationMillis: Long,
    val remainingAtCheckpointMillis: Long,
    val checkpointElapsedRealtime: Long,
    val checkpointBootCount: Int,
    val startedAtEpochMillis: Long
)
