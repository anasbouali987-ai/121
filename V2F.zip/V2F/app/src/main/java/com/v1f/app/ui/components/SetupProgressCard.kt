package com.v1f.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ShieldMoon
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.v1f.app.model.PermissionSnapshot
import com.v1f.app.ui.theme.V1FColors
import com.v1f.app.util.formatDuration

@Composable
fun SetupProgressCard(
    snapshot: PermissionSnapshot,
    modifier: Modifier = Modifier
) {
    val accent = when {
        snapshot.allReady -> V1FColors.Cyan
        snapshot.completedCount > 0 -> V1FColors.Gold
        else -> V1FColors.Gold
    }
    GlassSurface(
        modifier = modifier.fillMaxWidth(),
        padding = PaddingValues(18.dp),
        elevated = true,
        accent = if (snapshot.allReady) V1FColors.Cyan else null
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier.size(43.dp).background(accent.copy(alpha = 0.12f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Outlined.ShieldMoon, null, tint = accent, modifier = Modifier.size(22.dp))
                }
                Spacer(Modifier.width(13.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (snapshot.allReady) "طبقات الحماية جاهزة" else "النظام بحاجة إلى الإعداد",
                        style = MaterialTheme.typography.titleMedium,
                        color = V1FColors.MoonWhite
                    )
                    Text(
                        text = if (snapshot.allReady) "يمكنك الآن اختيار التطبيقات ومدة الحظر" else "أكمل ثلاث طبقات أساسية لبدء الحماية",
                        style = MaterialTheme.typography.bodyMedium,
                        color = V1FColors.TextSecondary
                    )
                }
                Text("${snapshot.completedCount} / 3", style = MaterialTheme.typography.labelLarge, color = accent)
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                repeat(3) { index ->
                    Box(
                        modifier = Modifier.weight(1f).height(5.dp).background(
                            color = if (index < snapshot.completedCount) accent else Color.White.copy(alpha = 0.08f),
                            shape = CircleShape
                        )
                    )
                }
            }
        }
    }
}

@Composable
fun ActiveSessionCard(
    remainingMillis: Long,
    blockedApps: Int,
    onOpenPermissions: () -> Unit,
    modifier: Modifier = Modifier
) {
    GlassSurface(
        modifier = modifier.fillMaxWidth(),
        padding = PaddingValues(18.dp),
        elevated = true,
        accent = V1FColors.StrictRed,
        pulseAccent = true
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(15.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier.size(44.dp).background(V1FColors.StrictRed.copy(alpha = 0.14f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Rounded.Lock, null, tint = V1FColors.StrictRed)
                }
                Spacer(Modifier.width(13.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text("الجلسة مقفلة", style = MaterialTheme.typography.titleMedium, color = V1FColors.MoonWhite)
                    Text("لا يمكن الإلغاء أو تعديل الاختيارات", style = MaterialTheme.typography.bodyMedium, color = V1FColors.TextSecondary)
                }
                Text("LOCKED", style = MaterialTheme.typography.labelLarge, color = V1FColors.StrictRed)
            }

            Text(
                text = formatDuration(remainingMillis),
                style = MaterialTheme.typography.displaySmall,
                color = V1FColors.MoonWhite,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("$blockedApps تطبيقات محظورة", style = MaterialTheme.typography.bodyMedium, color = V1FColors.TextSecondary)
                Text("الصلاحيات مقفلة", style = MaterialTheme.typography.labelLarge, color = V1FColors.StrictRed)
            }

            GlassSurface(
                modifier = Modifier.fillMaxWidth(),
                padding = PaddingValues(horizontal = 14.dp, vertical = 12.dp),
                accent = V1FColors.StrictRed,
                onClick = onOpenPermissions
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Lock, null, tint = V1FColors.StrictRed, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(9.dp))
                    Text("عرض الصلاحيات المقفلة", style = MaterialTheme.typography.labelLarge, color = V1FColors.MoonWhite)
                }
            }
        }
    }
}
