package com.v1f.app.protection

import android.view.accessibility.AccessibilityEvent
import com.v1f.app.model.ActiveSession

/** Immutable snapshot passed to one Protection Engine module. */
data class ProtectionContext(
    val event: AccessibilityEvent,
    val packageName: String,
    val session: ActiveSession,
    val remainingMillis: Long
)
