package com.v1f.app.ui.model

enum class ProtectionState {
    SetupRequired,
    Ready,
    Protected,
    Active,
    Alert
}
