package com.v1f.app.util

import java.util.Locale

fun formatDuration(millis: Long): String {
    val totalSeconds = (millis.coerceAtLeast(0L) + 999L) / 1000L
    val hours = totalSeconds / 3600L
    val minutes = (totalSeconds % 3600L) / 60L
    val seconds = totalSeconds % 60L
    return String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, seconds)
}

fun formatDurationHuman(millis: Long): String {
    val totalMinutes = (millis.coerceAtLeast(60_000L) / 60_000L)
    val hours = totalMinutes / 60L
    val minutes = totalMinutes % 60L
    return when {
        hours > 0 && minutes > 0 -> "$hours س $minutes د"
        hours > 0 -> "$hours ساعة"
        else -> "$minutes دقيقة"
    }
}
