package com.v1f.app.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.v1f.app.AppGraph
import com.v1f.app.model.ActiveSession
import com.v1f.app.model.PermissionSnapshot
import com.v1f.app.ui.components.ActiveSessionCard
import com.v1f.app.ui.components.CelestialButton
import com.v1f.app.ui.components.CompactGlassButton
import com.v1f.app.ui.components.ProtectionCore
import com.v1f.app.ui.components.SetupProgressCard
import com.v1f.app.ui.components.StatusPill
import com.v1f.app.ui.model.ProtectionState
import com.v1f.app.ui.theme.V1FColors
import com.v1f.app.ui.theme.V1FDimensions
import com.v1f.app.ui.theme.V1FMotion
import com.v1f.app.util.formatDuration
import kotlinx.coroutines.delay

@Composable
fun HomeScreen(
    permissionSnapshot: PermissionSnapshot,
    activeSession: ActiveSession?,
    onOpenPermissions: () -> Unit,
    onPrimaryAction: () -> Unit,
    modifier: Modifier = Modifier
) {
    var entered by remember { mutableStateOf(false) }
    var remainingMillis by remember(activeSession?.id) {
        mutableLongStateOf(AppGraph.sessionRepository.remainingMillis())
    }

    LaunchedEffect(Unit) {
        delay(90)
        entered = true
    }

    LaunchedEffect(activeSession?.id) {
        while (activeSession != null) {
            remainingMillis = AppGraph.sessionRepository.remainingMillis()
            delay(1_000L)
        }
    }

    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val compact = maxHeight < 700.dp
        val compactHeader = maxWidth < 370.dp
        val coreSize = if (compact) 176.dp else 205.dp
        val state = when {
            activeSession != null -> ProtectionState.Active
            permissionSnapshot.allReady -> ProtectionState.Ready
            else -> ProtectionState.SetupRequired
        }
        val accent = when (state) {
            ProtectionState.Active -> V1FColors.StrictRed
            ProtectionState.Ready -> V1FColors.Cyan
            else -> V1FColors.Gold
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = V1FDimensions.ScreenHorizontal)
                .padding(top = 15.dp, bottom = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Header(
                compact = compactHeader,
                sessionActive = activeSession != null,
                onOpenPermissions = onOpenPermissions
            )

            Spacer(Modifier.height(if (compact) 9.dp else 14.dp))

            AnimatedVisibility(
                visible = entered,
                enter = fadeIn(tween(V1FMotion.Entry)) +
                    slideInVertically(tween(V1FMotion.Entry)) { it / 10 }
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    ProtectionCore(
                        state = state,
                        progressText = if (activeSession != null) {
                            formatDuration(remainingMillis)
                        } else {
                            "${permissionSnapshot.completedCount} / 3"
                        },
                        coreLabel = if (activeSession != null) "STRICT" else "CORE",
                        coreSize = coreSize
                    )
                    StatusPill(
                        text = when {
                            activeSession != null -> "الحماية الصارمة نشطة"
                            permissionSnapshot.allReady -> "جاهز لاختيار التطبيقات"
                            else -> "إعداد مطلوب"
                        },
                        accent = accent
                    )
                }
            }

            Spacer(Modifier.height(if (compact) 12.dp else 17.dp))

            AnimatedVisibility(
                visible = entered,
                enter = fadeIn(tween(V1FMotion.Entry, delayMillis = V1FMotion.EntryDelay)) +
                    slideInVertically(tween(V1FMotion.Entry, delayMillis = V1FMotion.EntryDelay)) { it / 9 }
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = if (activeSession != null) "القرار أصبح نافذًا" else "استعد لاستعادة وقتك",
                        style = MaterialTheme.typography.displaySmall,
                        color = V1FColors.MoonWhite,
                        textAlign = TextAlign.Center
                    )
                    Spacer(Modifier.height(7.dp))
                    Text(
                        text = if (activeSession != null) {
                            "ستبقى التطبيقات المختارة محظورة حتى ينتهي العداد"
                        } else {
                            "مساحتك الرقمية، بشروطك أنت"
                        },
                        style = MaterialTheme.typography.bodyLarge,
                        color = V1FColors.TextSecondary,
                        textAlign = TextAlign.Center
                    )
                }
            }

            Spacer(Modifier.height(if (compact) 13.dp else 18.dp))

            AnimatedVisibility(
                visible = entered,
                enter = fadeIn(tween(V1FMotion.Entry, delayMillis = V1FMotion.EntryDelay * 2)) +
                    slideInVertically(tween(V1FMotion.Entry, delayMillis = V1FMotion.EntryDelay * 2)) { it / 8 }
            ) {
                if (activeSession != null) {
                    ActiveSessionCard(
                        remainingMillis = remainingMillis,
                        blockedApps = activeSession.blockedPackages.size,
                        onOpenPermissions = onOpenPermissions
                    )
                } else {
                    SetupProgressCard(snapshot = permissionSnapshot)
                }
            }

            if (activeSession == null) {
                Spacer(Modifier.height(if (compact) 15.dp else 20.dp))
                AnimatedVisibility(
                    visible = entered,
                    enter = fadeIn(tween(V1FMotion.Entry, delayMillis = V1FMotion.EntryDelay * 3)) +
                        slideInVertically(tween(V1FMotion.Entry, delayMillis = V1FMotion.EntryDelay * 3)) { it / 7 }
                ) {
                    CelestialButton(
                        text = if (permissionSnapshot.allReady) "اختيار التطبيقات" else "ابدأ إعداد الحماية",
                        onClick = onPrimaryAction
                    )
                }
            }

            Spacer(Modifier.height(18.dp))

            Text(
                text = if (activeSession != null) "V1F · جلسة صارمة لا تقبل الإلغاء" else "V1F · CELESTIAL APP LOCK",
                style = MaterialTheme.typography.labelMedium,
                color = if (activeSession != null) V1FColors.StrictRed else V1FColors.TextMuted
            )
        }
    }
}

@Composable
private fun Header(
    compact: Boolean,
    sessionActive: Boolean,
    onOpenPermissions: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier.size(40.dp).clip(CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Canvas(Modifier.fillMaxSize()) {
                    val accent = if (sessionActive) V1FColors.StrictRed else V1FColors.Violet
                    drawCircle(accent.copy(alpha = 0.14f))
                    drawCircle(
                        color = accent.copy(alpha = 0.34f),
                        style = androidx.compose.ui.graphics.drawscope.Stroke(1.2f)
                    )
                }
                Icon(
                    imageVector = Icons.Outlined.AutoAwesome,
                    contentDescription = null,
                    tint = if (sessionActive) V1FColors.StrictRed else V1FColors.Gold,
                    modifier = Modifier.size(21.dp)
                )
            }
            Spacer(Modifier.width(10.dp))
            Column {
                Text("V1F", style = MaterialTheme.typography.titleLarge, color = V1FColors.MoonWhite)
                if (!compact) {
                    Text("CELESTIAL FOCUS", style = MaterialTheme.typography.labelMedium, color = V1FColors.TextMuted)
                }
            }
        }

        CompactGlassButton(
            text = if (compact) "الصلاحيات" else if (sessionActive) "الصلاحيات مقفلة" else "جميع الصلاحيات",
            onClick = onOpenPermissions,
            accent = if (sessionActive) V1FColors.StrictRed else null,
            locked = sessionActive
        )
    }
}
