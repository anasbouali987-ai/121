package com.v1f.app.ui.theme

import androidx.compose.ui.graphics.Color

object V1FColors {
    val SpaceBlack = Color(0xFF02040B)
    val DeepNight = Color(0xFF060B19)
    val Midnight = Color(0xFF0D1630)
    val Nebula = Color(0xFF19142F)

    val Violet = Color(0xFF8B7CFF)
    val VioletSoft = Color(0xFFAAA1FF)
    val Cyan = Color(0xFF66D7F7)
    val Mint = Color(0xFF63E6AE)
    val Gold = Color(0xFFFFD17A)
    val Coral = Color(0xFFFF6578)
    val StrictRed = Color(0xFFFF354F)
    val DeepRed = Color(0xFF6D0B1C)
    val Ember = Color(0xFFFF9B64)

    val MoonWhite = Color(0xFFF7F8FF)
    val TextSecondary = Color(0xFFB5BED7)
    val TextMuted = Color(0xFF7A86A7)

    val Glass = Color(0x10FFFFFF)
    val GlassStrong = Color(0x1BFFFFFF)
    val GlassBorder = Color(0x2BFFFFFF)
    val GlassHighlight = Color(0x52FFFFFF)
}
