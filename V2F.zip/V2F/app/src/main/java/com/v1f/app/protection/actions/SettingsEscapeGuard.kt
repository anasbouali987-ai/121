package com.v1f.app.protection.actions

import android.accessibilityservice.AccessibilityService
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import com.v1f.app.protection.modules.settings.SettingsClickGuardConfig
import com.v1f.app.protection.overlay.MeteorShieldOverlay

/**
 * Covers Settings with the meteor shield while three Back actions execute.
 * The overlay is non-focusable, so the global actions target Settings beneath it.
 */
class SettingsEscapeGuard(
    private val service: AccessibilityService
) {
    private val handler = Handler(Looper.getMainLooper())
    private val overlay = MeteorShieldOverlay(service)
    private var running = false
    private var lastTriggeredAt = 0L
    private var generation = 0

    fun trigger() {
        val now = SystemClock.elapsedRealtime()
        if (running || now - lastTriggeredAt < SettingsClickGuardConfig.TRIGGER_COOLDOWN_MS) return

        running = true
        lastTriggeredAt = now
        generation += 1
        val currentGeneration = generation
        var backActionFailed = false

        overlay.show()

        repeat(SettingsClickGuardConfig.BACK_PRESS_COUNT) { index ->
            val delay = SettingsClickGuardConfig.OVERLAY_SETTLE_DELAY_MS +
                index * SettingsClickGuardConfig.BACK_PRESS_DELAY_MS
            handler.postDelayed({
                if (currentGeneration != generation) return@postDelayed
                val accepted = service.performGlobalAction(
                    AccessibilityService.GLOBAL_ACTION_BACK
                )
                if (!accepted) backActionFailed = true
            }, delay)
        }

        val completionDelay = SettingsClickGuardConfig.OVERLAY_SETTLE_DELAY_MS +
            (SettingsClickGuardConfig.BACK_PRESS_COUNT - 1) *
                SettingsClickGuardConfig.BACK_PRESS_DELAY_MS +
            SettingsClickGuardConfig.OVERLAY_HIDE_DELAY_MS

        handler.postDelayed({
            if (currentGeneration != generation) return@postDelayed
            if (backActionFailed) {
                service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
            }
            overlay.hide()
            running = false
        }, completionDelay)
    }

    fun close() {
        generation += 1
        handler.removeCallbacksAndMessages(null)
        overlay.hide()
        running = false
    }
}
