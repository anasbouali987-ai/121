package com.v1f.app.model

data class PermissionSnapshot(
    val accessibilityEnabled: Boolean = false,
    val deviceAdminEnabled: Boolean = false,
    val backgroundServiceRequested: Boolean = false,
    val backgroundServiceRunning: Boolean = false,
    val batteryOptimizationIgnored: Boolean = false,
    val notificationsAllowed: Boolean = true
) {
    /**
     * The third protection layer is considered active once the foreground
     * service is requested, running and allowed to show its persistent
     * notification. Battery-optimization exemption remains strongly
     * recommended, but is not treated as an impossible hard gate on every OEM.
     */
    val backgroundReady: Boolean
        get() = backgroundServiceRequested && backgroundServiceRunning &&
            notificationsAllowed

    val completedCount: Int
        get() = listOf(accessibilityEnabled, deviceAdminEnabled, backgroundReady).count { it }

    val allReady: Boolean
        get() = completedCount == 3
}
