package com.v1f.app.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.v1f.app.ui.theme.V1FColors
import com.v1f.app.ui.theme.V1FDimensions
import com.v1f.app.ui.theme.V1FMotion

@Composable
fun GlassSurface(
    modifier: Modifier = Modifier,
    padding: PaddingValues = PaddingValues(V1FDimensions.CardPadding),
    elevated: Boolean = false,
    accent: Color? = null,
    pulseAccent: Boolean = false,
    enabled: Boolean = true,
    onClick: (() -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit
) {
    val shape = RoundedCornerShape(V1FDimensions.CardRadius)
    val interaction = remember { MutableInteractionSource() }
    val pulse = if (pulseAccent && accent != null) {
        rememberInfiniteTransition(label = "glass-pulse").animateFloat(
            initialValue = 0.34f,
            targetValue = 0.82f,
            animationSpec = infiniteRepeatable(
                animation = tween(V1FMotion.StrictPulse),
                repeatMode = RepeatMode.Reverse
            ),
            label = "glass-pulse-value"
        ).value
    } else {
        0.44f
    }

    val clickModifier = if (onClick == null || !enabled) {
        Modifier
    } else {
        Modifier.clickable(
            interactionSource = interaction,
            indication = null,
            onClick = onClick
        )
    }

    val borderBrush = if (accent != null) {
        Brush.verticalGradient(
            listOf(
                accent.copy(alpha = pulse),
                accent.copy(alpha = 0.18f)
            )
        )
    } else {
        Brush.verticalGradient(
            listOf(V1FColors.GlassHighlight, V1FColors.GlassBorder)
        )
    }

    Box(
        modifier = modifier
            .then(
                if (elevated) {
                    Modifier.shadow(
                        elevation = 14.dp,
                        shape = shape,
                        ambientColor = (accent ?: Color.Black).copy(alpha = 0.28f),
                        spotColor = (accent ?: Color.Black).copy(alpha = 0.34f)
                    )
                } else {
                    Modifier
                }
            )
            .clip(shape)
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        (accent ?: V1FColors.MoonWhite).copy(
                            alpha = if (accent == null) 0.10f else 0.075f
                        ),
                        V1FColors.Glass
                    )
                )
            )
            .border(1.dp, borderBrush, shape)
            .then(clickModifier)
            .padding(padding),
        content = content
    )
}
