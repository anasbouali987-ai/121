package com.v1f.app.protection

import android.view.accessibility.AccessibilityEvent
import com.v1f.app.data.SessionRepository
import com.v1f.app.model.ActiveSession
import com.v1f.app.protection.modules.AppGuardModule
import com.v1f.app.protection.modules.settings.SettingsClickGuardModule
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Background-only coordinator for all present and future protection modules.
 *
 * V2F registers SettingsClickGuard and the existing application blocker. Future
 * versions can add PermissionGuard, SafeModeGuard, TimeManipulationGuard and
 * other modules without changing the engine contract or the visible UI.
 */
class ProtectionEngine(
    private val sessionRepository: SessionRepository,
    modules: List<ProtectionModule> = listOf(
        SettingsClickGuardModule(),
        AppGuardModule()
    )
) {
    private val modules = modules.toList()
    private val _state = MutableStateFlow(ProtectionEngineState())
    val state: StateFlow<ProtectionEngineState> = _state.asStateFlow()

    @Volatile
    private var activeSessionId: String? = null

    @Synchronized
    fun synchronize() {
        val session = sessionRepository.session.value
        if (session == null || sessionRepository.remainingMillis() <= 0L) {
            sessionRepository.clearIfExpired()
            stopLocked()
        } else {
            startLocked(session)
        }
    }

    @Synchronized
    fun evaluate(event: AccessibilityEvent): ProtectionDecision {
        val session = sessionRepository.session.value
            ?: run {
                stopLocked()
                return ProtectionDecision.Allow
            }

        val remaining = sessionRepository.remainingMillis()
        if (remaining <= 0L) {
            sessionRepository.clearIfExpired()
            stopLocked()
            return ProtectionDecision.Allow
        }

        startLocked(session)

        val packageName = event.packageName?.toString()?.takeIf(String::isNotBlank)
            ?: return ProtectionDecision.Allow
        val context = ProtectionContext(
            event = event,
            packageName = packageName,
            session = session,
            remainingMillis = remaining
        )

        modules.forEach { module ->
            val decision = runCatching { module.evaluate(context) }
                .getOrDefault(ProtectionDecision.Allow)
            if (decision !is ProtectionDecision.Allow) return decision
        }
        return ProtectionDecision.Allow
    }

    @Synchronized
    fun stop() = stopLocked()

    private fun startLocked(session: ActiveSession) {
        if (activeSessionId == session.id) return
        if (activeSessionId != null) stopLocked()

        modules.forEach { module -> runCatching { module.onSessionStarted(session) } }
        activeSessionId = session.id
        _state.value = ProtectionEngineState(
            active = true,
            sessionId = session.id,
            enabledModules = modules.mapTo(linkedSetOf()) { it.id }
        )
    }

    private fun stopLocked() {
        if (activeSessionId == null && !_state.value.active) return
        modules.asReversed().forEach { module -> runCatching { module.onSessionEnded() } }
        activeSessionId = null
        _state.value = ProtectionEngineState()
    }
}
