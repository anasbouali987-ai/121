package com.v1f.app

import android.app.Application

class V1FApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        AppGraph.initialize(this)
    }
}
