package com.v1f.app.admin

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent
import com.v1f.app.AppGraph
import com.v1f.app.R

class V1FDeviceAdminReceiver : DeviceAdminReceiver() {
    override fun onEnabled(context: Context, intent: Intent) {
        super.onEnabled(context, intent)
        AppGraph.permissionRepository.refresh()
    }

    override fun onDisabled(context: Context, intent: Intent) {
        super.onDisabled(context, intent)
        AppGraph.permissionRepository.refresh()
    }

    override fun onDisableRequested(context: Context, intent: Intent): CharSequence {
        return if (AppGraph.sessionRepository.session.value != null) {
            context.getString(R.string.admin_disable_warning_active)
        } else {
            context.getString(R.string.admin_disable_warning)
        }
    }
}
