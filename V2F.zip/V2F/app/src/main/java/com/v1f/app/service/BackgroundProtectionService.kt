package com.v1f.app.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.v1f.app.AppGraph
import com.v1f.app.MainActivity
import com.v1f.app.R
import com.v1f.app.util.formatDuration
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class BackgroundProtectionService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var tickerJob: Job? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        _isRunning.value = true
        AppGraph.permissionRepository.refresh()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val foregroundType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        } else {
            0
        }
        ServiceCompat.startForeground(
            this,
            NOTIFICATION_ID,
            buildNotification(),
            foregroundType
        )
        if (tickerJob?.isActive != true) {
            tickerJob = scope.launch {
                var tick = 0
                while (isActive) {
                    val repository = AppGraph.sessionRepository
                    AppGraph.protectionEngine.synchronize()
                    val session = repository.session.value
                    if (session != null) {
                        val remaining = repository.remainingMillis()
                        if (remaining <= 0L) {
                            repository.clearSession()
                        } else if (tick % CHECKPOINT_EVERY_TICKS == 0) {
                            repository.checkpoint()
                        }
                    }
                    updateNotification()
                    delay(1_000L)
                    tick++
                }
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        AppGraph.protectionEngine.synchronize()
        tickerJob?.cancel()
        scope.cancel()
        _isRunning.value = false
        AppGraph.permissionRepository.refresh()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun updateNotification() {
        val manager = getSystemService(NotificationManager::class.java)
        runCatching { manager.notify(NOTIFICATION_ID, buildNotification()) }
    }

    private fun buildNotification() = NotificationCompat.Builder(this, CHANNEL_ID)
        .setSmallIcon(R.drawable.ic_launcher_foreground)
        .setContentTitle(getString(R.string.notification_title))
        .setContentText(notificationText())
        .setContentIntent(
            PendingIntent.getActivity(
                this,
                10,
                Intent(this, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
                },
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        )
        .setCategory(NotificationCompat.CATEGORY_SERVICE)
        .setOngoing(true)
        .setOnlyAlertOnce(true)
        .setSilent(true)
        .build()

    private fun notificationText(): String {
        val session = AppGraph.sessionRepository.session.value
        return if (session == null) {
            getString(R.string.notification_ready)
        } else {
            getString(
                R.string.notification_active,
                formatDuration(AppGraph.sessionRepository.remainingMillis()),
                session.blockedPackages.size
            )
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.notification_channel_description)
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    companion object {
        private const val CHANNEL_ID = "v1f_protection"
        private const val NOTIFICATION_ID = 1407
        private const val CHECKPOINT_EVERY_TICKS = 15

        private val _isRunning = MutableStateFlow(false)
        val isRunning = _isRunning.asStateFlow()

        fun start(context: Context) {
            ContextCompat.startForegroundService(
                context,
                Intent(context, BackgroundProtectionService::class.java)
            )
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, BackgroundProtectionService::class.java))
        }
    }
}
