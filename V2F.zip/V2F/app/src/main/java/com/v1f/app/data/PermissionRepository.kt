package com.v1f.app.data

import android.Manifest
import android.app.NotificationManager
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.v1f.app.admin.V1FDeviceAdminReceiver
import com.v1f.app.model.PermissionSnapshot
import com.v1f.app.service.AppBlockAccessibilityService
import com.v1f.app.service.BackgroundProtectionService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class PermissionRepository(private val context: Context) {
    private val preferences = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private val _snapshot = MutableStateFlow(readSnapshot())
    val snapshot: StateFlow<PermissionSnapshot> = _snapshot.asStateFlow()

    fun refresh() {
        _snapshot.value = readSnapshot()
    }

    fun markBackgroundRequested(requested: Boolean) {
        preferences.edit().putBoolean(KEY_BACKGROUND_REQUESTED, requested).apply()
        refresh()
    }

    fun isBackgroundRequested(): Boolean =
        preferences.getBoolean(KEY_BACKGROUND_REQUESTED, false)

    private fun readSnapshot(): PermissionSnapshot {
        val notificationAllowed = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            val manager = context.getSystemService(NotificationManager::class.java)
            manager.areNotificationsEnabled()
        }

        val powerManager = context.getSystemService(PowerManager::class.java)
        val devicePolicyManager = context.getSystemService(DevicePolicyManager::class.java)
        val adminComponent = ComponentName(context, V1FDeviceAdminReceiver::class.java)

        return PermissionSnapshot(
            accessibilityEnabled = AppBlockAccessibilityService.isEnabled(context),
            deviceAdminEnabled = devicePolicyManager.isAdminActive(adminComponent),
            backgroundServiceRequested = isBackgroundRequested(),
            backgroundServiceRunning = BackgroundProtectionService.isRunning.value,
            batteryOptimizationIgnored = powerManager.isIgnoringBatteryOptimizations(
                context.packageName
            ),
            notificationsAllowed = notificationAllowed
        )
    }

    companion object {
        private const val PREFS = "v1f_permissions"
        private const val KEY_BACKGROUND_REQUESTED = "background_requested"
    }
}
