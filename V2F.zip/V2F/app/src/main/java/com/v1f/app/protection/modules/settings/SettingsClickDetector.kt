package com.v1f.app.protection.modules.settings

import android.view.accessibility.AccessibilityEvent

/**
 * Reads only the clicked element from Settings. It does not scan windows,
 * inspect activities, traverse page trees, use OCR, or inspect other apps.
 */
internal object SettingsClickDetector {
    fun detect(event: AccessibilityEvent, packageName: String): String? {
        if (packageName != SettingsClickGuardConfig.TARGET_PACKAGE) return null
        if (event.eventType != AccessibilityEvent.TYPE_VIEW_CLICKED) return null

        val labels = linkedSetOf<String>()
        event.text.forEach { value ->
            value?.toString()?.takeIf(String::isNotBlank)?.let(labels::add)
        }
        event.contentDescription
            ?.toString()
            ?.takeIf(String::isNotBlank)
            ?.let(labels::add)

        // Read only the source node that generated this click; do not traverse
        // parents, children or the active window.
        runCatching { event.source }.getOrNull()?.let { source ->
            source.text?.toString()?.takeIf(String::isNotBlank)?.let(labels::add)
            source.contentDescription?.toString()?.takeIf(String::isNotBlank)?.let(labels::add)
        }

        return SettingsClickMatcher.match(
            packageName = packageName,
            isViewClick = true,
            clickedLabels = labels
        )
    }
}
