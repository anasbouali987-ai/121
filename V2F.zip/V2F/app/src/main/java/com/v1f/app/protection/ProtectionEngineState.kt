package com.v1f.app.protection

/** Internal diagnostic state; it is never exposed in the application UI. */
data class ProtectionEngineState(
    val active: Boolean = false,
    val sessionId: String? = null,
    val enabledModules: Set<String> = emptySet()
)
