package com.v1f.app.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Apps
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import com.v1f.app.AppGraph
import com.v1f.app.model.InstalledApp
import com.v1f.app.ui.components.CelestialButton
import com.v1f.app.ui.components.GlassSurface
import com.v1f.app.ui.components.StatusPill
import com.v1f.app.ui.theme.V1FColors
import com.v1f.app.ui.theme.V1FDimensions

enum class AppFilter { All, User, System }

@Composable
fun AppSelectionScreen(
    initialSelection: Set<String>,
    onBack: () -> Unit,
    onNext: (Set<String>) -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)
    var selected by remember(initialSelection) { mutableStateOf(initialSelection) }
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf(AppFilter.All) }
    val apps by produceState<List<InstalledApp>?>(initialValue = null) {
        value = AppGraph.installedAppsRepository.loadInstalledApps()
    }

    val filteredApps = apps.orEmpty().filter { app ->
        val matchesQuery = query.isBlank() ||
            app.label.contains(query, ignoreCase = true) ||
            app.packageName.contains(query, ignoreCase = true)
        val matchesFilter = when (filter) {
            AppFilter.All -> true
            AppFilter.User -> !app.isSystem
            AppFilter.System -> app.isSystem
        }
        matchesQuery && matchesFilter
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = V1FDimensions.ScreenHorizontal)
            .padding(top = 16.dp, bottom = 18.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            BackIcon(onBack)
            StatusPill("${selected.size} مختارة", if (selected.isEmpty()) V1FColors.Gold else V1FColors.Cyan)
        }

        Spacer(Modifier.height(15.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier.size(48.dp).background(V1FColors.Violet.copy(alpha = 0.12f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Outlined.Apps, null, tint = V1FColors.VioletSoft)
            }
            Spacer(Modifier.size(12.dp))
            Column {
                Text("اختر التطبيقات", style = MaterialTheme.typography.headlineMedium, color = V1FColors.MoonWhite)
                Text("تظهر تطبيقات المستخدم والنظام، بما فيها الإعدادات", style = MaterialTheme.typography.bodyMedium, color = V1FColors.TextSecondary)
            }
        }

        Spacer(Modifier.height(15.dp))

        TextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("ابحث بالاسم أو اسم الحزمة") },
            leadingIcon = { Icon(Icons.Outlined.Search, null) },
            singleLine = true,
            shape = RoundedCornerShape(20.dp),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = V1FColors.GlassStrong,
                unfocusedContainerColor = V1FColors.Glass,
                focusedTextColor = V1FColors.MoonWhite,
                unfocusedTextColor = V1FColors.MoonWhite,
                focusedIndicatorColor = Color.Transparent,
                unfocusedIndicatorColor = Color.Transparent,
                focusedLeadingIconColor = V1FColors.Cyan,
                unfocusedLeadingIconColor = V1FColors.TextMuted,
                focusedPlaceholderColor = V1FColors.TextMuted,
                unfocusedPlaceholderColor = V1FColors.TextMuted
            )
        )

        Spacer(Modifier.height(11.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip("الكل", AppFilter.All, filter) { filter = it }
            FilterChip("المستخدم", AppFilter.User, filter) { filter = it }
            FilterChip("النظام", AppFilter.System, filter) { filter = it }
        }

        Spacer(Modifier.height(11.dp))

        GlassSurface(
            modifier = Modifier.fillMaxWidth(),
            padding = PaddingValues(horizontal = 14.dp, vertical = 11.dp),
            accent = if (selected.isNotEmpty()) V1FColors.Cyan else null
        ) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("عدد التطبيقات", style = MaterialTheme.typography.bodyMedium, color = V1FColors.TextSecondary)
                Text("${selected.size} تطبيق", style = MaterialTheme.typography.labelLarge, color = if (selected.isEmpty()) V1FColors.Gold else V1FColors.Cyan)
            }
        }

        Spacer(Modifier.height(10.dp))

        if (apps == null) {
            Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = V1FColors.Cyan)
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(9.dp),
                contentPadding = PaddingValues(vertical = 3.dp)
            ) {
                items(filteredApps, key = { it.packageName }) { app ->
                    AppRow(
                        app = app,
                        selected = app.packageName in selected,
                        onToggle = {
                            if (!app.isCritical) {
                                selected = if (app.packageName in selected) {
                                    selected - app.packageName
                                } else {
                                    selected + app.packageName
                                }
                            }
                        }
                    )
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        CelestialButton(
            text = if (selected.isEmpty()) "اختر تطبيقًا واحدًا على الأقل" else "OKAY · اختيار المدة",
            enabled = selected.isNotEmpty(),
            onClick = { onNext(selected) }
        )
    }
}

@Composable
private fun AppRow(app: InstalledApp, selected: Boolean, onToggle: () -> Unit) {
    val bitmap = remember(app.packageName) {
        runCatching { app.icon.toBitmap(96, 96).asImageBitmap() }.getOrNull()
    }
    GlassSurface(
        modifier = Modifier.fillMaxWidth(),
        padding = PaddingValues(horizontal = 14.dp, vertical = 12.dp),
        accent = if (selected) V1FColors.Cyan else null,
        enabled = !app.isCritical,
        onClick = onToggle
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier.size(48.dp).clip(RoundedCornerShape(14.dp)).background(Color.White.copy(alpha = 0.06f)),
                contentAlignment = Alignment.Center
            ) {
                if (bitmap != null) {
                    Image(bitmap = bitmap, contentDescription = null, modifier = Modifier.size(39.dp))
                } else {
                    Icon(Icons.Outlined.Apps, null, tint = V1FColors.TextMuted)
                }
            }
            Spacer(Modifier.size(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(app.label, style = MaterialTheme.typography.titleMedium, color = if (app.isCritical) V1FColors.TextMuted else V1FColors.MoonWhite, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(app.packageName, style = MaterialTheme.typography.bodySmall, color = V1FColors.TextMuted, maxLines = 1, overflow = TextOverflow.Ellipsis)
                when {
                    app.isCritical -> {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.Lock, null, tint = V1FColors.Gold, modifier = Modifier.size(13.dp))
                            Spacer(Modifier.size(4.dp))
                            Text("أساسي للنظام — يظهر ولا يمكن اختياره", style = MaterialTheme.typography.labelSmall, color = V1FColors.Gold)
                        }
                    }
                    app.isSettings -> {
                        Text("إعدادات الهاتف · قابل للاختيار", style = MaterialTheme.typography.labelSmall, color = V1FColors.Gold)
                    }
                    app.isSystem -> {
                        Text("تطبيق نظام", style = MaterialTheme.typography.labelSmall, color = V1FColors.VioletSoft)
                    }
                }
            }
            Checkbox(
                checked = selected,
                onCheckedChange = { onToggle() },
                enabled = !app.isCritical,
                colors = CheckboxDefaults.colors(
                    checkedColor = V1FColors.Cyan,
                    uncheckedColor = V1FColors.TextMuted,
                    checkmarkColor = V1FColors.SpaceBlack
                )
            )
        }
    }
}

@Composable
private fun FilterChip(
    text: String,
    value: AppFilter,
    selected: AppFilter,
    onSelect: (AppFilter) -> Unit
) {
    val isSelected = value == selected
    GlassSurface(
        padding = PaddingValues(horizontal = 13.dp, vertical = 8.dp),
        accent = if (isSelected) V1FColors.VioletSoft else null,
        onClick = { onSelect(value) }
    ) {
        Text(text, style = MaterialTheme.typography.labelMedium, color = if (isSelected) V1FColors.MoonWhite else V1FColors.TextSecondary)
    }
}

@Composable
private fun BackIcon(onBack: () -> Unit) {
    val interaction = remember { MutableInteractionSource() }
    Icon(
        imageVector = Icons.AutoMirrored.Outlined.ArrowBack,
        contentDescription = "رجوع",
        tint = V1FColors.MoonWhite,
        modifier = Modifier
            .size(40.dp)
            .clip(CircleShape)
            .clickable(interactionSource = interaction, indication = null, onClick = onBack)
            .padding(8.dp)
    )
}
