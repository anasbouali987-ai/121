package com.v1f.app.protection

sealed interface ProtectionDecision {
    data object Allow : ProtectionDecision

    data class BlockApplication(
        val packageName: String,
        val moduleId: String
    ) : ProtectionDecision

    data class InterceptSettingsClick(
        val packageName: String,
        val clickedLabel: String,
        val moduleId: String
    ) : ProtectionDecision
}
