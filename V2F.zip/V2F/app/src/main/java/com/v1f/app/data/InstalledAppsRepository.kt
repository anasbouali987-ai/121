package com.v1f.app.data

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import com.v1f.app.model.InstalledApp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.Collator
import java.util.Locale

class InstalledAppsRepository(private val context: Context) {
    suspend fun loadInstalledApps(): List<InstalledApp> = withContext(Dispatchers.IO) {
        val packageManager = context.packageManager
        val applications = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            packageManager.getInstalledApplications(
                PackageManager.ApplicationInfoFlags.of(PackageManager.MATCH_ALL.toLong())
            )
        } else {
            @Suppress("DEPRECATION")
            packageManager.getInstalledApplications(PackageManager.MATCH_ALL)
        }

        val settingsPackage = settingsPackageName()
        val criticalPackages = discoverCriticalPackages(packageManager)
        val collator = Collator.getInstance(Locale.getDefault())

        applications.mapNotNull { applicationInfo ->
            runCatching {
                val label = packageManager.getApplicationLabel(applicationInfo).toString()
                    .ifBlank { applicationInfo.packageName }
                InstalledApp(
                    label = label,
                    packageName = applicationInfo.packageName,
                    icon = packageManager.getApplicationIcon(applicationInfo),
                    isSystem = applicationInfo.flags and ApplicationInfo.FLAG_SYSTEM != 0,
                    isCritical = applicationInfo.packageName in criticalPackages &&
                        applicationInfo.packageName != settingsPackage,
                    isSettings = applicationInfo.packageName == settingsPackage
                )
            }.getOrNull()
        }
            .distinctBy { it.packageName }
            .sortedWith(
                compareByDescending<InstalledApp> { it.isSettings }
                    .thenComparator { first, second -> collator.compare(first.label, second.label) }
            )
    }

    fun settingsPackageName(): String {
        val intent = Intent(Settings.ACTION_SETTINGS)
        return context.packageManager.resolveActivity(
            intent,
            PackageManager.MATCH_DEFAULT_ONLY
        )?.activityInfo?.packageName ?: "com.android.settings"
    }

    private fun discoverCriticalPackages(packageManager: PackageManager): Set<String> {
        val packages = mutableSetOf(
            context.packageName,
            "android",
            "com.android.systemui",
            "com.android.permissioncontroller",
            "com.google.android.permissioncontroller",
            "com.android.packageinstaller",
            "com.google.android.packageinstaller"
        )

        val homeIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val dialIntent = Intent(Intent.ACTION_DIAL)

        packages += packageManager.queryIntentActivities(homeIntent, PackageManager.MATCH_ALL)
            .map { it.activityInfo.packageName }
        packages += packageManager.queryIntentActivities(dialIntent, PackageManager.MATCH_ALL)
            .map { it.activityInfo.packageName }

        val inputMethodManager = context.getSystemService(Context.INPUT_METHOD_SERVICE) as
            android.view.inputmethod.InputMethodManager
        packages += inputMethodManager.inputMethodList.map { it.packageName }

        return packages
    }
}
