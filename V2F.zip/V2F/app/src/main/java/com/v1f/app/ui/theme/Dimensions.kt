package com.v1f.app.ui.theme

import androidx.compose.ui.unit.dp

object V1FDimensions {
    val ScreenHorizontal = 21.dp
    val CardRadius = 26.dp
    val ButtonRadius = 22.dp
    val CardPadding = 18.dp
}
