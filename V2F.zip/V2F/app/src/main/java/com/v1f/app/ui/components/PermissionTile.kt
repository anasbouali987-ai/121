package com.v1f.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.v1f.app.ui.theme.V1FColors

@Composable
fun PermissionTile(
    icon: ImageVector,
    title: String,
    description: String,
    accent: Color,
    status: String,
    enabled: Boolean,
    locked: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val effectiveAccent = if (locked) V1FColors.StrictRed else accent
    GlassSurface(
        modifier = modifier,
        padding = PaddingValues(17.dp),
        accent = if (locked) V1FColors.StrictRed else if (enabled) accent else null,
        pulseAccent = locked,
        enabled = !locked,
        onClick = onClick
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(modifier = Modifier.size(46.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.size(46.dp)) {
                    drawCircle(effectiveAccent.copy(alpha = 0.12f))
                    drawCircle(
                        color = effectiveAccent.copy(alpha = 0.34f),
                        style = Stroke(1.3f)
                    )
                }
                Icon(
                    imageVector = if (locked) Icons.Rounded.Lock else icon,
                    contentDescription = null,
                    tint = effectiveAccent,
                    modifier = Modifier.size(23.dp)
                )
            }

            Spacer(Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium, color = V1FColors.MoonWhite)
                Text(description, style = MaterialTheme.typography.bodyMedium, color = V1FColors.TextSecondary)
            }

            Spacer(Modifier.width(10.dp))

            Column(horizontalAlignment = Alignment.End) {
                Text(status, style = MaterialTheme.typography.labelMedium, color = effectiveAccent)
                if (!locked) {
                    Icon(
                        Icons.AutoMirrored.Rounded.ArrowForward,
                        contentDescription = null,
                        tint = V1FColors.TextMuted,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}
