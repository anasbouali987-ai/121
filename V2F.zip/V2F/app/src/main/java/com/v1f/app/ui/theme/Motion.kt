package com.v1f.app.ui.theme

object V1FMotion {
    const val ScreenTransition = 420
    const val Entry = 620
    const val EntryDelay = 90
    const val CoreBreath = 3_600
    const val CoreRingRotation = 18_000
    const val CoreOrbitRotation = 26_000
    const val StarTwinkle = 5_800
    const val AuroraDrift = 16_000
    const val StrictPulse = 3_200
}
