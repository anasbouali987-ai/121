package com.v1f.app.protection.modules.settings

import com.v1f.app.protection.ProtectionContext
import com.v1f.app.protection.ProtectionDecision
import com.v1f.app.protection.ProtectionModule

/**
 * Invisible Protection Engine module enabled automatically during a session.
 * It intercepts only exact UI clicks inside com.android.settings.
 */
class SettingsClickGuardModule : ProtectionModule {
    override val id: String = ID

    override fun evaluate(context: ProtectionContext): ProtectionDecision {
        val label = SettingsClickDetector.detect(context.event, context.packageName)
            ?: return ProtectionDecision.Allow

        return ProtectionDecision.InterceptSettingsClick(
            packageName = context.packageName,
            clickedLabel = label,
            moduleId = id
        )
    }

    companion object {
        const val ID = "settings_click_guard"
    }
}
