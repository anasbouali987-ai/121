# V1F currently keeps release minification disabled.
# Add feature-specific rules before enabling R8 shrinking.
