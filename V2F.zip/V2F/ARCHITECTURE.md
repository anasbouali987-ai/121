# V2F architecture

```text
AccessibilityService
        │
        ▼
ProtectionEngine
├── SettingsClickGuardModule
│   ├── SettingsClickGuardConfig
│   ├── SettingsClickDetector
│   └── SettingsClickMatcher
└── AppGuardModule

Settings click decision
        │
        ▼
SettingsEscapeGuard
├── MeteorShieldOverlay (TYPE_ACCESSIBILITY_OVERLAY)
└── BACK × 3, 250 ms apart
```

## Design rules

- Protection Engine has no UI dependency and no user-facing controls.
- Modules start and stop atomically with the strict session.
- Settings Click Guard listens only to `TYPE_VIEW_CLICKED` from `com.android.settings`.
- It reads only the clicked event/source node and never traverses the active page.
- Application blocking remains independent and continues using window-change events.
- Future modules implement the same `ProtectionModule` contract.
