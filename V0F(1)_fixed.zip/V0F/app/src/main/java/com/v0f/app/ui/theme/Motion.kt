package com.v0f.app.ui.theme

object V0FMotion {
    const val ScreenTransition = 360
    const val Entry = 720
    const val EntryDelay = 95
    const val CoreBreath = 4200
    const val CoreRingRotation = 26000
    const val CoreOrbitRotation = 60000
    const val StarTwinkle = 9400
    const val AuroraDrift = 22000
}
