package com.v0f.app.ui.background

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.unit.dp
import com.v0f.app.ui.theme.V0FColors
import com.v0f.app.ui.theme.V0FMotion
import kotlin.math.sin
import kotlin.random.Random

private data class Star(
    val x: Float,
    val y: Float,
    val radius: Float,
    val alpha: Float,
    val phase: Float,
    val color: Color,
    val twinkles: Boolean,
    val prominent: Boolean
)

@Composable
fun CelestialSky(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    0f to V0FColors.SpaceBlack,
                    0.55f to V0FColors.DeepNight,
                    1f to V0FColors.Nebula
                )
            )
    ) {
        val starCount = when {
            maxWidth < 360.dp -> 88
            maxWidth < 500.dp -> 108
            else -> 132
        }
        val stars = remember(starCount) {
            generateStars(seed = 24017, count = starCount)
        }
        val staticStars = remember(stars) { stars.filterNot(Star::twinkles) }
        val twinklingStars = remember(stars) { stars.filter(Star::twinkles) }

        val transition = rememberInfiniteTransition(label = "v0f-sky")
        val time = transition.animateFloat(
            initialValue = 0f,
            targetValue = 6.28318f,
            animationSpec = infiniteRepeatable(
                animation = tween(
                    durationMillis = V0FMotion.StarTwinkle,
                    easing = LinearEasing
                ),
                repeatMode = RepeatMode.Restart
            ),
            label = "star-time"
        ).value
        val drift = transition.animateFloat(
            initialValue = -0.012f,
            targetValue = 0.012f,
            animationSpec = infiniteRepeatable(
                animation = tween(
                    durationMillis = V0FMotion.AuroraDrift,
                    easing = LinearEasing
                ),
                repeatMode = RepeatMode.Reverse
            ),
            label = "aurora-drift"
        ).value

        Canvas(Modifier.fillMaxSize()) {
            drawAurora(drift)
        }

        Canvas(Modifier.fillMaxSize()) {
            staticStars.forEach { drawStar(it, pulse = 1f) }
        }

        Canvas(Modifier.fillMaxSize()) {
            twinklingStars.forEach { star ->
                val pulse = 0.70f + 0.30f * ((sin(time + star.phase) + 1f) / 2f)
                drawStar(star, pulse)
            }

            drawRect(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color.Transparent,
                        Color.Transparent,
                        V0FColors.SpaceBlack.copy(alpha = 0.18f)
                    )
                )
            )
        }

        content()
    }
}

private fun DrawScope.drawAurora(drift: Float) {
    val violetCenter = Offset(
        x = size.width * (0.84f + drift),
        y = size.height * 0.28f
    )
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(
                V0FColors.Violet.copy(alpha = 0.16f),
                V0FColors.Violet.copy(alpha = 0.035f),
                Color.Transparent
            ),
            center = violetCenter,
            radius = size.minDimension * 0.76f
        ),
        radius = size.minDimension * 0.76f,
        center = violetCenter
    )

    val cyanCenter = Offset(
        x = size.width * (0.06f - drift),
        y = size.height * 0.16f
    )
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(
                V0FColors.Cyan.copy(alpha = 0.095f),
                V0FColors.Cyan.copy(alpha = 0.02f),
                Color.Transparent
            ),
            center = cyanCenter,
            radius = size.minDimension * 0.64f
        ),
        radius = size.minDimension * 0.64f,
        center = cyanCenter
    )
}

private fun DrawScope.drawStar(star: Star, pulse: Float) {
    val center = Offset(size.width * star.x, size.height * star.y)
    val finalAlpha = (star.alpha * pulse).coerceIn(0.12f, 1f)

    if (star.prominent) {
        drawCircle(
            color = star.color.copy(alpha = finalAlpha * 0.14f),
            radius = star.radius * 5.2f,
            center = center
        )
        drawLine(
            color = star.color.copy(alpha = finalAlpha * 0.28f),
            start = Offset(center.x - star.radius * 3.6f, center.y),
            end = Offset(center.x + star.radius * 3.6f, center.y),
            strokeWidth = 0.75f
        )
        drawLine(
            color = star.color.copy(alpha = finalAlpha * 0.28f),
            start = Offset(center.x, center.y - star.radius * 3.6f),
            end = Offset(center.x, center.y + star.radius * 3.6f),
            strokeWidth = 0.75f
        )
    }

    drawCircle(
        color = star.color.copy(alpha = finalAlpha),
        radius = star.radius,
        center = center
    )
}

private fun generateStars(seed: Int, count: Int): List<Star> {
    val random = Random(seed)
    return List(count) { index ->
        val prominent = index < 4
        val twinkles = index < 6
        val tone = when {
            index == 0 || index % 37 == 0 -> V0FColors.Gold
            index == 1 || index % 23 == 0 -> V0FColors.Cyan
            else -> V0FColors.MoonWhite
        }

        Star(
            x = random.nextFloat(),
            y = random.nextFloat(),
            radius = when {
                prominent -> 1.75f + random.nextFloat() * 0.55f
                index < 24 -> 1.05f + random.nextFloat() * 0.45f
                else -> 0.45f + random.nextFloat() * 0.60f
            },
            alpha = 0.30f + random.nextFloat() * 0.62f,
            phase = random.nextFloat() * 6.28318f,
            color = tone,
            twinkles = twinkles,
            prominent = prominent
        )
    }
}
