package com.v0f.app.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.v0f.app.R
import com.v0f.app.ui.components.CelestialButton
import com.v0f.app.ui.components.CompactGlassButton
import com.v0f.app.ui.components.ProtectionCore
import com.v0f.app.ui.components.SetupProgressCard
import com.v0f.app.ui.components.StatusPill
import com.v0f.app.ui.model.ProtectionState
import com.v0f.app.ui.theme.V0FColors
import com.v0f.app.ui.theme.V0FDimensions
import com.v0f.app.ui.theme.V0FMotion
import kotlinx.coroutines.delay

@Composable
fun HomeScreen(
    onOpenPermissions: () -> Unit,
    modifier: Modifier = Modifier
) {
    var entered by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        delay(90)
        entered = true
    }

    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val compact = maxHeight < 700.dp
        val compactHeader = maxWidth < 370.dp
        val coreSize = if (compact) 182.dp else 208.dp
        val sectionGap = if (compact) 13.dp else 18.dp

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = V0FDimensions.ScreenHorizontal)
                .padding(top = 15.dp, bottom = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Header(
                compact = compactHeader,
                onOpenPermissions = onOpenPermissions
            )

            Spacer(Modifier.height(if (compact) 10.dp else 16.dp))

            AnimatedVisibility(
                visible = entered,
                enter = fadeIn(tween(V0FMotion.Entry)) +
                    slideInVertically(tween(V0FMotion.Entry)) { it / 10 }
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    ProtectionCore(
                        state = ProtectionState.SetupRequired,
                        coreSize = coreSize
                    )
                    StatusPill(
                        text = stringResource(R.string.setup_needed),
                        accent = V0FColors.Gold
                    )
                }
            }

            Spacer(Modifier.height(sectionGap))

            AnimatedVisibility(
                visible = entered,
                enter = fadeIn(
                    tween(
                        durationMillis = V0FMotion.Entry,
                        delayMillis = V0FMotion.EntryDelay
                    )
                ) + slideInVertically(
                    tween(
                        durationMillis = V0FMotion.Entry,
                        delayMillis = V0FMotion.EntryDelay
                    )
                ) { it / 9 }
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = stringResource(R.string.hero_title),
                        style = MaterialTheme.typography.displaySmall,
                        color = V0FColors.MoonWhite,
                        textAlign = TextAlign.Center
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = stringResource(R.string.hero_subtitle),
                        style = MaterialTheme.typography.bodyLarge,
                        color = V0FColors.TextSecondary,
                        textAlign = TextAlign.Center
                    )
                }
            }

            Spacer(Modifier.height(if (compact) 17.dp else 23.dp))

            AnimatedVisibility(
                visible = entered,
                enter = fadeIn(
                    tween(
                        durationMillis = V0FMotion.Entry,
                        delayMillis = V0FMotion.EntryDelay * 2
                    )
                ) + slideInVertically(
                    tween(
                        durationMillis = V0FMotion.Entry,
                        delayMillis = V0FMotion.EntryDelay * 2
                    )
                ) { it / 8 }
            ) {
                SetupProgressCard()
            }

            Spacer(Modifier.height(if (compact) 15.dp else 20.dp))

            AnimatedVisibility(
                visible = entered,
                enter = fadeIn(
                    tween(
                        durationMillis = V0FMotion.Entry,
                        delayMillis = V0FMotion.EntryDelay * 3
                    )
                ) + slideInVertically(
                    tween(
                        durationMillis = V0FMotion.Entry,
                        delayMillis = V0FMotion.EntryDelay * 3
                    )
                ) { it / 7 }
            ) {
                CelestialButton(
                    text = stringResource(R.string.start_setup),
                    onClick = onOpenPermissions
                )
            }

            Spacer(Modifier.height(18.dp))

            Text(
                text = stringResource(R.string.visual_release),
                style = MaterialTheme.typography.labelMedium,
                color = V0FColors.TextMuted
            )
        }
    }
}

@Composable
private fun Header(
    compact: Boolean,
    onOpenPermissions: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape),
                contentAlignment = Alignment.Center
            ) {
                androidx.compose.foundation.Canvas(Modifier.fillMaxSize()) {
                    drawCircle(V0FColors.Violet.copy(alpha = 0.14f))
                    drawCircle(
                        color = V0FColors.VioletSoft.copy(alpha = 0.32f),
                        style = androidx.compose.ui.graphics.drawscope.Stroke(1.2f)
                    )
                }
                Icon(
                    imageVector = Icons.Outlined.AutoAwesome,
                    contentDescription = null,
                    tint = V0FColors.Gold,
                    modifier = Modifier.size(21.dp)
                )
            }

            Spacer(Modifier.width(10.dp))

            Column {
                Text(
                    text = stringResource(R.string.app_name),
                    style = MaterialTheme.typography.titleLarge,
                    color = V0FColors.MoonWhite
                )
                if (!compact) {
                    Text(
                        text = stringResource(R.string.brand_subtitle),
                        style = MaterialTheme.typography.labelMedium,
                        color = V0FColors.TextMuted
                    )
                }
            }
        }

        CompactGlassButton(
            text = stringResource(
                if (compact) R.string.permissions_short else R.string.all_permissions
            ),
            onClick = onOpenPermissions
        )
    }
}
