package com.v0f.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.v0f.app.ui.theme.V0FColors
import com.v0f.app.ui.theme.V0FDimensions

@Composable
fun GlassSurface(
    modifier: Modifier = Modifier,
    padding: PaddingValues = PaddingValues(V0FDimensions.CardPadding),
    elevated: Boolean = false,
    onClick: (() -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit
) {
    val shape = RoundedCornerShape(V0FDimensions.CardRadius)
    val interaction = remember { MutableInteractionSource() }
    val clickModifier = if (onClick == null) {
        Modifier
    } else {
        Modifier.clickable(
            interactionSource = interaction,
            indication = null,
            onClick = onClick
        )
    }

    Box(
        modifier = modifier
            .then(
                if (elevated) {
                    Modifier.shadow(
                        elevation = 14.dp,
                        shape = shape,
                        ambientColor = Color.Black.copy(alpha = 0.48f),
                        spotColor = Color.Black.copy(alpha = 0.48f)
                    )
                } else {
                    Modifier
                }
            )
            .clip(shape)
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        V0FColors.GlassStrong,
                        V0FColors.Glass
                    )
                )
            )
            .border(
                width = 1.dp,
                brush = Brush.verticalGradient(
                    colors = listOf(
                        V0FColors.GlassHighlight,
                        V0FColors.GlassBorder
                    )
                ),
                shape = shape
            )
            .then(clickModifier)
            .padding(padding),
        content = content
    )
}
