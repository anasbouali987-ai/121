package com.v0f.app.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.v0f.app.R
import com.v0f.app.ui.model.ProtectionState
import com.v0f.app.ui.theme.V0FColors
import com.v0f.app.ui.theme.V0FMotion
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun ProtectionCore(
    state: ProtectionState,
    modifier: Modifier = Modifier,
    coreSize: Dp = 208.dp
) {
    val stateColor by animateColorAsState(
        targetValue = when (state) {
            ProtectionState.SetupRequired -> V0FColors.Gold
            ProtectionState.Ready -> V0FColors.Cyan
            ProtectionState.Protected -> V0FColors.Mint
            ProtectionState.Alert -> V0FColors.Coral
        },
        animationSpec = tween(700),
        label = "core-state-color"
    )

    val transition = rememberInfiniteTransition(label = "v0f-core")
    val breath = transition.animateFloat(
        initialValue = 0.965f,
        targetValue = 1.018f,
        animationSpec = infiniteRepeatable(
            animation = tween(V0FMotion.CoreBreath),
            repeatMode = RepeatMode.Reverse
        ),
        label = "core-breath"
    ).value
    val ringRotation = transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = V0FMotion.CoreRingRotation,
                easing = LinearEasing
            ),
            repeatMode = RepeatMode.Restart
        ),
        label = "core-ring"
    ).value
    val orbitRotation = transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = V0FMotion.CoreOrbitRotation,
                easing = LinearEasing
            ),
            repeatMode = RepeatMode.Restart
        ),
        label = "core-orbit"
    ).value

    Box(
        modifier = modifier
            .size(coreSize)
            .graphicsLayer {
                scaleX = breath
                scaleY = breath
            },
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val c = center
            val diameter = this.size.minDimension

            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        stateColor.copy(alpha = 0.24f),
                        stateColor.copy(alpha = 0.07f),
                        Color.Transparent
                    ),
                    center = c,
                    radius = diameter * 0.50f
                ),
                radius = diameter * 0.50f,
                center = c
            )

            drawCircle(
                color = Color.White.copy(alpha = 0.035f),
                radius = diameter * 0.43f,
                center = c
            )

            rotate(orbitRotation, pivot = c) {
                drawCircle(
                    color = V0FColors.MoonWhite.copy(alpha = 0.13f),
                    radius = diameter * 0.42f,
                    center = c,
                    style = Stroke(width = 1.1f)
                )

                repeat(3) { index ->
                    val angle = Math.toRadians(index * 120.0)
                    val orbitRadius = diameter * 0.42f
                    val point = Offset(
                        x = c.x + (cos(angle) * orbitRadius).toFloat(),
                        y = c.y + (sin(angle) * orbitRadius).toFloat()
                    )
                    drawCircle(
                        color = if (index == 1) V0FColors.Cyan else stateColor,
                        radius = if (index == 1) 4.0f else 3.1f,
                        center = point
                    )
                }
            }

            rotate(ringRotation, pivot = c) {
                drawArc(
                    brush = Brush.sweepGradient(
                        colors = listOf(
                            stateColor.copy(alpha = 0.18f),
                            stateColor,
                            V0FColors.Cyan.copy(alpha = 0.80f),
                            Color.Transparent,
                            stateColor.copy(alpha = 0.18f)
                        ),
                        center = c
                    ),
                    startAngle = 0f,
                    sweepAngle = 326f,
                    useCenter = false,
                    topLeft = Offset(diameter * 0.14f, diameter * 0.14f),
                    size = androidx.compose.ui.geometry.Size(
                        width = diameter * 0.72f,
                        height = diameter * 0.72f
                    ),
                    style = Stroke(width = 4.2f, cap = StrokeCap.Round)
                )
            }

            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color(0xFF172142),
                        Color(0xFF090D20),
                        Color(0xFF03050D)
                    ),
                    center = c,
                    radius = diameter * 0.30f
                ),
                radius = diameter * 0.29f,
                center = c
            )
            drawCircle(
                color = stateColor.copy(alpha = 0.58f),
                radius = diameter * 0.29f,
                center = c,
                style = Stroke(width = 1.9f)
            )
            drawCircle(
                color = Color.White.copy(alpha = 0.10f),
                radius = diameter * 0.25f,
                center = c,
                style = Stroke(width = 1f)
            )

            drawCoreStar(
                center = Offset(c.x, c.y - diameter * 0.070f),
                radius = diameter * 0.075f,
                color = stateColor
            )
        }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.graphicsLayer { translationY = coreSize.toPx() * 0.105f }
        ) {
            Text(
                text = stringResource(R.string.core_label),
                style = MaterialTheme.typography.labelMedium,
                color = V0FColors.TextSecondary
            )
            Text(
                text = stringResource(R.string.core_progress),
                style = MaterialTheme.typography.titleMedium,
                color = V0FColors.MoonWhite
            )
        }
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawCoreStar(
    center: Offset,
    radius: Float,
    color: Color
) {
    val points = listOf(
        Offset(center.x, center.y - radius),
        Offset(center.x + radius * 0.22f, center.y - radius * 0.22f),
        Offset(center.x + radius, center.y),
        Offset(center.x + radius * 0.22f, center.y + radius * 0.22f),
        Offset(center.x, center.y + radius),
        Offset(center.x - radius * 0.22f, center.y + radius * 0.22f),
        Offset(center.x - radius, center.y),
        Offset(center.x - radius * 0.22f, center.y - radius * 0.22f)
    )

    val path = Path().apply {
        moveTo(points.first().x, points.first().y)
        points.drop(1).forEach { lineTo(it.x, it.y) }
        close()
    }

    drawPath(
        path = path,
        brush = Brush.radialGradient(
            colors = listOf(V0FColors.MoonWhite, color),
            center = center,
            radius = radius
        )
    )
}
