package com.v0f.app.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import com.v0f.app.ui.background.CelestialSky
import com.v0f.app.ui.screens.HomeScreen
import com.v0f.app.ui.screens.PermissionsScreen
import com.v0f.app.ui.theme.V0FMotion

private enum class V0FScreen {
    Home,
    Permissions
}

@Composable
fun V0FApp() {
    var screen by remember { mutableStateOf(V0FScreen.Home) }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        CelestialSky {
            AnimatedContent(
                targetState = screen,
                transitionSpec = {
                    val duration = V0FMotion.ScreenTransition
                    if (targetState == V0FScreen.Permissions) {
                        (
                            slideInHorizontally(tween(duration)) { it / 7 } +
                                fadeIn(tween(duration))
                            ) togetherWith (
                            slideOutHorizontally(tween(duration)) { -it / 10 } +
                                fadeOut(tween(duration))
                            )
                    } else {
                        (
                            slideInHorizontally(tween(duration)) { -it / 7 } +
                                fadeIn(tween(duration))
                            ) togetherWith (
                            slideOutHorizontally(tween(duration)) { it / 10 } +
                                fadeOut(tween(duration))
                            )
                    }
                },
                label = "v0f-screen"
            ) { destination ->
                val safeModifier = Modifier
                    .fillMaxSize()
                    .windowInsetsPadding(WindowInsets.systemBars)

                when (destination) {
                    V0FScreen.Home -> HomeScreen(
                        onOpenPermissions = { screen = V0FScreen.Permissions },
                        modifier = safeModifier
                    )

                    V0FScreen.Permissions -> PermissionsScreen(
                        onBack = { screen = V0FScreen.Home },
                        modifier = safeModifier
                    )
                }
            }
        }
    }
}
