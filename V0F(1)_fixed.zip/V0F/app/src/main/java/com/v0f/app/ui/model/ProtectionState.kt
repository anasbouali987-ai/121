package com.v0f.app.ui.model

enum class ProtectionState {
    SetupRequired,
    Ready,
    Protected,
    Alert
}
