package com.v0f.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.v0f.app.ui.theme.V0FColors

@Composable
fun PermissionTile(
    icon: ImageVector,
    title: String,
    description: String,
    accent: Color,
    status: String,
    modifier: Modifier = Modifier
) {
    GlassSurface(
        modifier = modifier,
        padding = PaddingValues(17.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier.size(46.dp),
                contentAlignment = Alignment.Center
            ) {
                Canvas(Modifier.size(46.dp)) {
                    drawCircle(accent.copy(alpha = 0.12f))
                    drawCircle(
                        color = accent.copy(alpha = 0.28f),
                        style = androidx.compose.ui.graphics.drawscope.Stroke(1.3f)
                    )
                }
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accent,
                    modifier = Modifier.size(23.dp)
                )
            }

            Spacer(Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    color = V0FColors.MoonWhite
                )
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = V0FColors.TextSecondary
                )
            }

            Spacer(Modifier.width(10.dp))

            Text(
                text = status,
                style = MaterialTheme.typography.labelMedium,
                color = accent
            )
        }
    }
}
