package com.v0f.app.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.AccessibilityNew
import androidx.compose.material.icons.outlined.AdminPanelSettings
import androidx.compose.material.icons.outlined.BatterySaver
import androidx.compose.material.icons.outlined.ShieldMoon
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.v0f.app.R
import com.v0f.app.ui.components.GlassSurface
import com.v0f.app.ui.components.PermissionTile
import com.v0f.app.ui.components.StatusPill
import com.v0f.app.ui.theme.V0FColors
import com.v0f.app.ui.theme.V0FDimensions

@Composable
fun PermissionsScreen(
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)
    val backInteraction = remember { MutableInteractionSource() }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = V0FDimensions.ScreenHorizontal)
            .padding(top = 18.dp, bottom = 30.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Outlined.ArrowBack,
                contentDescription = stringResource(R.string.back),
                tint = V0FColors.MoonWhite,
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .clickable(
                        interactionSource = backInteraction,
                        indication = null,
                        onClick = onBack
                    )
                    .padding(8.dp)
            )
            StatusPill(
                text = stringResource(R.string.coming_v1),
                accent = V0FColors.Cyan
            )
        }

        Spacer(Modifier.height(28.dp))

        Icon(
            imageVector = Icons.Outlined.ShieldMoon,
            contentDescription = null,
            tint = V0FColors.VioletSoft,
            modifier = Modifier
                .size(52.dp)
                .align(Alignment.CenterHorizontally)
        )

        Spacer(Modifier.height(15.dp))

        Text(
            text = stringResource(R.string.permissions_title),
            style = MaterialTheme.typography.displaySmall,
            color = V0FColors.MoonWhite,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(8.dp))

        Text(
            text = stringResource(R.string.permissions_subtitle),
            style = MaterialTheme.typography.bodyLarge,
            color = V0FColors.TextSecondary,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(24.dp))

        GlassSurface(
            modifier = Modifier.fillMaxWidth(),
            padding = PaddingValues(17.dp),
            elevated = true
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = stringResource(R.string.permissions_progress),
                    style = MaterialTheme.typography.titleMedium,
                    color = V0FColors.MoonWhite,
                    modifier = Modifier.weight(1f)
                )
                Text(
                    text = stringResource(R.string.core_progress),
                    style = MaterialTheme.typography.labelLarge,
                    color = V0FColors.Gold
                )
            }
        }

        Spacer(Modifier.height(14.dp))

        PermissionTile(
            icon = Icons.Outlined.AccessibilityNew,
            title = stringResource(R.string.permission_accessibility),
            description = stringResource(R.string.permission_accessibility_description),
            accent = V0FColors.Cyan,
            status = stringResource(R.string.required),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(12.dp))

        PermissionTile(
            icon = Icons.Outlined.AdminPanelSettings,
            title = stringResource(R.string.permission_admin),
            description = stringResource(R.string.permission_admin_description),
            accent = V0FColors.VioletSoft,
            status = stringResource(R.string.required),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(12.dp))

        PermissionTile(
            icon = Icons.Outlined.BatterySaver,
            title = stringResource(R.string.permission_background),
            description = stringResource(R.string.permission_background_description),
            accent = V0FColors.Mint,
            status = stringResource(R.string.required),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(24.dp))

        Text(
            text = stringResource(R.string.preview_notice),
            style = MaterialTheme.typography.bodyMedium,
            color = V0FColors.TextMuted,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
    }
}
