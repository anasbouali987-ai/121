package com.v0f.app.ui.theme

import androidx.compose.ui.unit.dp

object V0FDimensions {
    val ScreenHorizontal = 21.dp
    val CardRadius = 26.dp
    val ButtonRadius = 22.dp
    val CardPadding = 18.dp
}
