package com.v0f.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val V0FColorScheme = darkColorScheme(
    primary = V0FColors.Violet,
    onPrimary = V0FColors.MoonWhite,
    secondary = V0FColors.Cyan,
    onSecondary = V0FColors.SpaceBlack,
    tertiary = V0FColors.Mint,
    background = V0FColors.SpaceBlack,
    onBackground = V0FColors.MoonWhite,
    surface = V0FColors.DeepNight,
    onSurface = V0FColors.MoonWhite,
    error = V0FColors.Coral
)

@Composable
fun V0FTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = V0FColorScheme,
        typography = V0FTypography,
        content = content
    )
}
