# V0F Design System

## Design principle

Luxury comes from a small number of strong elements, generous spacing, and movement that is felt more than noticed.

The visual language is:

- calm
- protective
- celestial
- disciplined
- premium without excess

## Main hierarchy

The home screen contains only:

1. Brand mark
2. Protection Core
3. Global state
4. One short message
5. One setup summary
6. One primary action
7. One visible entry to all permissions

Individual permission controls never occupy the center of the home screen.

## Color balance

- 85% deep navy and near-black
- 10% moon white and blue-gray text
- 5% functional accent

Functional colors:

- Gold: setup required
- Cyan: ready
- Mint: protected
- Coral: alert
- Violet: brand identity, used sparingly

## Protection Core

The core is the principal identity element.

It has three visual layers:

- outer breathing glow
- orbit rotating once every 60 seconds
- gradient ring rotating once every 26 seconds
- stable dark inner core

The core state color changes without changing the structure.

## Sky

- Deterministic seed
- 88–132 stars depending on screen width
- Four prominent stars
- Six twinkling stars only
- No particle system
- No repeated shooting star
- No 3D planet
- No video background
- No live blur
- Aurora drift is limited to 1.2% of screen width

## Glass

Pseudo-glass is created using:

- low-opacity surface
- faint upper highlight
- one-pixel border
- restrained black shadow for important cards only

Never use live background blur in V0F.

## Motion

- Screen transition: 360 ms
- Entry sequence: 720 ms
- Core breath: 4.2 s
- Ring rotation: 26 s
- Orbit rotation: 60 s
- Star cycle: 9.4 s
- Aurora drift: 22 s

Motion must never compete with the primary action or the Protection Core.

## Typography

One system sans-serif family is used.

Primary roles:

- hero title
- section title
- body and status

Avoid adding decorative typefaces or excessive letter spacing to Arabic text.

## Accessibility and expansion

V1 can connect real permission state without redesigning the UI. The core and status colors already support:

- SetupRequired
- Ready
- Protected
- Alert
