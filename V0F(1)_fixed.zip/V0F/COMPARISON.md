# Comparison of the three V0 experiments

## Experiment 1

### Strongest ideas

- Closest to the agreed product layout.
- Best visible “All permissions” entry.
- Clear setup progress card.
- Permission sheet is discoverable and practical.
- Strong state-color vocabulary.

### Problems corrected in V0F

- The main layout was not scrollable, creating risk on short screens.
- The primary button arrow lacked safe edge padding.
- Glass shadows were heavier than necessary.
- Ring rotation did not use linear easing, so the loop could feel less natural.
- The permission UI was a sheet, while a dedicated page scales better for V1.

## Experiment 2

### Strongest ideas

- Cleanest and most economical code.
- Strong Design Lab concept.
- Simple, readable component boundaries.
- Attractive core with text inside.
- Responsive scrollable home screen.

### Problems corrected in V0F

- “READY” conflicted with the visible 0/3 setup state.
- Design Lab was the main user action instead of an internal tool.
- Twinkling stars shared one synchronized pulse.
- The lower background became too purple.
- There was no true permissions page.
- Design Lab would ship in release without a debug-only boundary.

## Experiment 3

### Strongest ideas

- Best overall project completeness.
- Strongest navigation structure.
- Best launcher resources and documentation.
- Good active/inactive visual state.
- Dedicated permissions screen.
- Strong separation for future V1 logic.

### Problems corrected in V0F

- The home screen was more crowded than the agreed minimal layout.
- Permissions were hidden behind five secret taps and were not discoverable.
- Constellation, film grain, Aurora, stars, metrics, and demo cards competed for attention.
- Film grain was regenerated during animated redraws.
- Fourteen stars twinkled instead of the restrained target of five or six.
- The system-bar padding plus large top padding created excessive empty space.
- The core did not directly express the setup state.

## V0F synthesis

V0F keeps:

- Experiment 1’s product hierarchy and visible permissions entry.
- Experiment 2’s economy, core text, and clean component style.
- Experiment 3’s architecture, separate permissions screen, state model, app icon, and documentation.

V0F removes:

- hidden navigation
- synchronized or excessive twinkling
- film grain
- constellation clutter
- demo metrics
- release Design Lab
- heavy blur and heavy shadows
- inconsistent status messaging
