# V0F

**V0F** is the finalized visual prototype for a future Android focus and self-control application.

This release intentionally contains **UI only**. It does not request Accessibility, Device Administrator, notification, or background-service permissions, and it does not block applications.

## What V0F contains

- RTL-first Arabic interface with an English resource fallback.
- A calm full-screen night sky.
- Deterministic star positions using a fixed seed.
- Four prominent stars and only six twinkling stars.
- Subtle, slow Aurora movement.
- A three-layer animated Protection Core.
- A visible but unobtrusive “All permissions” entry.
- A separate permissions preview screen.
- Pseudo-glass surfaces without live blur.
- Responsive spacing for shorter screens.
- A state model prepared for Setup, Ready, Protected, and Alert states.

## Build locally

Requirements:

- JDK 17
- Android SDK 35
- Gradle 8.9, or use the included bootstrap script

Linux/macOS:

```bash
chmod +x gradlew
./gradlew :app:assembleDebug
```

Windows:

```bat
gradlew.bat :app:assembleDebug
```

Expected APK:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Build on GitHub

The workflow is deliberately distributed as a **separate file**, not inside this ZIP.

1. Upload this ZIP to a GitHub repository.
2. Place `build-any-zip.yml` at:
   `.github/workflows/build-any-zip.yml`
3. Commit both files.
4. Open **Actions → Build APK from any ZIP**.
5. Download the generated APK artifact.

The workflow detects a ZIP regardless of its filename, extracts it, finds the Gradle project, and builds the debug APK.
