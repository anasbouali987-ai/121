# V0F UI architecture

```text
app/src/main/java/com/v0f/app/
├── MainActivity.kt
└── ui/
    ├── V0FApp.kt
    ├── model/
    │   └── ProtectionState.kt
    ├── background/
    │   └── CelestialSky.kt
    ├── components/
    │   ├── CelestialButton.kt
    │   ├── CompactGlassButton.kt
    │   ├── GlassSurface.kt
    │   ├── PermissionTile.kt
    │   ├── ProtectionCore.kt
    │   ├── SetupProgressCard.kt
    │   └── StatusPill.kt
    ├── screens/
    │   ├── HomeScreen.kt
    │   └── PermissionsScreen.kt
    └── theme/
        ├── Color.kt
        ├── Dimensions.kt
        ├── Motion.kt
        ├── Theme.kt
        └── Type.kt
```

## Expansion path for V1

The UI layer is separated from future Android platform behavior.

Suggested V1 layers:

```text
domain/
├── ProtectionStatus.kt
└── PermissionRequirement.kt

platform/
├── accessibility/
├── admin/
└── background/

data/
└── ProtectionRepository.kt
```

`ProtectionState` can later be driven by a ViewModel and repository without rewriting the visual components.
