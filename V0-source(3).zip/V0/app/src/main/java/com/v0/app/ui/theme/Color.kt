package com.v0.app.ui.theme

import androidx.compose.ui.graphics.Color

object V0Colors {
    val SpaceBlack = Color(0xFF03050D)
    val DeepNight = Color(0xFF070B19)
    val Midnight = Color(0xFF111735)
    val Nebula = Color(0xFF2D194B)
    val Violet = Color(0xFF9B87FF)
    val VioletBright = Color(0xFFB5A6FF)
    val Cyan = Color(0xFF72DCF9)
    val Mint = Color(0xFF72F1B8)
    val WarmStar = Color(0xFFFFD9A8)
    val MoonWhite = Color(0xFFF5F3FF)
    val TextSecondary = Color(0xFFA9ACC2)
    val TextMuted = Color(0xFF747A98)
    val Glass = Color(0x12FFFFFF)
    val GlassStrong = Color(0x1AFFFFFF)
    val GlassBorder = Color(0x26FFFFFF)
    val GlassHighlight = Color(0x3DFFFFFF)
}
