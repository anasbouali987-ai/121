package com.v0.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val V0ColorScheme = darkColorScheme(
    primary = V0Colors.Violet,
    onPrimary = Color.White,
    secondary = V0Colors.Cyan,
    onSecondary = V0Colors.SpaceBlack,
    tertiary = V0Colors.Mint,
    background = V0Colors.SpaceBlack,
    onBackground = V0Colors.MoonWhite,
    surface = V0Colors.DeepNight,
    onSurface = V0Colors.MoonWhite
)

@Composable
fun V0Theme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = V0ColorScheme,
        typography = V0Typography,
        content = content
    )
}
