package com.v0.app.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.runtime.CompositionLocalProvider
import com.v0.app.ui.background.CelestialBackground
import com.v0.app.ui.screens.HomeScreen
import com.v0.app.ui.screens.PermissionsPreviewScreen

private enum class V0Screen { Home, PermissionsPreview }

@Composable
fun V0App() {
    var screen by remember { mutableStateOf(V0Screen.Home) }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        CelestialBackground {
            AnimatedContent(
                targetState = screen,
                transitionSpec = {
                    val duration = 420
                    if (targetState == V0Screen.PermissionsPreview) {
                        (slideInHorizontally(tween(duration)) { it / 5 } + fadeIn(tween(duration))) togetherWith
                            (slideOutHorizontally(tween(duration)) { -it / 7 } + fadeOut(tween(duration)))
                    } else {
                        (slideInHorizontally(tween(duration)) { -it / 5 } + fadeIn(tween(duration))) togetherWith
                            (slideOutHorizontally(tween(duration)) { it / 7 } + fadeOut(tween(duration)))
                    }
                },
                label = "screen"
            ) { target ->
                when (target) {
                    V0Screen.Home -> HomeScreen(
                        onOpenHiddenPermissions = { screen = V0Screen.PermissionsPreview },
                        modifier = Modifier
                            .fillMaxSize()
                            .windowInsetsPadding(WindowInsets.systemBars)
                    )
                    V0Screen.PermissionsPreview -> PermissionsPreviewScreen(
                        onBack = { screen = V0Screen.Home },
                        modifier = Modifier
                            .fillMaxSize()
                            .windowInsetsPadding(WindowInsets.systemBars)
                    )
                }
            }
        }
    }
}
