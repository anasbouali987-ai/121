package com.v0.app.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBackIosNew
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.v0.app.ui.theme.V0Colors

@Composable
fun FeatureTile(
    icon: ImageVector,
    title: String,
    subtitle: String,
    accent: Color,
    modifier: Modifier = Modifier,
    trailingText: String? = null
) {
    GlassCard(modifier = modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            androidx.compose.foundation.layout.Box(
                modifier = Modifier.size(46.dp),
                contentAlignment = Alignment.Center
            ) {
                androidx.compose.foundation.Canvas(Modifier.size(46.dp)) {
                    drawCircle(accent.copy(alpha = 0.13f))
                    drawCircle(
                        color = accent.copy(alpha = 0.30f),
                        style = androidx.compose.ui.graphics.drawscope.Stroke(1.4f)
                    )
                }
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accent,
                    modifier = Modifier.size(23.dp)
                )
            }
            Spacer(Modifier.width(15.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium, color = V0Colors.MoonWhite)
                Text(
                    subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = V0Colors.TextSecondary
                )
            }
            if (trailingText != null) {
                Text(
                    trailingText,
                    style = MaterialTheme.typography.labelMedium,
                    color = accent
                )
            } else {
                Icon(
                    imageVector = Icons.Outlined.ArrowBackIosNew,
                    contentDescription = null,
                    tint = V0Colors.TextMuted,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}
