package com.v0.app.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.DarkMode
import androidx.compose.material.icons.outlined.ShieldMoon
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.v0.app.ui.components.GlassCard
import com.v0.app.ui.components.PrimaryAction
import com.v0.app.ui.components.ProtectionCore
import com.v0.app.ui.components.StatusPill
import com.v0.app.ui.theme.V0Colors

@Composable
fun HomeScreen(
    onOpenHiddenPermissions: () -> Unit,
    modifier: Modifier = Modifier
) {
    var demoActive by remember { mutableStateOf(false) }
    var secretTapCount by remember { mutableIntStateOf(0) }
    val secretInteraction = remember { MutableInteractionSource() }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 22.dp)
            .padding(top = 54.dp, bottom = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Outlined.ShieldMoon,
                    contentDescription = null,
                    tint = V0Colors.VioletBright,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(Modifier.width(9.dp))
                Text("V0", style = MaterialTheme.typography.titleLarge, color = V0Colors.MoonWhite)
            }
            StatusPill("نسخة التصميم")
        }

        Spacer(Modifier.height(18.dp))

        ProtectionCore(active = demoActive)

        AnimatedContent(
            targetState = demoActive,
            transitionSpec = { fadeIn() togetherWith fadeOut() },
            label = "heroText"
        ) { active ->
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = if (active) "مساحتك الهادئة جاهزة" else "استعد لاستعادة وقتك",
                    style = MaterialTheme.typography.displaySmall,
                    color = V0Colors.MoonWhite,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(10.dp))
                Text(
                    text = if (active) {
                        "هذه معاينة بصرية فقط. في الإصدار القادم ستتحول إلى حماية حقيقية."
                    } else {
                        "واجهة هادئة بينك وبين كل ما يسرق انتباهك، مصممة لتصبح أكثر صرامة مع كل إصدار."
                    },
                    style = MaterialTheme.typography.bodyLarge,
                    color = V0Colors.TextSecondary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 12.dp)
                )
            }
        }

        Spacer(Modifier.height(26.dp))

        GlassCard(
            modifier = Modifier
                .fillMaxWidth()
                .animateContentSize(animationSpec = spring())
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (demoActive) Icons.Outlined.AutoAwesome else Icons.Outlined.DarkMode,
                        contentDescription = null,
                        tint = if (demoActive) V0Colors.Mint else V0Colors.Cyan,
                        modifier = Modifier.size(25.dp)
                    )
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(
                            text = if (demoActive) "وضع الحماية التجريبي" else "معاينة التجربة",
                            style = MaterialTheme.typography.titleLarge,
                            color = V0Colors.MoonWhite
                        )
                        Text(
                            text = if (demoActive) "نشط بصريًا" else "اضغط لتشغيل الحركة والحالة",
                            style = MaterialTheme.typography.bodyMedium,
                            color = V0Colors.TextSecondary
                        )
                    }
                }
                Spacer(Modifier.height(18.dp))
                PrimaryAction(
                    text = if (demoActive) "إيقاف المعاينة" else "تشغيل المعاينة",
                    active = demoActive,
                    onClick = { demoActive = !demoActive }
                )
            }
        }

        Spacer(Modifier.height(14.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            MiniMetric(
                title = "الواجهة",
                value = "مكتملة",
                accent = V0Colors.Cyan,
                modifier = Modifier.weight(1f)
            )
            MiniMetric(
                title = "النظام",
                value = "V0",
                accent = V0Colors.Violet,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(Modifier.height(24.dp))

        Text(
            text = "V0 · 0.0.0",
            style = MaterialTheme.typography.labelMedium,
            color = V0Colors.TextMuted,
            modifier = Modifier.clickable(
                interactionSource = secretInteraction,
                indication = null
            ) {
                secretTapCount += 1
                if (secretTapCount >= 5) {
                    secretTapCount = 0
                    onOpenHiddenPermissions()
                }
            }
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text = "خمس نقرات تكشف بوابة النظام",
            style = MaterialTheme.typography.labelMedium,
            color = Color.Transparent
        )
    }
}

@Composable
private fun MiniMetric(
    title: String,
    value: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    GlassCard(modifier = modifier, padding = androidx.compose.foundation.layout.PaddingValues(16.dp)) {
        Column {
            Text(title, style = MaterialTheme.typography.labelMedium, color = V0Colors.TextMuted)
            Spacer(Modifier.height(6.dp))
            Text(value, style = MaterialTheme.typography.titleMedium, color = accent)
        }
    }
}
