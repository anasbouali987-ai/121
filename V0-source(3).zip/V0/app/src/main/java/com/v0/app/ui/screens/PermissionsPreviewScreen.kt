package com.v0.app.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AccessibilityNew
import androidx.compose.material.icons.outlined.AdminPanelSettings
import androidx.compose.material.icons.outlined.ArrowForward
import androidx.compose.material.icons.outlined.BatterySaver
import androidx.compose.material.icons.outlined.DeveloperMode
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.v0.app.ui.components.FeatureTile
import com.v0.app.ui.components.StatusPill
import com.v0.app.ui.theme.V0Colors

@Composable
fun PermissionsPreviewScreen(
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)
    val interaction = remember { MutableInteractionSource() }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 22.dp)
            .padding(top = 54.dp, bottom = 32.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Outlined.ArrowForward,
                contentDescription = "رجوع",
                tint = V0Colors.MoonWhite,
                modifier = Modifier
                    .size(25.dp)
                    .clickable(
                        interactionSource = interaction,
                        indication = null,
                        onClick = onBack
                    )
            )
            StatusPill("صفحة مخفية", accent = V0Colors.Cyan)
        }

        Spacer(Modifier.height(34.dp))

        Icon(
            imageVector = Icons.Outlined.DeveloperMode,
            contentDescription = null,
            tint = V0Colors.VioletBright,
            modifier = Modifier
                .size(54.dp)
                .align(Alignment.CenterHorizontally)
        )
        Spacer(Modifier.height(18.dp))
        Text(
            text = "بوابة النظام",
            style = MaterialTheme.typography.displaySmall,
            color = V0Colors.MoonWhite,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(10.dp))
        Text(
            text = "معاينة مستقلة للصلاحيات التي ستُربط فعليًا في الإصدار V1. لا توجد أذونات حقيقية في V0.",
            style = MaterialTheme.typography.bodyLarge,
            color = V0Colors.TextSecondary,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(30.dp))

        FeatureTile(
            icon = Icons.Outlined.AccessibilityNew,
            title = "إمكانية الوصول",
            subtitle = "طبقة المراقبة المستقبلية",
            accent = V0Colors.Cyan,
            trailingText = "قريبًا"
        )
        Spacer(Modifier.height(13.dp))
        FeatureTile(
            icon = Icons.Outlined.AdminPanelSettings,
            title = "إدارة الجهاز",
            subtitle = "حماية إضافية ضد التعطيل",
            accent = V0Colors.VioletBright,
            trailingText = "قريبًا"
        )
        Spacer(Modifier.height(13.dp))
        FeatureTile(
            icon = Icons.Outlined.BatterySaver,
            title = "الحضور في الخلفية",
            subtitle = "استمرارية الخدمة بعد منح الصلاحيات",
            accent = V0Colors.Mint,
            trailingText = "قريبًا"
        )

        Spacer(Modifier.height(28.dp))
        Text(
            text = "هذه الصفحة مخفية عمدًا حتى تبقى الواجهة الرئيسية هادئة وغير تقنية.",
            style = MaterialTheme.typography.bodyMedium,
            color = V0Colors.TextMuted,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
    }
}
