package com.v0.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.v0.app.ui.theme.V0Colors

@Composable
fun StatusPill(
    text: String,
    accent: Color = V0Colors.Violet,
    modifier: Modifier = Modifier
) {
    val shape = RoundedCornerShape(100.dp)
    Row(
        modifier = modifier
            .clip(shape)
            .background(accent.copy(alpha = 0.10f))
            .border(1.dp, accent.copy(alpha = 0.22f), shape),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Spacer(Modifier.width(11.dp))
        androidx.compose.foundation.Canvas(Modifier.size(6.dp)) {
            drawCircle(accent)
        }
        Spacer(Modifier.width(7.dp))
        Text(
            text = text,
            style = MaterialTheme.typography.labelMedium,
            color = V0Colors.MoonWhite.copy(alpha = 0.82f)
        )
        Spacer(Modifier.width(11.dp))
    }
}
