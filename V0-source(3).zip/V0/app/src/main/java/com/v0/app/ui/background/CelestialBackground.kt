package com.v0.app.ui.background

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import com.v0.app.ui.theme.V0Colors
import kotlin.math.sin
import kotlin.random.Random

private data class Star(
    val x: Float,
    val y: Float,
    val radius: Float,
    val alpha: Float,
    val phase: Float,
    val color: Color
)

@Composable
fun CelestialBackground(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    val stars = remember { generateStars(seed = 1701, count = 128) }
    val transition = rememberInfiniteTransition(label = "sky")
    val time = transition.animateFloat(
        initialValue = 0f,
        targetValue = 6.28318f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 9000),
            repeatMode = RepeatMode.Restart
        ),
        label = "starTime"
    ).value
    val drift = transition.animateFloat(
        initialValue = -0.06f,
        targetValue = 0.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 15000),
            repeatMode = RepeatMode.Reverse
        ),
        label = "auroraDrift"
    ).value

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    0f to V0Colors.SpaceBlack,
                    0.48f to V0Colors.DeepNight,
                    1f to V0Colors.Nebula
                )
            )
    ) {
        Canvas(Modifier.fillMaxSize()) {
            drawAurora(drift)
            drawConstellation()
            drawStars(stars, time)
            drawGrain(seed = 81)
        }
        content()
    }
}

private fun DrawScope.drawAurora(drift: Float) {
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(
                V0Colors.Violet.copy(alpha = 0.20f),
                V0Colors.Violet.copy(alpha = 0.05f),
                Color.Transparent
            ),
            center = Offset(size.width * (0.80f + drift), size.height * 0.30f),
            radius = size.minDimension * 0.72f
        ),
        radius = size.minDimension * 0.72f,
        center = Offset(size.width * (0.80f + drift), size.height * 0.30f)
    )
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(
                V0Colors.Cyan.copy(alpha = 0.12f),
                V0Colors.Cyan.copy(alpha = 0.025f),
                Color.Transparent
            ),
            center = Offset(size.width * (0.04f - drift), size.height * 0.14f),
            radius = size.minDimension * 0.62f
        ),
        radius = size.minDimension * 0.62f,
        center = Offset(size.width * (0.04f - drift), size.height * 0.14f)
    )
}

private fun DrawScope.drawConstellation() {
    val points = listOf(
        Offset(size.width * 0.12f, size.height * 0.18f),
        Offset(size.width * 0.20f, size.height * 0.14f),
        Offset(size.width * 0.28f, size.height * 0.20f),
        Offset(size.width * 0.22f, size.height * 0.28f),
        Offset(size.width * 0.13f, size.height * 0.25f)
    )
    val lines = listOf(0 to 1, 1 to 2, 2 to 3, 3 to 4, 4 to 0, 1 to 3)
    lines.forEach { (from, to) ->
        drawLine(
            color = V0Colors.VioletBright.copy(alpha = 0.08f),
            start = points[from],
            end = points[to],
            strokeWidth = 1f
        )
    }
    points.forEach {
        drawCircle(V0Colors.MoonWhite.copy(alpha = 0.16f), radius = 2.2f, center = it)
    }
}

private fun DrawScope.drawStars(stars: List<Star>, time: Float) {
    stars.forEachIndexed { index, star ->
        val twinkle = if (index % 9 == 0) {
            0.68f + 0.32f * ((sin(time + star.phase) + 1f) / 2f)
        } else 1f
        val center = Offset(size.width * star.x, size.height * star.y)
        val finalAlpha = star.alpha * twinkle
        if (star.radius > 1.35f) {
            drawCircle(
                color = star.color.copy(alpha = finalAlpha * 0.18f),
                radius = star.radius * 4.5f,
                center = center
            )
            drawLine(
                color = star.color.copy(alpha = finalAlpha * 0.30f),
                start = Offset(center.x - star.radius * 3.2f, center.y),
                end = Offset(center.x + star.radius * 3.2f, center.y),
                strokeWidth = 0.7f
            )
            drawLine(
                color = star.color.copy(alpha = finalAlpha * 0.30f),
                start = Offset(center.x, center.y - star.radius * 3.2f),
                end = Offset(center.x, center.y + star.radius * 3.2f),
                strokeWidth = 0.7f
            )
        }
        drawCircle(star.color.copy(alpha = finalAlpha), radius = star.radius, center = center)
    }
}

private fun DrawScope.drawGrain(seed: Int) {
    val random = Random(seed)
    repeat(420) {
        val alpha = random.nextFloat() * 0.014f
        drawCircle(
            color = Color.White.copy(alpha = alpha),
            radius = 0.45f,
            center = Offset(random.nextFloat() * size.width, random.nextFloat() * size.height)
        )
    }
}

private fun generateStars(seed: Int, count: Int): List<Star> {
    val random = Random(seed)
    return List(count) { index ->
        val tone = when {
            index % 31 == 0 -> V0Colors.WarmStar
            index % 17 == 0 -> V0Colors.Cyan
            else -> V0Colors.MoonWhite
        }
        Star(
            x = random.nextFloat(),
            y = random.nextFloat(),
            radius = when {
                index % 29 == 0 -> 1.8f
                index % 11 == 0 -> 1.2f
                else -> 0.55f + random.nextFloat() * 0.55f
            },
            alpha = 0.30f + random.nextFloat() * 0.60f,
            phase = random.nextFloat() * 6.28318f,
            color = tone
        )
    }
}
