package com.v0.app.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import com.v0.app.ui.theme.V0Colors
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun ProtectionCore(
    active: Boolean,
    modifier: Modifier = Modifier
) {
    val transition = rememberInfiniteTransition(label = "core")
    val rotation = transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(17000), RepeatMode.Restart),
        label = "rotation"
    ).value
    val pulse = transition.animateFloat(
        initialValue = 0.84f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(2200), RepeatMode.Reverse),
        label = "pulse"
    ).value

    Box(modifier = modifier.size(190.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(190.dp)) {
            val c = center
            val base = if (active) V0Colors.Mint else V0Colors.Violet

            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(base.copy(alpha = 0.28f * pulse), Color.Transparent),
                    center = c,
                    radius = size.minDimension * 0.50f
                ),
                radius = size.minDimension * 0.50f,
                center = c
            )
            drawCircle(
                color = Color.White.copy(alpha = 0.04f),
                radius = size.minDimension * 0.37f,
                center = c
            )
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0xFF151B38), Color(0xFF070A16)),
                    center = c,
                    radius = size.minDimension * 0.28f
                ),
                radius = size.minDimension * 0.28f,
                center = c
            )
            drawCircle(
                color = base.copy(alpha = 0.75f),
                radius = size.minDimension * 0.31f,
                center = c,
                style = Stroke(width = 2.2f)
            )
            drawCircle(
                color = V0Colors.MoonWhite.copy(alpha = 0.14f),
                radius = size.minDimension * 0.42f,
                center = c,
                style = Stroke(width = 1.2f)
            )

            rotate(rotation, pivot = c) {
                repeat(3) { index ->
                    val angle = Math.toRadians((index * 120.0))
                    val orbitRadius = size.minDimension * 0.42f
                    val dot = Offset(
                        x = c.x + (cos(angle) * orbitRadius).toFloat(),
                        y = c.y + (sin(angle) * orbitRadius).toFloat()
                    )
                    drawCircle(
                        color = if (index == 1) V0Colors.Cyan else base,
                        radius = if (index == 1) 4.2f else 3.2f,
                        center = dot
                    )
                }
            }

            val starR = size.minDimension * 0.11f
            drawLine(
                color = V0Colors.MoonWhite,
                start = Offset(c.x - starR, c.y),
                end = Offset(c.x + starR, c.y),
                strokeWidth = 4f,
                cap = StrokeCap.Round
            )
            drawLine(
                color = V0Colors.MoonWhite,
                start = Offset(c.x, c.y - starR),
                end = Offset(c.x, c.y + starR),
                strokeWidth = 4f,
                cap = StrokeCap.Round
            )
            drawCircle(V0Colors.MoonWhite, radius = 7f, center = c)
        }
    }
}
