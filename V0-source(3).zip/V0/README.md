# V0

V0 is the visual foundation of a future Android focus and self-control application.
This release intentionally contains **UI only**—no Accessibility Service, Device Administrator, background service, blocking, or real permission requests.

## Included in V0

- RTL-first Arabic interface
- Programmatic night-sky background
- Deterministic star field with restrained twinkling
- Aurora-style radial glows
- Pseudo-glass cards
- Animated protection core
- Demo-only visual activation state
- Hidden permissions preview page

## Hidden permissions preview

Tap the `V0 · 0.0.0` label five times on the main screen.

## Build

Requirements:

- JDK 17+
- Android SDK 35

Linux/macOS:

```bash
chmod +x gradlew
./gradlew assembleDebug
```

Windows:

```bat
gradlew.bat assembleDebug
```

The included launcher bootstraps Gradle 8.9 automatically on first use.

## Package

- Project name: `V0`
- Application ID: `com.v0.app`
- Version: `0.0.0`
