# V0 UI architecture

```text
app/src/main/java/com/v0/app/
├── MainActivity.kt
└── ui/
    ├── V0App.kt
    ├── background/
    │   └── CelestialBackground.kt
    ├── components/
    │   ├── FeatureTile.kt
    │   ├── GlassCard.kt
    │   ├── PrimaryAction.kt
    │   ├── ProtectionCore.kt
    │   └── StatusPill.kt
    ├── screens/
    │   ├── HomeScreen.kt
    │   └── PermissionsPreviewScreen.kt
    └── theme/
        ├── Color.kt
        ├── Theme.kt
        └── Type.kt
```

The UI is deliberately separated from future permission and protection logic. V1 can add domain and platform layers without rewriting the design system.
